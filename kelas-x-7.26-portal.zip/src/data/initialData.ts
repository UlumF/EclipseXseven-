import {
  Student,
  PiketDaySchedule,
  ClassStructure,
  SubjectItem,
  HomeworkNote,
  Announcement,
  ClassImportantNote,
  WebsiteSettings
} from '../types';

export const INITIAL_STUDENTS: Student[] = [
  { id: '1', nisn: '0071230001', name: 'Achmad Fauzan Pratama', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-blue-600' },
  { id: '2', nisn: '0071230002', name: 'Adinda Putri Maharani', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-rose-500' },
  { id: '3', nisn: '0071230003', name: 'Aisyah Nur Aulia', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-emerald-500' },
  { id: '4', nisn: '0071230004', name: 'Alif Kurniawan Putra', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-indigo-600' },
  { id: '5', nisn: '0071230005', name: 'Ananda Bagas Wicaksono', gender: 'L', attendanceStatus: 'sakit', notes: 'Demam dan flu (Surat izin terlampir)', avatarBg: 'bg-amber-600' },
  { id: '6', nisn: '0071230006', name: 'Aqila Zahra Ramadhani', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-pink-600' },
  { id: '7', nisn: '0071230007', name: 'Aurelia Safira Putri', gender: 'P', attendanceStatus: 'hadir', notes: 'Wakil Ketua Kelas', avatarBg: 'bg-purple-600' },
  { id: '8', nisn: '0071230008', name: 'Bayu Arya Permana', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-cyan-600' },
  { id: '9', nisn: '0071230009', name: 'Cantika Dewi Lestari', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-fuchsia-600' },
  { id: '10', nisn: '0071230010', name: 'Daffa Rizky Ramadhan', gender: 'L', attendanceStatus: 'izin', notes: 'Lomba Olimpiade Fisika Kota', avatarBg: 'bg-blue-500' },
  { id: '11', nisn: '0071230011', name: 'Danendra Galih Saputra', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-teal-600' },
  { id: '12', nisn: '0071230012', name: 'Dini Fitriyani', gender: 'P', attendanceStatus: 'hadir', notes: 'Sekretaris 1', avatarBg: 'bg-violet-600' },
  { id: '13', nisn: '0071230013', name: 'Fadhil Ihsan Maulana', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-sky-600' },
  { id: '14', nisn: '0071230014', name: 'Farhan Maulana Hakim', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-lime-600' },
  { id: '15', nisn: '0071230015', name: 'Gita Clarissa Melani', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-pink-500' },
  { id: '16', nisn: '0071230016', name: 'Habibi Rahman Syah', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-slate-700' },
  { id: '17', nisn: '0071230017', name: 'Hafizha Nurul Izzati', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-amber-500' },
  { id: '18', nisn: '0071230018', name: 'Indra Lesmana Wardhana', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-indigo-500' },
  { id: '19', nisn: '0071230019', name: 'Jessica Amanda Siregar', gender: 'P', attendanceStatus: 'hadir', notes: 'Bendahara 1', avatarBg: 'bg-purple-500' },
  { id: '20', nisn: '0071230020', name: 'Kevin Christian Wijaya', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-blue-700' },
  { id: '21', nisn: '0071230021', name: 'Luthfi Hakim Sudrajat', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-emerald-600' },
  { id: '22', nisn: '0071230022', name: 'Marsha Nabila Khairunisa', gender: 'P', attendanceStatus: 'hadir', notes: 'Sekretaris 2', avatarBg: 'bg-rose-600' },
  { id: '23', nisn: '0071230023', name: 'Muhammad Rayhan Al-Fatih', gender: 'L', attendanceStatus: 'hadir', notes: 'Ketua Kelas', avatarBg: 'bg-blue-800' },
  { id: '24', nisn: '0071230024', name: 'Nabila Shafa Azzahra', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-fuchsia-500' },
  { id: '25', nisn: '0071230025', name: 'Naufal Raditya Pratama', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-teal-500' },
  { id: '26', nisn: '0071230026', name: 'Nurul Hidayati', gender: 'P', attendanceStatus: 'hadir', notes: 'Bendahara 2', avatarBg: 'bg-amber-700' },
  { id: '27', nisn: '0071230027', name: 'Putri Ayu Wandira', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-pink-700' },
  { id: '28', nisn: '0071230028', name: 'Raden Mas Bagus Satria', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-cyan-700' },
  { id: '29', nisn: '0071230029', name: 'Rangga Aditya Nugraha', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-indigo-700' },
  { id: '30', nisn: '0071230030', name: 'Rania Salma Humaira', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-violet-500' },
  { id: '31', nisn: '0071230031', name: 'Reza Fahlevi', gender: 'L', attendanceStatus: 'alpa', notes: 'Tanpa konfirmasi wali murid', avatarBg: 'bg-red-600' },
  { id: '32', nisn: '0071230032', name: 'Salsabila Citra Dewi', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-teal-700' },
  { id: '33', nisn: '0071230033', name: 'Tiara Anggun Pratiwi', gender: 'P', attendanceStatus: 'hadir', avatarBg: 'bg-rose-700' },
  { id: '34', nisn: '0071230034', name: 'Vito Andrian Pratama', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-blue-600' },
  { id: '35', nisn: '0071230035', name: 'Wildan Arya Syahputra', gender: 'L', attendanceStatus: 'hadir', avatarBg: 'bg-emerald-700' }
];

export const INITIAL_PIKET: PiketDaySchedule[] = [
  {
    day: 'Senin',
    coordinator: 'Muhammad Rayhan Al-Fatih',
    members: [
      'Muhammad Rayhan Al-Fatih',
      'Achmad Fauzan Pratama',
      'Adinda Putri Maharani',
      'Aisyah Nur Aulia',
      'Alif Kurniawan Putra',
      'Aqila Zahra Ramadhani',
      'Bayu Arya Permana'
    ],
    cleanlinessScore: 95,
    tasks: [
      { id: 'p1-1', label: 'Menyapu seluruh lantai kelas dan lorong depan', completed: true },
      { id: 'p1-2', label: 'Mengepel lantai bagian depan & belakang', completed: true },
      { id: 'p1-3', label: 'Menghapus dan membersihkan papan tulis putih', completed: true },
      { id: 'p1-4', label: 'Membuang sampah ke tempat pembuangan luar', completed: false },
      { id: 'p1-5', label: 'Merapikan meja guru & menyediakan spidol/penghapus', completed: true },
      { id: 'p1-6', label: 'Menyiapkan kabel proyektor / LCD kelas', completed: true }
    ]
  },
  {
    day: 'Selasa',
    coordinator: 'Aurelia Safira Putri',
    members: [
      'Aurelia Safira Putri',
      'Ananda Bagas Wicaksono',
      'Cantika Dewi Lestari',
      'Daffa Rizky Ramadhan',
      'Danendra Galih Saputra',
      'Dini Fitriyani',
      'Fadhil Ihsan Maulana'
    ],
    cleanlinessScore: 92,
    tasks: [
      { id: 'p2-1', label: 'Menyapu seluruh lantai kelas dan lorong depan', completed: false },
      { id: 'p2-2', label: 'Mengepel lantai dan menyiram tanaman kelas', completed: false },
      { id: 'p2-3', label: 'Menghapus dan membersihkan papan tulis putih', completed: false },
      { id: 'p2-4', label: 'Membuang sampah ke tempat pembuangan luar', completed: false },
      { id: 'p2-5', label: 'Merapikan meja guru & buku absen kelas', completed: false },
      { id: 'p2-6', label: 'Memastikan jendela dan ventilasi terbuka/bersih', completed: false }
    ]
  },
  {
    day: 'Rabu',
    coordinator: 'Jessica Amanda Siregar',
    members: [
      'Jessica Amanda Siregar',
      'Farhan Maulana Hakim',
      'Gita Clarissa Melani',
      'Habibi Rahman Syah',
      'Hafizha Nurul Izzati',
      'Indra Lesmana Wardhana',
      'Kevin Christian Wijaya'
    ],
    cleanlinessScore: 96,
    tasks: [
      { id: 'p3-1', label: 'Menyapu seluruh lantai kelas dan lorong depan', completed: false },
      { id: 'p3-2', label: 'Mengepel lantai dengan cairan pembersih wangi', completed: false },
      { id: 'p3-3', label: 'Menghapus dan membersihkan papan tulis putih', completed: false },
      { id: 'p3-4', label: 'Membuang sampah dan mengganti plastik kresek sampah', completed: false },
      { id: 'p3-5', label: 'Merapikan meja guru, taplak, dan vas bunga', completed: false },
      { id: 'p3-6', label: 'Menyiapkan remote AC dan cek kelistrikan', completed: false }
    ]
  },
  {
    day: 'Kamis',
    coordinator: 'Marsha Nabila Khairunisa',
    members: [
      'Marsha Nabila Khairunisa',
      'Luthfi Hakim Sudrajat',
      'Nabila Shafa Azzahra',
      'Naufal Raditya Pratama',
      'Nurul Hidayati',
      'Putri Ayu Wandira',
      'Raden Mas Bagus Satria'
    ],
    cleanlinessScore: 90,
    tasks: [
      { id: 'p4-1', label: 'Menyapu seluruh lantai kelas dan lorong depan', completed: false },
      { id: 'p4-2', label: 'Mengepel lantai & membersihkan sudut ruang', completed: false },
      { id: 'p4-3', label: 'Menghapus dan membersihkan papan tulis putih', completed: false },
      { id: 'p4-4', label: 'Membuang sampah ke tempat pembuangan akhir', completed: false },
      { id: 'p4-5', label: 'Merapikan meja guru dan menyiapkan spidol cadangan', completed: false },
      { id: 'p4-6', label: 'Mengelap kaca jendela kelas', completed: false }
    ]
  },
  {
    day: 'Jumat',
    coordinator: 'Rangga Aditya Nugraha',
    members: [
      'Rangga Aditya Nugraha',
      'Rania Salma Humaira',
      'Reza Fahlevi',
      'Salsabila Citra Dewi',
      'Tiara Anggun Pratiwi',
      'Vito Andrian Pratama',
      'Wildan Arya Syahputra'
    ],
    cleanlinessScore: 98,
    tasks: [
      { id: 'p5-1', label: 'Jumat Bersih: Pembersihan total kelas & loker', completed: false },
      { id: 'p5-2', label: 'Mengepel lantai dan menyikat keset pintu masuk', completed: false },
      { id: 'p5-3', label: 'Membersihkan papan tulis dan kisi-kisi AC', completed: false },
      { id: 'p5-4', label: 'Membuang sampah dan mencuci tempat sampah', completed: false },
      { id: 'p5-5', label: 'Merapikan meja guru dan mengunci lemari kelas', completed: false },
      { id: 'p5-6', label: 'Mematikan stop kontak, AC, dan mengunci pintu saat pulang', completed: false }
    ]
  }
];

export const INITIAL_STRUCTURE: ClassStructure = {
  motto: '',
  visi: '',
  waliKelas: {
    id: 'wk-1',
    role: 'Wali Kelas',
    name: '',
    nickname: '',
    avatar: '👩‍🏫',
    description: '',
    contact: '',
    tasks: [],
    quote: ''
  },
  ketuaKelas: {
    id: 'kk-1',
    role: 'Ketua Kelas',
    name: '',
    nickname: '',
    avatar: '👨‍🎓',
    description: '',
    contact: '',
    tasks: [],
    quote: ''
  },
  wakilKetua: {
    id: 'wk-2',
    role: 'Wakil Ketua Kelas',
    name: '',
    nickname: '',
    avatar: '👩‍🎓',
    description: '',
    contact: '',
    tasks: [],
    quote: ''
  },
  sekretaris1: {
    id: 'sek-1',
    role: 'Sekretaris 1',
    name: '',
    nickname: '',
    avatar: '📝',
    description: '',
    contact: '',
    tasks: [],
    quote: ''
  },
  sekretaris2: {
    id: 'sek-2',
    role: 'Sekretaris 2',
    name: '',
    nickname: '',
    avatar: '📋',
    description: '',
    contact: '',
    tasks: [],
    quote: ''
  },
  bendahara1: {
    id: 'ben-1',
    role: 'Bendahara 1',
    name: '',
    nickname: '',
    avatar: '💰',
    description: '',
    contact: '',
    tasks: [],
    quote: ''
  },
  bendahara2: {
    id: 'ben-2',
    role: 'Bendahara 2',
    name: '',
    nickname: '',
    avatar: '💳',
    description: '',
    contact: '',
    tasks: [],
    quote: ''
  },
  departments: []
};

export const INITIAL_SCHEDULE: SubjectItem[] = [
  // SENIN
  {
    id: 'sub-mon-1',
    code: 'UPC',
    name: 'Upacara Bendera',
    teacher: 'Tim Kesiswaan / Pembina Upacara',
    room: 'Lapangan Utama',
    day: 'Senin',
    startTime: '07.00',
    endTime: '07.45',
    category: 'Pengembangan Diri',
    color: 'slate',
    description: 'Upacara bendera rutin mingguan untuk menumbuhkan rasa nasionalisme dan kedisiplinan.',
    currentTopic: 'Amanat: Kedisiplinan & Etika Bermedia Sosial',
    syllabusTopics: ['Kedisiplinan', 'Kepemimpinan', 'Wawasan Kebangsaan'],
    referenceBooks: ['Panduan Tata Upacara Sekolah']
  },
  {
    id: 'sub-mon-2',
    code: 'MTK-W',
    name: 'Matematika Wajib',
    teacher: 'Dra. Hj. Siti Nurhaliza, M.Pd',
    teacherNip: '19720415 199803 2 004',
    room: 'Ruang Kelas X-7',
    day: 'Senin',
    startTime: '07.45',
    endTime: '09.45',
    category: 'Wajib',
    color: 'blue',
    description: 'Mempelajari konsep dasar matematika, aljabar, persamaan & pertidaksamaan linear, serta fungsi kuadrat.',
    currentTopic: 'Bab 4: Sistem Persamaan Linear Tiga Variabel (SPLTV) & Aplikasi Kontekstual',
    syllabusTopics: ['Eksponen & Logaritma', 'SPLTV & SPtLDV', 'Fungsi Kuadrat & Rasional', 'Trigonometri Dasar'],
    referenceBooks: ['Buku Siswa Matematika SMA Kelas X Kemendikbudristek', 'Mandiri Matematika Erlangga'],
    classroomLink: 'https://classroom.google.com/c/mtk-x7-26'
  },
  {
    id: 'sub-mon-3',
    code: 'BIN-1',
    name: 'Bahasa Indonesia',
    teacher: 'Bambang Sudibyo, S.Pd',
    teacherNip: '19810822 200604 1 008',
    room: 'Ruang Kelas X-7',
    day: 'Senin',
    startTime: '10.00',
    endTime: '11.30',
    category: 'Wajib',
    color: 'emerald',
    description: 'Pengembangan kemampuan berbahasa dan bersastra Indonesia secara kritis, kreatif, dan komunikatif.',
    currentTopic: 'Teks Laporan Hasil Observasi (LHO) & Kaidah Kebahasaan',
    syllabusTopics: ['Teks LHO', 'Teks Eksposisi', 'Teks Anekdot', 'Teks Hikayat & Cerpen'],
    referenceBooks: ['Cerdas Cergas Berbahasa Indonesia Kelas X']
  },
  {
    id: 'sub-mon-4',
    code: 'SEJ-1',
    name: 'Sejarah Indonesia',
    teacher: 'Rina Kusuma Dewi, S.Pd, M.Hum',
    teacherNip: '19850310 200902 2 005',
    room: 'Ruang Kelas X-7',
    day: 'Senin',
    startTime: '12.30',
    endTime: '14.00',
    category: 'Wajib',
    color: 'amber',
    description: 'Pemahaman peristiwa sejarah bangsa Indonesia dari masa praaksara hingga revolusi kemerdekaan.',
    currentTopic: 'Zaman Kerajaan Hindu-Buddha di Nusantara & Jalur Rempah',
    syllabusTopics: ['Konsep Dasar Sejarah', 'Zaman Praaksara', 'Kerajaan Hindu-Buddha', 'Kerajaan Islam Nusantara'],
    referenceBooks: ['Sejarah Indonesia Kurikulum Merdeka Kemendikbud']
  },

  // SELASA
  {
    id: 'sub-tue-1',
    code: 'FIS-1',
    name: 'Fisika',
    teacher: 'Dr. Ir. Hendra Gunawan, M.Si',
    teacherNip: '19760912 200212 1 003',
    room: 'Laboratorium Fisika 1',
    day: 'Selasa',
    startTime: '07.00',
    endTime: '09.00',
    category: 'Peminatan',
    color: 'indigo',
    description: 'Studi gejala alam, kinematika gerak, dinamika partikel hukum Newton, serta energi dan usaha.',
    currentTopic: 'Hukum Newton tentang Gerak & Gaya Gesek pada Bidang Miring',
    syllabusTopics: ['Pengukuran & Vektor', 'Kinematika Gerak Lurus (GLB & GLBB)', 'Dinamika Hukum Newton', 'Usaha dan Energi'],
    referenceBooks: ['Fisika SMA/MA Kelas X Halliday Resnick edisi Indonesia', 'Fisika Eksplorasi Sagufindo'],
    classroomLink: 'https://classroom.google.com/c/fisika-x7-lab'
  },
  {
    id: 'sub-tue-2',
    code: 'KIM-1',
    name: 'Kimia',
    teacher: 'Sri Wahyuningsih, M.Pd',
    teacherNip: '19800214 200501 2 007',
    room: 'Laboratorium Kimia',
    day: 'Selasa',
    startTime: '09.15',
    endTime: '11.15',
    category: 'Peminatan',
    color: 'purple',
    description: 'Struktur atom, sistem periodik unsur, ikatan kimia, dan stoikiometri larutan.',
    currentTopic: 'Ikatan Kimia: Ikatan Kovalen Polar & Nonpolar serta Geometri Molekul',
    syllabusTopics: ['Struktur Atom & Tabel Periodik', 'Ikatan Kimia', 'Hukum-Hukum Dasar Kimia', 'Larutan Elektrolit & Redoks'],
    referenceBooks: ['Kimia untuk SMA/MA Kelas X - Unggul Sudarmo', 'Buku Paket Kimia Diknas']
  },
  {
    id: 'sub-tue-3',
    code: 'BIG-1',
    name: 'Bahasa Inggris',
    teacher: 'Sarah Nathania, S.Pd, M.A',
    teacherNip: '19890520 201403 2 002',
    room: 'Ruang Kelas X-7',
    day: 'Selasa',
    startTime: '12.00',
    endTime: '13.30',
    category: 'Wajib',
    color: 'rose',
    description: 'Active English communication, reading comprehension, descriptive text, and conversational fluency.',
    currentTopic: 'Descriptive Text: Describing World Landmarks & Tourism Places',
    syllabusTopics: ['Great Athletes (Descriptive Text)', 'Sports Events', 'Narrative Legends', 'Expository Speech'],
    referenceBooks: ['Pathway to English for Senior High School Grade X']
  },

  // RABU
  {
    id: 'sub-wed-1',
    code: 'BIO-1',
    name: 'Biologi',
    teacher: 'Drs. Agus Supriyadi, M.Kes',
    teacherNip: '19690317 199403 1 004',
    room: 'Laboratorium Biologi',
    day: 'Rabu',
    startTime: '07.00',
    endTime: '09.00',
    category: 'Peminatan',
    color: 'teal',
    description: 'Keanekaragaman hayati, virus & bakteri, kingdom fungi, serta ekosistem lingkungan hidup.',
    currentTopic: 'Virus: Struktur, Replikasi Litik & Lisogenik, serta Peranan Vaksin',
    syllabusTopics: ['Keanekaragaman Hayati Indonesia', 'Virus & Bioteknologi', 'Bakteri & Archaebacteria', 'Ekologi Lingkungan'],
    referenceBooks: ['Campbell Biology 11th Edition (Summary)', 'Biologi Siswa Kelas X Erlangga']
  },
  {
    id: 'sub-wed-2',
    code: 'INF-1',
    name: 'Informatika & Koding',
    teacher: 'Dimas Aditya, S.Kom, M.T',
    teacherNip: '19921105 201801 1 002',
    room: 'Laboratorium Komputer 2',
    day: 'Rabu',
    startTime: '09.15',
    endTime: '11.15',
    category: 'Wajib',
    color: 'sky',
    description: 'Berpikir komputasional, dasar pemrograman Python & Web, analisis data, dan jaringan komputer.',
    currentTopic: 'Algoritma Pemrograman: Struktur Percabangan dan Perulangan dengan Python',
    syllabusTopics: ['Berpikir Komputasional', 'Sistem Komputer & Jaringan', 'Analisis Data Spreadsheet', 'Algoritma & Pemrograman'],
    referenceBooks: ['Buku Informatika SMA Kelas X Diknas', 'Hands-on Python Coding Workshop'],
    classroomLink: 'https://github.com/kelas-x7-26/informatika'
  },
  {
    id: 'sub-wed-3',
    code: 'SNB-1',
    name: 'Seni Budaya & Prakarya',
    teacher: 'Dewi Sekar Arum, S.Sn',
    teacherNip: '19870618 201001 2 006',
    room: 'Ruang Kesenian',
    day: 'Rabu',
    startTime: '12.00',
    endTime: '13.30',
    category: 'Wajib',
    color: 'fuchsia',
    description: 'Apresiasi dan kreasi karya seni rupa dua dimensi, kriya lokal, dan musik tradisional modern.',
    currentTopic: 'Eksplorasi Media Seni Rupa 2 Dimensi & Sketsa Ragam Hias Nusantara',
    syllabusTopics: ['Seni Rupa 2 Dimensi', 'Seni Musik Tradisional', 'Seni Tari Nusantara', 'Pameran Karya Kelas'],
    referenceBooks: ['Seni Budaya Kelas X Kemendikbud']
  },

  // KAMIS
  {
    id: 'sub-thu-1',
    code: 'PJK-1',
    name: 'PJOK (Pendidikan Jasmani & Kesehatan)',
    teacher: 'Rian Triatmoko, S.Pd',
    teacherNip: '19840120 200801 1 007',
    room: 'GOR & Lapangan Olahraga',
    day: 'Kamis',
    startTime: '07.00',
    endTime: '09.00',
    category: 'Wajib',
    color: 'orange',
    description: 'Olahraga permainan bola besar (Basket/Futsal), kebugaran jasmani, dan pola hidup sehat.',
    currentTopic: 'Keterampilan Bola Basket: Dribble, Chest Pass, dan Lay-up Shoot',
    syllabusTopics: ['Permainan Bola Besar (Basket/Voli)', 'Atletik Lari Jarak Pendek', 'Kebugaran Jasmani', 'Pertolongan Pertama'],
    referenceBooks: ['Buku PJOK SMA Kelas X']
  },
  {
    id: 'sub-thu-2',
    code: 'PPKN-1',
    name: 'Pendidikan Pancasila & Kewarganegaraan',
    teacher: 'Drs. H. Mulyadi, M.Si',
    teacherNip: '19671109 199303 1 005',
    room: 'Ruang Kelas X-7',
    day: 'Kamis',
    startTime: '09.15',
    endTime: '10.45',
    category: 'Wajib',
    color: 'red',
    description: 'Nilai-nilai Pancasila, konstitusi UUD 1945, hak asasi manusia, dan integrasi nasional.',
    currentTopic: 'Penerapan Nilai-Nilai Pancasila dalam Kehidupan Berbangsa Era Digital',
    syllabusTopics: ['Nilai Dasar Pancasila', 'Konstitusi & Norma Hukum', 'Bhinneka Tunggal Ika', 'Wawasan Nusantara'],
    referenceBooks: ['Pendidikan Pancasila SMA Kelas X']
  },
  {
    id: 'sub-thu-3',
    code: 'EKO-1',
    name: 'Ekonomi Dasar',
    teacher: 'Yuli Astuti, S.E, M.Pd',
    teacherNip: '19830412 200701 2 008',
    room: 'Ruang Kelas X-7',
    day: 'Kamis',
    startTime: '11.00',
    endTime: '12.30',
    category: 'Peminatan',
    color: 'cyan',
    description: 'Konsep kelangkaan, literasi keuangan siswa, pasar dan elastisitas harga, serta sistem perbankan.',
    currentTopic: 'Literasi Keuangan: Pengelolaan Budget Pribadi & Instrumen Investasi Aman',
    syllabusTopics: ['Konsep Ilmu Ekonomi & Kelangkaan', 'Pelaku Kegiatan Ekonomi', 'Permintaan dan Penawaran', 'Bank & Lembaga Keuangan'],
    referenceBooks: ['Ekonomi SMA Kelas X - Grafindo Media Pratama']
  },

  // JUMAT
  {
    id: 'sub-fri-1',
    code: 'PAI-1',
    name: 'Pendidikan Agama & Budi Pekerti',
    teacher: 'Ustadz H. Ahmad Zaki, Lc, M.A',
    teacherNip: '19790815 200501 1 009',
    room: 'Masjid Sekolah & Kelas X-7',
    day: 'Jumat',
    startTime: '07.00',
    endTime: '08.45',
    category: 'Wajib',
    color: 'emerald',
    description: 'Penguatan aqidah, akhlak mulia, pemahaman toleransi beragama, dan fiqih muamalah.',
    currentTopic: 'Meniti Hidup dengan Kemuliaan: Adab Menuntut Ilmu dan Berbakti kepada Orang Tua',
    syllabusTopics: ['Qur\'an dan Hadits Pilihan', 'Asmaul Husna', 'Akhlak Terpuji', 'Toleransi Beragama'],
    referenceBooks: ['Pendidikan Agama Islam dan Budi Pekerti Kelas X']
  },
  {
    id: 'sub-fri-2',
    code: 'BJW-1',
    name: 'Bahasa & Sastra Daerah',
    teacher: 'Ki Purwadi, S.Pd',
    teacherNip: '19750201 200103 1 004',
    room: 'Ruang Kelas X-7',
    day: 'Jumat',
    startTime: '09.00',
    endTime: '10.30',
    category: 'Muatan Lokal',
    color: 'amber',
    description: 'Unggah-ungguh basa, aksara daerah, dan kearifan lokal sastra tradisional.',
    currentTopic: 'Aksara Tradisional: Sandhangan & Pasangan dalam Penulisan Kalimat',
    syllabusTopics: ['Unggah-Ungguh Basa', 'Aksara Tradisional', 'Tembang Macapat', 'Cerita Wayang'],
    referenceBooks: ['Kirtya Basa SMA Kelas X']
  },
  {
    id: 'sub-fri-3',
    code: 'WAK-1',
    name: 'Bimbingan Konseling & Jam Wali Kelas',
    teacher: 'Dra. Hj. Siti Nurhaliza, M.Pd / Guru BK',
    teacherNip: '19720415 199803 2 004',
    room: 'Ruang Kelas X-7',
    day: 'Jumat',
    startTime: '10.30',
    endTime: '11.30',
    category: 'Pengembangan Diri',
    color: 'indigo',
    description: 'Evaluasi mingguan kelas, konsultasi karier/minat bakat, penguatan motivasi belajar, dan koordinasi kebersihan.',
    currentTopic: 'Manajemen Waktu Belajar & Persiapan Penilaian Tengah Semester (PTS)',
    syllabusTopics: ['Self-Management', 'Perencanaan Studi Lanjut', 'Resolusi Konflik Kelas', 'Evaluasi Kekompakan'],
    referenceBooks: ['Modul Bimbingan Konseling Remaja']
  }
];

export const INITIAL_HOMEWORKS: HomeworkNote[] = [
  {
    id: 'hw-1',
    subject: 'Matematika Wajib',
    title: 'Latihan Soal SPLTV & Metode Gabungan Eliminasi-Substitusi',
    dateGiven: '2026-08-25',
    dueDate: '2026-09-01',
    description: 'Kerjakan soal latihan di Buku Paket halaman 84 Nomor 1 s.d. 8 bagian B. Tulis langkah penyelesaian lengkap di buku tugas berpetak.',
    priority: 'Tinggi',
    status: 'Sedang Dikerjakan',
    submissionType: 'Buku Tugas',
    tags: ['SPLTV', 'Buku Paket', 'Wajib']
  },
  {
    id: 'hw-2',
    subject: 'Fisika',
    title: 'Laporan Praktikum Gerak Lurus Beraturan (GLB) & GLBB Ticker Timer',
    dateGiven: '2026-08-26',
    dueDate: '2026-09-02',
    description: 'Buat laporan resmi praktikum lengkap dengan data tabel pita ketik, grafik kecepatan vs waktu, analisa kesalahan, dan kesimpulan kelompok.',
    priority: 'Tinggi',
    status: 'Belum Selesai',
    submissionType: 'Google Classroom',
    tags: ['Laporan', 'Kelompok', 'Lab Fisika']
  },
  {
    id: 'hw-3',
    subject: 'Bahasa Indonesia',
    title: 'Penyusunan Draf Teks Laporan Hasil Observasi (LHO) Lingkungan Sekolah',
    dateGiven: '2026-08-28',
    dueDate: '2026-09-04',
    description: 'Tulis teks LHO minimal 4 paragraf dengan struktur: Pernyataan Umum, Deskripsi Bagian, dan Deskripsi Manfaat. Objek: Kantin Sehat / Lab Komputer.',
    priority: 'Sedang',
    status: 'Belum Selesai',
    submissionType: 'Buku Tugas',
    tags: ['Teks LHO', 'Individu']
  },
  {
    id: 'hw-4',
    subject: 'Informatika',
    title: 'Mini Proyek Koding: Program Kalkulator Nilai Siswa Python',
    dateGiven: '2026-08-27',
    dueDate: '2026-09-05',
    description: 'Buat program python yang menerima input nama, nilai tugas, UTS, UAS, lalu menghitung nilai akhir beserta huruf mutu (A/B/C/D). Unggah file .py ke repo/drive.',
    priority: 'Sedang',
    status: 'Selesai',
    submissionType: 'Google Classroom',
    tags: ['Python', 'Koding', 'Lab Komputer']
  },
  {
    id: 'hw-5',
    subject: 'Biologi',
    title: 'Mind Mapping Struktur Morfologi Virus dan Daur Litik vs Lisogenik',
    dateGiven: '2026-08-28',
    dueDate: '2026-09-07',
    description: 'Gambar mind mapping berwarna di kertas karton A3 / buku gambar. Lengkapi dengan keterangan bagian kapsid, asam nukleat, leher, dan serabut ekor.',
    priority: 'Rendah',
    status: 'Belum Selesai',
    submissionType: 'Proyek Fisik',
    tags: ['Kreatif', 'MindMap', 'Virus']
  }
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: '🚨 PENGUMUMAN MENDESAK: Kelengkapan Atribut Upacara & Razia Kerapian Besok Pagi',
    content: 'Dihimbau kepada SELURUH siswa kelas X-7.26 bahwa besok pagi ada upacara bendera gabungan sekaligus pemeriksaan tata tertib sekolah oleh Tim Kesiswaan. WAJIB memakai seragam putih abu-abu lengkap: dasi, sabuk hitam resmi, kaos kaki putih di atas mata kaki, sepatu hitam polos, dan topi sekolah. Yang rambutnya panjang harap dipotong rapi sore ini.',
    sender: 'Ketua Kelas',
    senderName: 'Muhammad Rayhan Al-Fatih',
    date: '2026-08-29 14:30',
    isUrgent: true,
    category: 'Mendesak',
    attachmentName: 'Tata_Tertib_Seragam_Siswa.pdf'
  },
  {
    id: 'ann-2',
    title: '📢 Pembayaran Iuran Kas Kelas Bulan Ini & Pembelian Dispenser Galon',
    content: 'Teman-teman X-7.26, bagi yang belum melunasi kas kelas bulan Agustus (Rp 20.000 / 4 pekan), mohon segera disetorkan ke Bendahara 1 (Jessica) atau Bendahara 2 (Nurul) maksimal hari Rabu ini. Uang kas akan dialokasikan untuk pengadaan galon air minum kelas dan perlengkapan kebersihan.',
    sender: 'Bendahara',
    senderName: 'Jessica Amanda Siregar',
    date: '2026-08-28 09:15',
    isUrgent: false,
    category: 'Keuangan'
  },
  {
    id: 'ann-3',
    title: '📌 Pesan Wali Kelas: Persiapan Penilaian Tengah Semester (PTS) Gasal',
    content: 'Anak-anakku kelas X-7.26 yang hebat, jadwal PTS Gasal akan dimulai dalam waktu 2 minggu lagi. Pastikan semua catatan materi dan tugas-tugas guru mata pelajaran sudah dilengkapi tanpa ada yang menunggak. Jika ada kesulitan materi, silakan hubungi Bu Siti atau manfaatkan kelompok belajar teman sebaya. Tetap jaga kesehatan dan semangat!',
    sender: 'Wali Kelas',
    senderName: 'Dra. Hj. Siti Nurhaliza, M.Pd',
    date: '2026-08-27 16:45',
    isUrgent: true,
    category: 'Akademik'
  }
];

export const INITIAL_CLASS_NOTES: ClassImportantNote[] = [
  {
    id: 'note-1',
    title: 'Tata Tertib Khusus Kelas X-7.26',
    category: 'Tata Tertib',
    content: '1. Masuk kelas paling lambat pukul 06.45 WIB.\n2. Piket pagi harus selesai sebelum bel berbunyi pukul 07.00 WIB.\n3. Dilarang meninggalkan sampah di dalam laci meja.\n4. Handphone dimasukkan ke loker HP selama KBM berlangsung kecuali ada instruksi dari guru pengajar.\n5. Menjaga ketenangan dan saling menghargai pendapat sesama teman.',
    dateUpdated: '2026-08-25',
    pinned: true,
    author: 'Pengurus Kelas',
    color: 'border-blue-500 bg-blue-50/70'
  },
  {
    id: 'note-2',
    title: 'Link Drive & Bank Soal Kelas X-7.26',
    category: 'Akademik',
    content: 'Kumpulan slide guru, modul rangkuman, ebook perpustakaan, dan bank soal latihan dapat diakses melalui link Google Drive bersama kelas: drive.google.com/drive/folders/x7-26-official. Silakan unduh materi sebelum jadwal pelajaran dimulai.',
    dateUpdated: '2026-08-26',
    pinned: true,
    author: 'Sekretaris 2 (Marsha)',
    color: 'border-emerald-500 bg-emerald-50/70'
  },
  {
    id: 'note-3',
    title: 'Informasi Kas & Rekening Resmi Kelas',
    category: 'Keuangan',
    content: 'Iuran kas: Rp 5.000 / minggu (Ditarik setiap hari Rabu).\nSaldo Kas saat ini: Rp 485.000 (Transparan & dapat dicek di tabel rekap Bendahara).\nPengeluaran terdekat: Isi ulang galon air minum & spidol whiteboard snowman 1 pack.',
    dateUpdated: '2026-08-28',
    pinned: false,
    author: 'Bendahara 1 (Jessica)',
    color: 'border-amber-500 bg-amber-50/70'
  },
  {
    id: 'note-4',
    title: 'Agenda Class Meeting & Lomba Kebersihan Kelas',
    category: 'Kegiatan',
    content: 'Bulan depan sekolah mengadakan Lomba Kebersihan & Estetika Ruang Kelas tingkat kelas X. Mohon partisipasi aktif setiap seksi piket dan seluruh siswa untuk merawat tanaman, poster mading, serta menjaga kebersihan lantai setiap hari.',
    dateUpdated: '2026-08-24',
    pinned: false,
    author: 'Ketua Kelas',
    color: 'border-purple-500 bg-purple-50/70'
  }
];

export const INITIAL_WEBSITE_SETTINGS: WebsiteSettings = {
  heroTitle: 'Setiap prestasi hebat dimulai dari Kelas X-7.26.',
  heroSubtitle: 'Ruang portal terpadu untuk monitoring absensi 35 siswa, jadwal piket Senin s.d. Jum\'at, struktur kepengurusan, jadwal mata pelajaran & info silabus, catatan deadline PR, serta pengumuman penting wali kelas.',
  classTagline: 'Solidaritas Tanpa Batas, Berprestasi dengan Integritas',
  schoolYear: 'Tahun Ajaran 2026/2027',
  accentColor: '#1E1B4B'
};
