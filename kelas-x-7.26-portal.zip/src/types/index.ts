export type AttendanceStatus = 'hadir' | 'sakit' | 'izin' | 'alpa';

export type UserRole = 'student' | 'admin';

export interface UserSession {
  role: UserRole;
  name: string;
  avatar?: string;
  studentId?: string;
  officerRole?: string;
  lastLogin?: string;
}

export interface WebsiteSettings {
  heroTitle: string;
  heroSubtitle: string;
  classTagline: string;
  schoolYear: string;
  accentColor?: string;
}

export interface Student {
  id: string;
  nisn: string;
  name: string;
  gender: 'L' | 'P';
  attendanceStatus: AttendanceStatus;
  notes?: string;
  avatarBg?: string;
  email?: string;
  phone?: string;
}

export interface AttendanceSummary {
  hadir: number;
  sakit: number;
  izin: number;
  alpa: number;
  total: number;
  percentage: number;
}

export type DayOfWeek = 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat';

export interface PiketTask {
  id: string;
  label: string;
  completed: boolean;
}

export interface PiketDaySchedule {
  day: DayOfWeek;
  coordinator: string;
  members: string[];
  tasks: PiketTask[];
  cleanlinessScore?: number;
}

export interface Officer {
  id: string;
  role: string;
  name: string;
  nickname?: string;
  avatar: string;
  description: string;
  contact?: string;
  tasks: string[];
  quote?: string;
}

export interface SectionDepartment {
  name: string;
  icon: string;
  coordinator: string;
  members: string[];
  duties: string[];
}

export interface ClassStructure {
  waliKelas: Officer;
  ketuaKelas: Officer;
  wakilKetua: Officer;
  sekretaris1: Officer;
  sekretaris2: Officer;
  bendahara1: Officer;
  bendahara2: Officer;
  departments: SectionDepartment[];
  motto: string;
  visi: string;
}

export interface SubjectItem {
  id: string;
  code: string;
  name: string;
  teacher: string;
  teacherNip?: string;
  room: string;
  day: DayOfWeek;
  startTime: string;
  endTime: string;
  category: 'Wajib' | 'Peminatan' | 'Muatan Lokal' | 'Pengembangan Diri';
  color: string;
  description: string;
  currentTopic: string;
  syllabusTopics: string[];
  referenceBooks: string[];
  classroomLink?: string;
}

export interface HomeworkNote {
  id: string;
  subject: string;
  title: string;
  dateGiven: string;
  dueDate: string;
  description: string;
  priority: 'Tinggi' | 'Sedang' | 'Rendah';
  status: 'Belum Selesai' | 'Sedang Dikerjakan' | 'Selesai';
  submissionType: 'Buku Tugas' | 'Google Classroom' | 'Presentasi' | 'Proyek Fisik';
  tags: string[];
}

export type AnnouncementSender = 'Wali Kelas' | 'Ketua Kelas' | 'Sekretaris' | 'Bendahara' | 'Pengurus Kelas';

export interface Announcement {
  id: string;
  title: string;
  content: string;
  sender: AnnouncementSender;
  senderName: string;
  date: string;
  isUrgent: boolean;
  category: 'Mendesak' | 'Akademik' | 'Kegiatan' | 'Keuangan' | 'Tata Tertib';
  attachmentName?: string;
}

export interface ClassImportantNote {
  id: string;
  title: string;
  category: string;
  content: string;
  dateUpdated: string;
  pinned: boolean;
  author: string;
  color?: string;
}

export type AdminRoleTitle = 'Wali Kelas' | 'Perangkat Kelas' | 'Admin Website';

export interface VisitorLog {
  id: string;
  timestamp: string; // ISO string
  name: string;
  role: 'admin' | 'student';
  roleTitle: 'Wali Kelas' | 'Perangkat Kelas' | 'Admin Website' | 'Siswa';
  studentId?: string;
  nisn?: string;
  device: 'Desktop' | 'Mobile' | 'Tablet';
  browser: string;
  action: 'Login Admin' | 'Login Siswa' | 'Kunjungan Halaman';
  dateStr: string; // YYYY-MM-DD
  timeStr: string; // HH:mm:ss
  monthKey: string; // YYYY-MM
}

export interface MonthlyRecap {
  id: string;
  monthKey: string; // e.g. "2026-08"
  monthLabel: string; // e.g. "Agustus 2026"
  generatedAt: string; // ISO string
  totalVisits: number;
  studentVisits: number;
  adminVisits: number;
  waliKelasVisits: number;
  perangkatVisits: number;
  adminWebVisits: number;
  uniqueVisitors: number;
  peakDay: string;
  statusNote: string;
  topUsers: { name: string; count: number; role: string }[];
  dailyTrend: { date: string; label: string; siswa: number; admin: number; total: number }[];
  isArchived: boolean;
}
