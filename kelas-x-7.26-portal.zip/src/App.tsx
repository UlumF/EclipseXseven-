/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Student, 
  PiketDaySchedule, 
  ClassStructure, 
  SubjectItem, 
  HomeworkNote, 
  Announcement, 
  ClassImportantNote,
  DayOfWeek,
  AttendanceStatus,
  UserSession,
  WebsiteSettings
} from './types';
import { 
  INITIAL_STUDENTS, 
  INITIAL_PIKET, 
  INITIAL_STRUCTURE, 
  INITIAL_SCHEDULE, 
  INITIAL_HOMEWORKS, 
  INITIAL_ANNOUNCEMENTS, 
  INITIAL_CLASS_NOTES,
  INITIAL_WEBSITE_SETTINGS
} from './data/initialData';

import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AppWindowContainer } from './components/AppWindowContainer';
import { DashboardOverview } from './components/views/DashboardOverview';
import { AttendanceView } from './components/views/AttendanceView';
import { PiketView } from './components/views/PiketView';
import { StructureView } from './components/views/StructureView';
import { ScheduleView } from './components/views/ScheduleView';
import { HomeworkView } from './components/views/HomeworkView';
import { AnnouncementView } from './components/views/AnnouncementView';
import { QuickAddModal } from './components/QuickAddModal';
import { LoginModal } from './components/LoginModal';
import { StudentManageModal } from './components/StudentManageModal';
import { WebsiteCustomizerModal } from './components/WebsiteCustomizerModal';

export default function App() {
  // Auth & Role State (Password: X720262027)
  const [session, setSession] = useState<UserSession>(() => {
    const saved = localStorage.getItem('x726_auth_session');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {
      role: 'student',
      name: 'Siswa X-7.26'
    };
  });

  // Website Settings State
  const [settings, setSettings] = useState<WebsiteSettings>(() => {
    const saved = localStorage.getItem('x726_website_settings');
    return saved ? JSON.parse(saved) : INITIAL_WEBSITE_SETTINGS;
  });

  // Local storage synced state
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('x726_students');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter((s: Student) => s.id !== '36' && s.name !== 'Zahra Amelia Santoso');
        }
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_STUDENTS;
  });

  const [piketSchedule, setPiketSchedule] = useState<PiketDaySchedule[]>(() => {
    const saved = localStorage.getItem('x726_piket');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.map((p: PiketDaySchedule) => ({
            ...p,
            members: p.members.filter((m: string) => m !== 'Zahra Amelia Santoso')
          }));
        }
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_PIKET;
  });

  const [structure, setStructure] = useState<ClassStructure>(() => {
    const saved = localStorage.getItem('x726_structure');
    return saved ? JSON.parse(saved) : INITIAL_STRUCTURE;
  });

  const [schedule, setSchedule] = useState<SubjectItem[]>(() => {
    const saved = localStorage.getItem('x726_schedule');
    return saved ? JSON.parse(saved) : INITIAL_SCHEDULE;
  });

  const [homeworks, setHomeworks] = useState<HomeworkNote[]>(() => {
    const saved = localStorage.getItem('x726_homeworks');
    return saved ? JSON.parse(saved) : INITIAL_HOMEWORKS;
  });

  const [announcements, setAnnouncements] = useState<Announcement[]>(() => {
    const saved = localStorage.getItem('x726_announcements');
    return saved ? JSON.parse(saved) : INITIAL_ANNOUNCEMENTS;
  });

  const [classNotes, setClassNotes] = useState<ClassImportantNote[]>(() => {
    const saved = localStorage.getItem('x726_classnotes');
    return saved ? JSON.parse(saved) : INITIAL_CLASS_NOTES;
  });

  // Active Tab state & Modals
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [loginModalTab, setLoginModalTab] = useState<'auth' | 'analytics'>('auth');
  const [isStudentManageOpen, setIsStudentManageOpen] = useState<boolean>(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState<boolean>(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState<boolean>(false);

  const isAdmin = session.role === 'admin';

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('x726_auth_session', JSON.stringify(session));
  }, [session]);

  useEffect(() => {
    localStorage.setItem('x726_website_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('x726_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('x726_piket', JSON.stringify(piketSchedule));
  }, [piketSchedule]);

  useEffect(() => {
    localStorage.setItem('x726_structure', JSON.stringify(structure));
  }, [structure]);

  useEffect(() => {
    localStorage.setItem('x726_schedule', JSON.stringify(schedule));
  }, [schedule]);

  useEffect(() => {
    localStorage.setItem('x726_homeworks', JSON.stringify(homeworks));
  }, [homeworks]);

  useEffect(() => {
    localStorage.setItem('x726_announcements', JSON.stringify(announcements));
  }, [announcements]);

  useEffect(() => {
    localStorage.setItem('x726_classnotes', JSON.stringify(classNotes));
  }, [classNotes]);

  // Auth Handlers
  const handleLogin = (newSession: UserSession) => {
    setSession(newSession);
  };

  const handleLogout = () => {
    setSession({
      role: 'student',
      name: 'Siswa X-7.26'
    });
  };

  // Student CRUD Handlers (For Admin)
  const handleAddStudent = (newStudentData: Omit<Student, 'id'>) => {
    const newStudent: Student = {
      ...newStudentData,
      id: `student-${Date.now()}`
    };
    setStudents((prev) => [...prev, newStudent]);
  };

  const handleUpdateStudent = (id: string, updatedData: Partial<Student>) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updatedData } : s))
    );
  };

  const handleDeleteStudent = (id: string) => {
    setStudents((prev) => prev.filter((s) => s.id !== id));
  };

  const handleResetStudentsToZero = () => {
    setStudents([]);
  };

  // Attendance Handlers
  const handleUpdateAttendanceStatus = (
    studentId: string, 
    status: AttendanceStatus, 
    notes?: string
  ) => {
    setStudents((prev) =>
      prev.map((s) =>
        s.id === studentId
          ? { ...s, attendanceStatus: status, ...(notes !== undefined ? { notes } : {}) }
          : s
      )
    );
  };

  const handleMarkAllPresent = () => {
    setStudents((prev) =>
      prev.map((s) => ({ ...s, attendanceStatus: 'hadir' }))
    );
  };

  const handleResetAttendance = () => {
    setStudents((prev) =>
      prev.map((s) => ({ ...s, attendanceStatus: 'hadir', notes: undefined }))
    );
  };

  // Website Settings & Structure Handlers (For Admin)
  const handleSaveSettings = (newSettings: WebsiteSettings) => {
    setSettings(newSettings);
  };

  const handleSaveStructure = (newStructure: ClassStructure) => {
    setStructure(newStructure);
  };

  const handleClearStructure = () => {
    setStructure(INITIAL_STRUCTURE);
  };

  const handleResetWebsiteSettings = () => {
    setSettings(INITIAL_WEBSITE_SETTINGS);
    setStructure(INITIAL_STRUCTURE);
  };

  // Piket Handlers
  const handleTogglePiketTask = (day: DayOfWeek, taskId: string) => {
    setPiketSchedule((prev) =>
      prev.map((p) => {
        if (p.day === day) {
          const updatedTasks = p.tasks.map((t) =>
            t.id === taskId ? { ...t, completed: !t.completed } : t
          );
          return { ...p, tasks: updatedTasks };
        }
        return p;
      })
    );
  };

  const handleAddPiketTask = (day: DayOfWeek, label: string) => {
    setPiketSchedule((prev) =>
      prev.map((p) => {
        if (p.day === day) {
          const newTask = {
            id: `custom-task-${Date.now()}`,
            label,
            completed: false
          };
          return { ...p, tasks: [...p.tasks, newTask] };
        }
        return p;
      })
    );
  };

  const handleDeletePiketTask = (day: DayOfWeek, taskId: string) => {
    setPiketSchedule((prev) =>
      prev.map((p) => {
        if (p.day === day) {
          return { ...p, tasks: p.tasks.filter((t) => t.id !== taskId) };
        }
        return p;
      })
    );
  };

  const handleUpdatePiketDaySchedule = (day: DayOfWeek, updated: Partial<PiketDaySchedule>) => {
    setPiketSchedule((prev) =>
      prev.map((p) => (p.day === day ? { ...p, ...updated } : p))
    );
  };

  const handleSwapPiketMembers = (
    dayA: DayOfWeek, 
    memberA: string, 
    dayB: DayOfWeek, 
    memberB: string
  ) => {
    setPiketSchedule((prev) =>
      prev.map((p) => {
        if (p.day === dayA) {
          const newMembers = p.members.map((m) => (m === memberA ? memberB : m));
          return { ...p, members: newMembers };
        }
        if (p.day === dayB) {
          const newMembers = p.members.map((m) => (m === memberB ? memberA : m));
          return { ...p, members: newMembers };
        }
        return p;
      })
    );
  };

  // Schedule Handlers (Admin Mapel)
  const handleAddSubject = (newSubject: Omit<SubjectItem, 'id'>) => {
    const subjectItem: SubjectItem = {
      ...newSubject,
      id: `mapel-${Date.now()}`
    };
    setSchedule((prev) => [...prev, subjectItem]);
  };

  const handleUpdateSubject = (id: string, updated: Partial<SubjectItem>) => {
    setSchedule((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updated } : s))
    );
  };

  const handleDeleteSubject = (id: string) => {
    setSchedule((prev) => prev.filter((s) => s.id !== id));
  };

  // Homework Handlers
  const handleAddHomework = (hw: Omit<HomeworkNote, 'id'>) => {
    const newHw: HomeworkNote = {
      ...hw,
      id: `hw-${Date.now()}`
    };
    setHomeworks((prev) => [newHw, ...prev]);
  };

  const handleUpdateHomeworkStatus = (id: string, status: HomeworkNote['status']) => {
    setHomeworks((prev) =>
      prev.map((h) => (h.id === id ? { ...h, status } : h))
    );
  };

  const handleDeleteHomework = (id: string) => {
    setHomeworks((prev) => prev.filter((h) => h.id !== id));
  };

  // Announcement Handlers
  const handleAddAnnouncement = (ann: Omit<Announcement, 'id'>) => {
    const newAnn: Announcement = {
      ...ann,
      id: `ann-${Date.now()}`
    };
    setAnnouncements((prev) => [newAnn, ...prev]);
  };

  const handleDeleteAnnouncement = (id: string) => {
    setAnnouncements((prev) => prev.filter((a) => a.id !== id));
  };

  // Class Notes Handlers
  const handleAddClassNote = (note: Omit<ClassImportantNote, 'id'>) => {
    const newNote: ClassImportantNote = {
      ...note,
      id: `note-${Date.now()}`
    };
    setClassNotes((prev) => [newNote, ...prev]);
  };

  const handleDeleteClassNote = (id: string) => {
    setClassNotes((prev) => prev.filter((n) => n.id !== id));
  };

  const urgentCount = announcements.filter((a) => a.isUrgent).length;
  const primaryUrgent = announcements.find((a) => a.isUrgent);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-indigo-500 selection:text-white">
      
      {/* 1. Header & Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        urgentCount={urgentCount}
        session={session}
        onOpenLogin={() => {
          setLoginModalTab('auth');
          setIsLoginModalOpen(true);
        }}
        onOpenVisitorLogs={() => {
          setLoginModalTab('analytics');
          setIsLoginModalOpen(true);
        }}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
        onOpenStudentManage={() => setIsStudentManageOpen(true)}
        openAddModal={() => setIsQuickAddOpen(true)}
      />

      {/* 2. Hero Section */}
      <HeroSection
        settings={settings}
        studentCount={students.length}
        isAdmin={isAdmin}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
        onExplore={() => {
          setActiveTab('pengumuman');
          const el = document.getElementById('window-canvas');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        onViewSchedule={() => {
          setActiveTab('jadwal');
          const el = document.getElementById('window-canvas');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        onViewAttendance={() => {
          setActiveTab('absensi');
          const el = document.getElementById('window-canvas');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        urgentAnnouncement={primaryUrgent ? { title: primaryUrgent.title, sender: primaryUrgent.sender } : null}
      />

      {/* 3. Main Interactive Canvas Mockup Container */}
      <main id="window-canvas" className="flex-1">
        <AppWindowContainer
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          urgentCount={urgentCount}
          session={session}
          onOpenAddModal={() => setIsQuickAddOpen(true)}
          onOpenLogin={() => setIsLoginModalOpen(true)}
          onOpenCustomizer={() => setIsCustomizerOpen(true)}
          onOpenStudentManage={() => setIsStudentManageOpen(true)}
        >
          {activeTab === 'dashboard' && (
            <DashboardOverview
              students={students}
              piketSchedule={piketSchedule}
              schedule={schedule}
              homeworks={homeworks}
              announcements={announcements}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'absensi' && (
            <AttendanceView
              students={students}
              isAdmin={isAdmin}
              onUpdateStatus={handleUpdateAttendanceStatus}
              onMarkAllPresent={handleMarkAllPresent}
              onResetAttendance={handleResetAttendance}
              onDeleteStudent={handleDeleteStudent}
              onResetStudentsToZero={handleResetStudentsToZero}
              onOpenStudentManage={() => setIsStudentManageOpen(true)}
              onOpenLoginModal={() => setIsLoginModalOpen(true)}
            />
          )}

          {activeTab === 'piket' && (
            <PiketView
              piketSchedule={piketSchedule}
              students={students}
              isAdmin={isAdmin}
              onToggleTask={handleTogglePiketTask}
              onAddTask={handleAddPiketTask}
              onDeleteTask={handleDeletePiketTask}
              onUpdatePiketDaySchedule={handleUpdatePiketDaySchedule}
              onSwapMembers={handleSwapPiketMembers}
              onOpenLoginModal={() => setIsLoginModalOpen(true)}
            />
          )}

          {activeTab === 'struktur' && (
            <StructureView 
              structure={structure}
              isAdmin={isAdmin}
              onOpenCustomizer={() => setIsCustomizerOpen(true)}
              onSaveStructure={handleSaveStructure}
              onClearStructure={handleClearStructure}
            />
          )}

          {activeTab === 'jadwal' && (
            <ScheduleView 
              schedule={schedule}
              isAdmin={isAdmin}
              onAddSubject={handleAddSubject}
              onUpdateSubject={handleUpdateSubject}
              onDeleteSubject={handleDeleteSubject}
            />
          )}

          {activeTab === 'pr' && (
            <HomeworkView
              homeworks={homeworks}
              isAdmin={isAdmin}
              onAddHomework={handleAddHomework}
              onUpdateHomeworkStatus={handleUpdateHomeworkStatus}
              onDeleteHomework={handleDeleteHomework}
              onOpenLoginModal={() => setIsLoginModalOpen(true)}
            />
          )}

          {activeTab === 'pengumuman' && (
            <AnnouncementView
              announcements={announcements}
              classNotes={classNotes}
              isAdmin={isAdmin}
              onAddAnnouncement={handleAddAnnouncement}
              onDeleteAnnouncement={handleDeleteAnnouncement}
              onAddClassNote={handleAddClassNote}
              onDeleteClassNote={handleDeleteClassNote}
              onOpenLoginModal={() => setIsLoginModalOpen(true)}
            />
          )}
        </AppWindowContainer>
      </main>

      {/* 4. Modals */}
      {/* Login Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        currentSession={session}
        students={students}
        onLogin={handleLogin}
        onLogout={handleLogout}
        defaultTab={loginModalTab}
      />

      {/* Student Management Modal (Admin) */}
      <StudentManageModal
        isOpen={isStudentManageOpen}
        onClose={() => setIsStudentManageOpen(false)}
        students={students}
        onAddStudent={handleAddStudent}
        onUpdateStudent={handleUpdateStudent}
        onDeleteStudent={handleDeleteStudent}
      />

      {/* Website Customizer Modal (Admin) */}
      <WebsiteCustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        settings={settings}
        structure={structure}
        onSaveSettings={handleSaveSettings}
        onSaveStructure={handleSaveStructure}
        onResetToDefault={handleResetWebsiteSettings}
      />

      {/* Quick Add Floating Modal */}
      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        onAddHomework={handleAddHomework}
        onAddAnnouncement={handleAddAnnouncement}
        onAddClassNote={handleAddClassNote}
      />

      {/* 5. Clean Footer */}
      <footer className="bg-white border-t border-slate-200/80 py-10 mt-12 text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#1E1B4B] text-white flex items-center justify-center font-black text-xs">
              X-7
            </div>
            <div>
              <span className="font-extrabold text-slate-900 text-sm">Kelas X-7.26</span>
              <p className="text-[11px] text-slate-400">Portal Informasi &amp; Administrasi Kelas Terpadu</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 font-semibold text-slate-600">
            <button onClick={() => setActiveTab('absensi')} className="hover:text-indigo-600">
              Absensi ({students.length} Siswa)
            </button>
            <button onClick={() => setActiveTab('piket')} className="hover:text-indigo-600">
              Piket Senin-Jum&apos;at
            </button>
            <button onClick={() => setActiveTab('struktur')} className="hover:text-indigo-600">
              Struktur Organisasi
            </button>
            <button onClick={() => setActiveTab('jadwal')} className="hover:text-indigo-600">
              Jadwal Mapel
            </button>
            <button onClick={() => setActiveTab('pr')} className="hover:text-indigo-600">
              Catatan PR
            </button>
            <button onClick={() => setActiveTab('pengumuman')} className="hover:text-indigo-600">
              Pengumuman Mendesak
            </button>
          </div>

          <div className="text-center md:text-right text-[11px] text-slate-400">
            <span>Dikelola dengan ❤️ oleh Pengurus Kelas X-7.26</span>
            <div className="font-mono mt-0.5">Wali Kelas: {structure.waliKelas.name || '(Belum Diisi)'}</div>
          </div>
        </div>
      </footer>

    </div>
  );
}
