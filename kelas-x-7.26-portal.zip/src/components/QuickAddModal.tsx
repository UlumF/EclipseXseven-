import React, { useState } from 'react';
import { 
  HomeworkNote, 
  Announcement, 
  ClassImportantNote,
  AnnouncementSender 
} from '../types';
import { CheckSquare, AlertTriangle, Pin, X } from 'lucide-react';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddHomework: (hw: Omit<HomeworkNote, 'id'>) => void;
  onAddAnnouncement: (ann: Omit<Announcement, 'id'>) => void;
  onAddClassNote: (note: Omit<ClassImportantNote, 'id'>) => void;
}

export const QuickAddModal: React.FC<QuickAddModalProps> = ({
  isOpen,
  onClose,
  onAddHomework,
  onAddAnnouncement,
  onAddClassNote
}) => {
  const [activeType, setActiveType] = useState<'pr' | 'announcement' | 'note'>('pr');

  // Homework state
  const [hwSubject, setHwSubject] = useState('Matematika Wajib');
  const [hwTitle, setHwTitle] = useState('');
  const [hwDateGiven, setHwDateGiven] = useState(new Date().toISOString().split('T')[0]);
  const [hwDueDate, setHwDueDate] = useState('');
  const [hwDesc, setHwDesc] = useState('');
  const [hwPriority, setHwPriority] = useState<HomeworkNote['priority']>('Sedang');

  // Announcement state
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annSender, setAnnSender] = useState<AnnouncementSender>('Ketua Kelas');
  const [annIsUrgent, setAnnIsUrgent] = useState(true);

  // Note state
  const [noteTitle, setNoteTitle] = useState('');
  const [noteCategory, setNoteCategory] = useState('Akademik');
  const [noteContent, setNoteContent] = useState('');

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    if (activeType === 'pr') {
      if (!hwTitle.trim() || !hwDueDate) return;
      onAddHomework({
        subject: hwSubject,
        title: hwTitle.trim(),
        dateGiven: hwDateGiven,
        dueDate: hwDueDate,
        description: hwDesc.trim() || 'Kerjakan sesuai instruksi guru.',
        priority: hwPriority,
        status: 'Belum Selesai',
        submissionType: 'Buku Tugas',
        tags: [hwSubject]
      });
    } else if (activeType === 'announcement') {
      if (!annTitle.trim() || !annContent.trim()) return;
      const now = new Date();
      const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      
      onAddAnnouncement({
        title: annTitle.trim(),
        content: annContent.trim(),
        sender: annSender,
        senderName: annSender === 'Wali Kelas' ? 'Dra. Hj. Siti Nurhaliza, M.Pd' : 'Muhammad Rayhan Al-Fatih',
        date: formattedDate,
        isUrgent: annIsUrgent,
        category: annIsUrgent ? 'Mendesak' : 'Akademik'
      });
    } else {
      if (!noteTitle.trim() || !noteContent.trim()) return;
      const now = new Date();
      const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      
      onAddClassNote({
        title: noteTitle.trim(),
        category: noteCategory,
        content: noteContent.trim(),
        dateUpdated: formattedDate,
        pinned: true,
        author: 'Pengurus Kelas X-7.26',
        color: 'border-indigo-500 bg-indigo-50/70'
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 relative max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
        >
          <X className="w-4 h-4" />
        </button>

        <h3 className="text-lg font-bold text-slate-900 mb-1">
          Tambah Informasi Baru
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Pilih tipe data yang ingin ditambahkan ke portal kelas X-7.26
        </p>

        {/* Type Selector Tabs */}
        <div className="grid grid-cols-3 gap-2 mb-5">
          <button
            type="button"
            onClick={() => setActiveType('pr')}
            className={`p-2.5 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition ${
              activeType === 'pr'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <CheckSquare className="w-4 h-4" />
            <span>Catatan PR</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveType('announcement')}
            className={`p-2.5 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition ${
              activeType === 'announcement'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Pengumuman</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveType('note')}
            className={`p-2.5 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition ${
              activeType === 'note'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Pin className="w-4 h-4" />
            <span>Catatan Kelas</span>
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-3.5 text-xs sm:text-sm">
          
          {/* PR Form */}
          {activeType === 'pr' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Mata Pelajaran:</label>
                <select
                  value={hwSubject}
                  onChange={(e) => setHwSubject(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value="Matematika Wajib">Matematika Wajib</option>
                  <option value="Fisika">Fisika</option>
                  <option value="Kimia">Kimia</option>
                  <option value="Biologi">Biologi</option>
                  <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                  <option value="Bahasa Inggris">Bahasa Inggris</option>
                  <option value="Informatika">Informatika</option>
                  <option value="Sejarah Indonesia">Sejarah Indonesia</option>
                  <option value="Ekonomi Dasar">Ekonomi Dasar</option>
                  <option value="PPKN">PPKN</option>
                  <option value="PJOK">PJOK</option>
                  <option value="Seni Budaya">Seni Budaya</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Judul Tugas PR:</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Latihan Bab 4 Halaman 80"
                  value={hwTitle}
                  onChange={(e) => setHwTitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Diberikan:</label>
                  <input
                    type="date"
                    required
                    value={hwDateGiven}
                    onChange={(e) => setHwDateGiven(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Batas Deadline:</label>
                  <input
                    type="date"
                    required
                    value={hwDueDate}
                    onChange={(e) => setHwDueDate(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-indigo-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Instruksi Guru:</label>
                <textarea
                  rows={2}
                  placeholder="Keterangan cara pengerjaan..."
                  value={hwDesc}
                  onChange={(e) => setHwDesc(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
            </>
          )}

          {/* Announcement Form */}
          {activeType === 'announcement' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Jabatan Pengirim:</label>
                <select
                  value={annSender}
                  onChange={(e) => setAnnSender(e.target.value as AnnouncementSender)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value="Wali Kelas">Wali Kelas (Dra. Hj. Siti Nurhaliza)</option>
                  <option value="Ketua Kelas">Ketua Kelas (Muhammad Rayhan)</option>
                  <option value="Pengurus Kelas">Pengurus Kelas X-7.26</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Judul Pengumuman:</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Kelengkapan Seragam Upacara Besok"
                  value={annTitle}
                  onChange={(e) => setAnnTitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Isi Pemberitahuan:</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Tuliskan isi pengumuman secara lengkap..."
                  value={annContent}
                  onChange={(e) => setAnnContent(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 flex items-center gap-2">
                <input
                  type="checkbox"
                  id="modal-chk-urgent"
                  checked={annIsUrgent}
                  onChange={(e) => setAnnIsUrgent(e.target.checked)}
                  className="w-4 h-4 text-rose-600 rounded"
                />
                <label htmlFor="modal-chk-urgent" className="text-xs font-bold text-rose-900 cursor-pointer">
                  Tampilkan sebagai Pengumuman Mendesak (Urgent)
                </label>
              </div>
            </>
          )}

          {/* Note Form */}
          {activeType === 'note' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Kategori:</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Tata Tertib / Bank Soal / Kas"
                  value={noteCategory}
                  onChange={(e) => setNoteCategory(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Judul Catatan:</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Aturan Peminjaman Inventaris Kelas"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Isi Catatan:</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Isi catatan poin demi poin..."
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
            </>
          )}

          <div className="mt-5 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-[#1E1B4B] hover:bg-indigo-950 rounded-xl shadow-xs"
            >
              Simpan &amp; Publikasikan
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
