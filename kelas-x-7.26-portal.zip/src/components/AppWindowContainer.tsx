import React from 'react';
import { 
  Layers, 
  Users, 
  Sparkles, 
  BookOpen, 
  Calendar, 
  CheckSquare, 
  Bell, 
  Maximize2, 
  Plus,
  ShieldCheck,
  User,
  Palette,
  UserCog,
  Lock
} from 'lucide-react';
import { UserSession } from '../types';

interface AppWindowContainerProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  children: React.ReactNode;
  urgentCount: number;
  session?: UserSession;
  onOpenAddModal: () => void;
  onOpenLogin?: () => void;
  onOpenCustomizer?: () => void;
  onOpenStudentManage?: () => void;
}

export const AppWindowContainer: React.FC<AppWindowContainerProps> = ({
  activeTab,
  setActiveTab,
  children,
  urgentCount,
  session,
  onOpenAddModal,
  onOpenLogin,
  onOpenCustomizer,
  onOpenStudentManage
}) => {
  const isAdmin = session?.role === 'admin';

  const tabs = [
    { id: 'dashboard', label: 'Ringkasan Kelas', icon: Layers },
    { id: 'absensi', label: 'Absensi Siswa', icon: Users },
    { id: 'piket', label: 'Piket Senin-Jumat', icon: Sparkles },
    { id: 'struktur', label: 'Struktur Organisasi', icon: BookOpen },
    { id: 'jadwal', label: 'Jadwal Mapel', icon: Calendar },
    { id: 'pr', label: 'Catatan PR & Tugas', icon: CheckSquare },
    { id: 'pengumuman', label: 'Pengumuman & Catatan', icon: Bell, badge: urgentCount > 0 ? urgentCount : undefined },
  ];

  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 mb-16">
      
      {/* Outer macOS-style Canvas Frame */}
      <div className="bg-white rounded-2xl sm:rounded-3xl border border-slate-300/80 shadow-2xl shadow-slate-300/50 overflow-hidden transition-all">
        
        {/* Mockup Window Header Bar */}
        <div className="bg-slate-100/90 border-b border-slate-200 px-4 py-3 sm:px-6 sm:py-3.5 flex items-center justify-between gap-4 select-none">
          
          {/* Left: Window Traffic Lights */}
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-400 border border-rose-500/40 inline-block shadow-2xs" />
            <span className="w-3 h-3 rounded-full bg-amber-400 border border-amber-500/40 inline-block shadow-2xs" />
            <span className="w-3 h-3 rounded-full bg-emerald-400 border border-emerald-500/40 inline-block shadow-2xs" />
            
            <div className="hidden sm:flex items-center gap-1.5 ml-4 pl-4 border-l border-slate-200 text-xs font-semibold text-slate-600">
              <span className="text-indigo-600 font-bold">X-7.26</span>
              <span className="text-slate-400">/</span>
              <span className="capitalize">{activeTab} View</span>
            </div>
          </div>

          {/* Center: Title / Breadcrumb */}
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-white px-3 py-1 rounded-full border border-slate-200 shadow-2xs">
            <span className={`w-2 h-2 rounded-full ${isAdmin ? 'bg-indigo-600' : 'bg-emerald-500'} animate-pulse`} />
            <span className="font-bold text-slate-900">
              {isAdmin ? `Admin: ${session?.name}` : 'Sistem Portal Kelas X-7.26'}
            </span>
            <span className="text-[10px] text-slate-400 hidden md:inline">
              {isAdmin ? '(Akses Penuh)' : '(Mode Siswa)'}
            </span>
          </div>

          {/* Right Toolbar Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {isAdmin && (
              <>
                {onOpenCustomizer && (
                  <button
                    onClick={onOpenCustomizer}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition border border-indigo-200/60"
                    title="Ubah Teks & Tampilan Website"
                  >
                    <Palette className="w-3.5 h-3.5 text-indigo-600" />
                    <span className="hidden md:inline">Ubah Tampilan</span>
                  </button>
                )}

                {onOpenStudentManage && (
                  <button
                    onClick={onOpenStudentManage}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition border border-indigo-200/60"
                    title="Kelola & Edit Data Siswa"
                  >
                    <UserCog className="w-3.5 h-3.5 text-indigo-600" />
                    <span className="hidden md:inline">Edit Siswa</span>
                  </button>
                )}

                <button
                  onClick={onOpenAddModal}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition shadow-xs"
                  title="Tambah Catatan atau Pengumuman"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Tambah Data</span>
                </button>
              </>
            )}

            {!isAdmin && onOpenLogin && (
              <button
                onClick={onOpenLogin}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 rounded-lg transition border border-slate-200 shadow-2xs"
              >
                <Lock className="w-3 h-3 text-slate-500" />
                <span>Login Admin</span>
              </button>
            )}

            <button 
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 rounded-lg transition"
              title="Gulir ke Atas"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

        {/* Inner Sub-Toolbar / Segmented Tabs Switcher */}
        <div className="bg-slate-50 border-b border-slate-200/80 px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1 sm:gap-1.5">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;

              return (
                <button
                  key={tab.id}
                  id={`app-tab-${tab.id}`}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-white text-indigo-950 shadow-xs border border-slate-200 font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-rose-500 text-white">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* View Content Canvas Area */}
        <div className="p-4 sm:p-6 lg:p-8 bg-slate-50/60 min-h-[600px]">
          {children}
        </div>

      </div>

    </div>
  );
};
