import React, { useState } from 'react';
import { 
  WebsiteSettings, 
  ClassStructure 
} from '../types';
import { 
  Palette, 
  Type, 
  Sparkles, 
  X, 
  Check, 
  Save, 
  RotateCcw,
  Layout,
  Award,
  Globe,
  CheckCircle2
} from 'lucide-react';

interface WebsiteCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: WebsiteSettings;
  structure: ClassStructure;
  onSaveSettings: (newSettings: WebsiteSettings) => void;
  onSaveStructure: (newStructure: ClassStructure) => void;
  onResetToDefault: () => void;
}

export const WebsiteCustomizerModal: React.FC<WebsiteCustomizerModalProps> = ({
  isOpen,
  onClose,
  settings,
  structure,
  onSaveSettings,
  onSaveStructure,
  onResetToDefault
}) => {
  const [activeTab, setActiveTab] = useState<'hero' | 'structure' | 'theme'>('hero');
  
  // Hero and Branding settings state
  const [heroTitle, setHeroTitle] = useState(settings.heroTitle);
  const [heroSubtitle, setHeroSubtitle] = useState(settings.heroSubtitle);
  const [classTagline, setClassTagline] = useState(settings.classTagline);
  const [schoolYear, setSchoolYear] = useState(settings.schoolYear);

  // Structure / Visi state
  const [motto, setMotto] = useState(structure.motto);
  const [visi, setVisi] = useState(structure.visi);
  const [waliKelasName, setWaliKelasName] = useState(structure.waliKelas.name);
  const [waliKelasDesc, setWaliKelasDesc] = useState(structure.waliKelas.description);
  const [ketuaKelasName, setKetuaKelasName] = useState(structure.ketuaKelas.name);
  const [ketuaKelasDesc, setKetuaKelasDesc] = useState(structure.ketuaKelas.description);
  const [wakilKetuaName, setWakilKetuaName] = useState(structure.wakilKetua.name);

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  if (!isOpen) return null;

  const handleExecuteReset = () => {
    // Defaults from constants
    setHeroTitle('Website Resmi Kelas X-7.26');
    setHeroSubtitle('Ruang digital informasi, absensi, jadwal piket, dan materi silabus kelas X-7');
    setClassTagline('SOLIDARITAS • DISIPLIN • PRESTASI');
    setSchoolYear('Tahun Ajaran 2025/2026');
    setMotto('“Belajar Bersama, Sukses Bersama, Menuju Masa Depan Gemilang”');
    setVisi('Membangun generasi cerdas berakhlak mulia dan berprestasi unggul.');
    setWaliKelasName('Dra. Hj. Nur Hasanah, M.Pd');
    setWaliKelasDesc('Guru Pembina & Pengampu Kimia');
    setKetuaKelasName('Muhammad Rayhan Pratama');
    setKetuaKelasDesc('Koordinator Utama & Disiplin Kelas');
    setWakilKetuaName('Aisyah Putri Azzahra');

    onResetToDefault();
    setShowResetConfirm(false);
  };

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();

    onSaveSettings({
      ...settings,
      heroTitle: heroTitle.trim(),
      heroSubtitle: heroSubtitle.trim(),
      classTagline: classTagline.trim(),
      schoolYear: schoolYear.trim()
    });

    onSaveStructure({
      ...structure,
      motto: motto.trim(),
      visi: visi.trim(),
      waliKelas: {
        ...structure.waliKelas,
        name: waliKelasName.trim(),
        description: waliKelasDesc.trim()
      },
      ketuaKelas: {
        ...structure.ketuaKelas,
        name: ketuaKelasName.trim(),
        description: ketuaKelasDesc.trim()
      },
      wakilKetua: {
        ...structure.wakilKetua,
        name: wakilKetuaName.trim()
      }
    });

    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-6 sm:p-7 border border-slate-200 relative max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-indigo-600 to-purple-700 text-white rounded-2xl shadow-xs">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-slate-900">
                  Ubah Teks &amp; Tampilan Website
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200 rounded-md">
                  Akses Admin
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Kustomisasi teks banner, visi, motto kelas, dan identitas pengurus
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-2xl my-3.5">
          <button
            type="button"
            onClick={() => setActiveTab('hero')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              activeTab === 'hero'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Type className="w-3.5 h-3.5" />
            <span>Teks Banner &amp; Header</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('structure')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              activeTab === 'structure'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Visi, Motto &amp; Pengurus</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSaveAll} className="flex-1 overflow-y-auto pr-1 py-1 space-y-4 text-xs sm:text-sm">
          
          {/* TAB 1: HERO & BRANDING */}
          {activeTab === 'hero' && (
            <div className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Judul Utama Hero (Headline):
                </label>
                <textarea
                  rows={2}
                  required
                  value={heroTitle}
                  onChange={(e) => setHeroTitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Subjudul Penjelas Hero:
                </label>
                <textarea
                  rows={3}
                  required
                  value={heroSubtitle}
                  onChange={(e) => setHeroSubtitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tagline Resmi Kelas:
                  </label>
                  <input
                    type="text"
                    required
                    value={classTagline}
                    onChange={(e) => setClassTagline(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tahun Ajaran:
                  </label>
                  <input
                    type="text"
                    required
                    value={schoolYear}
                    onChange={(e) => setSchoolYear(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: VISI, MOTTO & PENGURUS */}
          {activeTab === 'structure' && (
            <div className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Motto Kelas X-7.26:
                </label>
                <input
                  type="text"
                  required
                  value={motto}
                  onChange={(e) => setMotto(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-indigo-950 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Visi Kelas:
                </label>
                <textarea
                  rows={2}
                  required
                  value={visi}
                  onChange={(e) => setVisi(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Wali Kelas:
                  </label>
                  <input
                    type="text"
                    required
                    value={waliKelasName}
                    onChange={(e) => setWaliKelasName(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Deskripsi Wali Kelas:
                  </label>
                  <input
                    type="text"
                    value={waliKelasDesc}
                    onChange={(e) => setWaliKelasDesc(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Ketua Kelas:
                  </label>
                  <input
                    type="text"
                    required
                    value={ketuaKelasName}
                    onChange={(e) => setKetuaKelasName(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Wakil Ketua:
                  </label>
                  <input
                    type="text"
                    required
                    value={wakilKetuaName}
                    onChange={(e) => setWakilKetuaName(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="text-xs text-slate-500 hover:text-rose-600 flex items-center gap-1 font-semibold hover:bg-rose-50 px-2.5 py-1.5 rounded-lg transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Teks Default</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs flex items-center gap-1.5"
              >
                {savedSuccess ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-300 animate-bounce" />
                    <span>Tersimpan!</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Simpan &amp; Terapkan Tampilan</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {/* Reset Confirmation Modal */}
        {showResetConfirm && (
          <div className="fixed inset-0 z-60 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 animate-in fade-in zoom-in-95">
              <div className="flex items-center gap-2.5 text-indigo-600 mb-2.5">
                <div className="p-2 bg-indigo-50 rounded-xl">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Reset Teks Website?</h4>
                  <span className="text-[11px] text-slate-500">Kembalikan Pengaturan Asli</span>
                </div>
              </div>

              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                Kembalikan semua teks banner hero, moto kelas, visi, dan identitas pengurus ke pengaturan bawaan default?
              </p>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(false)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleExecuteReset}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Ya, Reset Sekarang
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
