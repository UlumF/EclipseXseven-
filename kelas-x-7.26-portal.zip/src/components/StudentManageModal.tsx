import React, { useState } from 'react';
import { 
  Student, 
  AttendanceStatus 
} from '../types';
import { 
  Users, 
  UserPlus, 
  Edit3, 
  Trash2, 
  X, 
  Check, 
  AlertCircle, 
  Search,
  Sparkles,
  Phone,
  Mail,
  FileText
} from 'lucide-react';

interface StudentManageModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  onAddStudent: (student: Omit<Student, 'id'>) => void;
  onUpdateStudent: (id: string, updated: Partial<Student>) => void;
  onDeleteStudent: (id: string) => void;
}

const AVATAR_COLORS = [
  'bg-blue-600',
  'bg-indigo-600',
  'bg-rose-600',
  'bg-emerald-600',
  'bg-amber-600',
  'bg-purple-600',
  'bg-teal-600',
  'bg-pink-600',
  'bg-cyan-600',
  'bg-violet-600'
];

export const StudentManageModal: React.FC<StudentManageModalProps> = ({
  isOpen,
  onClose,
  students,
  onAddStudent,
  onUpdateStudent,
  onDeleteStudent
}) => {
  const [activeTab, setActiveTab] = useState<'list' | 'add' | 'edit'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStudentToEdit, setSelectedStudentToEdit] = useState<Student | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<{ id: string; name: string } | null>(null);

  // Add / Edit Form State
  const [formName, setFormName] = useState('');
  const [formNisn, setFormNisn] = useState('');
  const [formGender, setFormGender] = useState<'L' | 'P'>('L');
  const [formStatus, setFormStatus] = useState<AttendanceStatus>('hadir');
  const [formNotes, setFormNotes] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formAvatarBg, setFormAvatarBg] = useState('bg-blue-600');

  if (!isOpen) return null;

  const handleOpenEdit = (student: Student) => {
    setSelectedStudentToEdit(student);
    setFormName(student.name);
    setFormNisn(student.nisn);
    setFormGender(student.gender);
    setFormStatus(student.attendanceStatus);
    setFormNotes(student.notes || '');
    setFormPhone(student.phone || '');
    setFormEmail(student.email || '');
    setFormAvatarBg(student.avatarBg || 'bg-blue-600');
    setActiveTab('edit');
  };

  const handleOpenAdd = () => {
    setSelectedStudentToEdit(null);
    setFormName('');
    const nextNisn = `007123${String(students.length + 1).padStart(4, '0')}`;
    setFormNisn(nextNisn);
    setFormGender('L');
    setFormStatus('hadir');
    setFormNotes('');
    setFormPhone('');
    setFormEmail('');
    setFormAvatarBg(AVATAR_COLORS[students.length % AVATAR_COLORS.length]);
    setActiveTab('add');
  };

  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formNisn.trim()) return;

    if (activeTab === 'edit' && selectedStudentToEdit) {
      onUpdateStudent(selectedStudentToEdit.id, {
        name: formName.trim(),
        nisn: formNisn.trim(),
        gender: formGender,
        attendanceStatus: formStatus,
        notes: formNotes.trim() || undefined,
        phone: formPhone.trim() || undefined,
        email: formEmail.trim() || undefined,
        avatarBg: formAvatarBg
      });
      setActiveTab('list');
      setSelectedStudentToEdit(null);
    } else if (activeTab === 'add') {
      onAddStudent({
        name: formName.trim(),
        nisn: formNisn.trim(),
        gender: formGender,
        attendanceStatus: formStatus,
        notes: formNotes.trim() || undefined,
        phone: formPhone.trim() || undefined,
        email: formEmail.trim() || undefined,
        avatarBg: formAvatarBg
      });
      setActiveTab('list');
    }
  };

  const handleDelete = (id: string, name: string) => {
    setStudentToDelete({ id, name });
  };

  const handleConfirmDelete = () => {
    if (studentToDelete) {
      onDeleteStudent(studentToDelete.id);
      if (selectedStudentToEdit?.id === studentToDelete.id) {
        setActiveTab('list');
        setSelectedStudentToEdit(null);
      }
      setStudentToDelete(null);
    }
  };

  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.nisn.includes(searchQuery) ||
      (s.notes && s.notes.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-6 sm:p-7 border border-slate-200 relative max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 text-white rounded-2xl shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-slate-900">
                  Kelola &amp; Edit Data Siswa
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-md">
                  Panel Admin
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Ubah nama, NISN, status, dan informasi seluruh {students.length} siswa kelas X-7.26
              </p>
            </div>
          </div>

          <button
            id="btn-close-student-manage"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center justify-between gap-2 py-3">
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('list')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
                activeTab === 'list'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daftar Siswa ({students.length})
            </button>
            <button
              onClick={handleOpenAdd}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition flex items-center gap-1 ${
                activeTab === 'add'
                  ? 'bg-white text-indigo-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Tambah Siswa</span>
            </button>
          </div>

          {activeTab === 'list' && (
            <div className="relative w-48 sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Cari siswa..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto pr-1 py-2">
          
          {/* TAB 1: LIST SISWA DENGAN TOMBOL EDIT & HAPUS */}
          {activeTab === 'list' && (
            <div className="space-y-2">
              {filteredStudents.length === 0 ? (
                <div className="text-center py-10 text-xs text-slate-400">
                  Tidak ada data siswa yang cocok dengan &quot;{searchQuery}&quot;.
                </div>
              ) : (
                filteredStudents.map((student, idx) => (
                  <div
                    key={student.id}
                    className="p-3 bg-slate-50 hover:bg-slate-100/80 rounded-2xl border border-slate-200/80 transition flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-xs font-bold text-slate-400 w-5 text-center shrink-0">
                        {idx + 1}
                      </span>
                      <div className={`w-8 h-8 rounded-full text-white text-xs font-bold flex items-center justify-center shrink-0 ${student.avatarBg || 'bg-indigo-600'}`}>
                        {student.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                            {student.name}
                          </h4>
                          <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                            student.gender === 'L' ? 'bg-blue-100 text-blue-800' : 'bg-pink-100 text-pink-800'
                          }`}>
                            {student.gender}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500">
                          <span className="font-mono">{student.nisn}</span>
                          {student.notes && (
                            <>
                              <span>•</span>
                              <span className="truncate max-w-[180px] text-slate-600">{student.notes}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => handleOpenEdit(student)}
                        className="px-2.5 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition border border-indigo-200 flex items-center gap-1"
                        title="Edit Data Siswa"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Edit</span>
                      </button>
                      <button
                        onClick={() => handleDelete(student.id, student.name)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                        title="Hapus Siswa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 2 & 3: FORM TAMBAH / EDIT DATA SISWA */}
          {(activeTab === 'add' || activeTab === 'edit') && (
            <form onSubmit={handleSaveStudent} className="space-y-4 text-xs sm:text-sm">
              <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-2xl flex items-center justify-between">
                <span className="font-bold text-indigo-950">
                  {activeTab === 'edit' ? `Mengedit Data: ${selectedStudentToEdit?.name}` : 'Tambah Data Siswa Baru Kelas X-7.26'}
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('list')}
                  className="text-xs text-indigo-700 hover:underline font-semibold"
                >
                  Kembali ke Daftar
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Lengkap Siswa:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Muhammad Rayhan Al-Fatih"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    NISN (Nomor Induk Siswa Nasional):
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: 0071230001"
                    value={formNisn}
                    onChange={(e) => setFormNisn(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jenis Kelamin:
                  </label>
                  <select
                    value={formGender}
                    onChange={(e) => setFormGender(e.target.value as 'L' | 'P')}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Status Presensi Hari Ini:
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as AttendanceStatus)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="hadir">Hadir (Masuk Kelas)</option>
                    <option value="sakit">Sakit (Ada Keterangan)</option>
                    <option value="izin">Izin (Lomba / Acara Resmi)</option>
                    <option value="alpa">Alpa (Tanpa Keterangan)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Warna Avatar Profil:
                  </label>
                  <div className="flex items-center gap-1.5 pt-1">
                    {AVATAR_COLORS.map((color) => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setFormAvatarBg(color)}
                        className={`w-6 h-6 rounded-full ${color} transition ${
                          formAvatarBg === color ? 'ring-2 ring-offset-2 ring-slate-900 scale-110' : 'opacity-70 hover:opacity-100'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Catatan Siswa / Keterangan Jabatan:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Ketua Kelas / Surat Dokter Sakit Flu / Izin Olimpiade Fisika"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    No. WhatsApp / HP (Opsional):
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: 081234567890"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Email Siswa (Opsional):
                  </label>
                  <input
                    type="email"
                    placeholder="Contoh: rayhan@sekolah.sch.id"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>
              </div>

              <div className="mt-6 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setActiveTab('list')}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs"
                >
                  {activeTab === 'edit' ? 'Simpan Perubahan Siswa' : 'Tambahkan Siswa ke Kelas'}
                </button>
              </div>
            </form>
          )}

        </div>

        {/* Delete Confirmation Modal */}
        {studentToDelete && (
          <div className="fixed inset-0 z-60 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 animate-in fade-in zoom-in-95">
              <div className="flex items-center gap-2.5 text-rose-600 mb-2.5">
                <div className="p-2 bg-rose-50 rounded-xl">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Hapus Data Siswa?</h4>
                  <span className="text-[11px] text-slate-500">Tindakan ini permanen</span>
                </div>
              </div>

              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                Yakin ingin menghapus <strong>&quot;{studentToDelete.name}&quot;</strong> dari daftar siswa kelas X-7.26?
              </p>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setStudentToDelete(null)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs"
                >
                  Ya, Hapus
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
