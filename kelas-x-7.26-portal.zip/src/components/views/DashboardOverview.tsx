import React from 'react';
import { 
  Student, 
  PiketDaySchedule, 
  SubjectItem, 
  HomeworkNote, 
  Announcement,
  DayOfWeek
} from '../../types';
import { 
  Users, 
  Sparkles, 
  Calendar, 
  CheckSquare, 
  AlertTriangle, 
  ArrowRight, 
  Clock, 
  MapPin, 
  ShieldAlert, 
  Award,
  CheckCircle2
} from 'lucide-react';

interface DashboardOverviewProps {
  students: Student[];
  piketSchedule: PiketDaySchedule[];
  schedule: SubjectItem[];
  homeworks: HomeworkNote[];
  announcements: Announcement[];
  onNavigate: (tab: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  students,
  piketSchedule,
  schedule,
  homeworks,
  announcements,
  onNavigate
}) => {
  const currentDayIndex = new Date().getDay();
  const dayNamesMap: Record<number, DayOfWeek> = {
    1: 'Senin',
    2: 'Selasa',
    3: 'Rabu',
    4: 'Kamis',
    5: 'Jumat'
  };
  const todayDayName: DayOfWeek = dayNamesMap[currentDayIndex] || 'Senin';

  // Today's piket
  const todayPiket = piketSchedule.find((p) => p.day === todayDayName) || piketSchedule[0];
  
  // Today's schedule
  const todaySubjects = schedule.filter((s) => s.day === todayDayName);

  // Urgent announcements
  const urgentAnnouncement = announcements.find((a) => a.isUrgent);

  // Homework due soon (sort by due date)
  const pendingHomeworks = homeworks
    .filter((h) => h.status !== 'Selesai')
    .slice(0, 3);

  // Attendance stats
  const hadirCount = students.filter((s) => s.attendanceStatus === 'hadir').length;
  const attendanceRate = Math.round((hadirCount / (students.length || 1)) * 100);

  return (
    <div className="space-y-6">
      
      {/* Top Welcome & Urgent Alert */}
      {urgentAnnouncement && (
        <div 
          onClick={() => onNavigate('pengumuman')}
          className="p-4 bg-gradient-to-r from-rose-500 via-rose-600 to-amber-600 text-white rounded-2xl shadow-sm cursor-pointer hover:shadow-md transition-all flex items-center justify-between gap-3 select-none"
        >
          <div className="flex items-center gap-3">
            <span className="p-2 bg-white/20 rounded-xl backdrop-blur-xs">
              <ShieldAlert className="w-5 h-5 text-white animate-bounce" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase bg-white text-rose-700 px-1.5 py-0.5 rounded">
                  PENGUMUMAN MENDESAK ({urgentAnnouncement.sender})
                </span>
                <span className="text-xs text-rose-100 hidden sm:inline">{urgentAnnouncement.date}</span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-white mt-0.5 line-clamp-1">
                {urgentAnnouncement.title}
              </h3>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-bold text-white shrink-0">
            <span className="hidden sm:inline">Buka Detail</span>
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>
      )}

      {/* Grid of Main Functional Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        
        {/* 1. Presensi Hari Ini */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-slate-300 transition flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Presensi Siswa Hari Ini</h3>
                  <span className="text-[11px] text-slate-500">Tingkat kehadiran kelas</span>
                </div>
              </div>
              <span className="text-xl font-extrabold text-emerald-600">{attendanceRate}%</span>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center py-2">
              <div className="p-2 bg-emerald-50 rounded-xl">
                <span className="text-[10px] font-bold text-emerald-700 block">Hadir</span>
                <span className="text-lg font-extrabold text-emerald-800">{hadirCount}</span>
              </div>
              <div className="p-2 bg-amber-50 rounded-xl">
                <span className="text-[10px] font-bold text-amber-700 block">Sakit</span>
                <span className="text-lg font-extrabold text-amber-800">
                  {students.filter((s) => s.attendanceStatus === 'sakit').length}
                </span>
              </div>
              <div className="p-2 bg-blue-50 rounded-xl">
                <span className="text-[10px] font-bold text-blue-700 block">Izin</span>
                <span className="text-lg font-extrabold text-blue-800">
                  {students.filter((s) => s.attendanceStatus === 'izin').length}
                </span>
              </div>
              <div className="p-2 bg-rose-50 rounded-xl">
                <span className="text-[10px] font-bold text-rose-700 block">Alpa</span>
                <span className="text-lg font-extrabold text-rose-800">
                  {students.filter((s) => s.attendanceStatus === 'alpa').length}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('absensi')}
            className="mt-4 w-full py-2 px-3 bg-slate-100 hover:bg-slate-200/80 text-slate-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
          >
            <span>Buka Lembar Absensi Lengkap</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 2. Piket Hari Ini */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-slate-300 transition flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Piket Hari {todayDayName}</h3>
                  <span className="text-[11px] text-slate-500">{todayPiket.members.length} Petugas bertugas</span>
                </div>
              </div>
              <span className="px-2 py-0.5 bg-amber-100 text-amber-800 font-bold rounded text-[10px]">
                Hari Ini
              </span>
            </div>

            <div className="space-y-1.5">
              <div className="text-xs text-slate-600 mb-1">
                <span className="font-semibold text-slate-800">Koordinator:</span> {todayPiket.coordinator}
              </div>
              <div className="flex flex-wrap gap-1.5">
                {todayPiket.members.map((m, idx) => (
                  <span key={idx} className="px-2 py-1 bg-slate-100 text-slate-700 rounded-md text-xs font-medium">
                    {m.split(' ')[0]}
                  </span>
                ))}
              </div>

              <div className="pt-2 text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  {todayPiket.tasks.filter((t) => t.completed).length} dari {todayPiket.tasks.length} checklist tugas tuntas
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('piket')}
            className="mt-4 w-full py-2 px-3 bg-slate-100 hover:bg-slate-200/80 text-slate-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
          >
            <span>Lihat Jadwal Piket Senin-Jum&apos;at</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 3. Catatan PR Mendekati Deadline */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-slate-300 transition flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-violet-50 text-violet-700 rounded-lg">
                  <CheckSquare className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">PR &amp; Tugas Mendatang</h3>
                  <span className="text-[11px] text-slate-500">Batas pengumpulan terdekat</span>
                </div>
              </div>
              <span className="px-2 py-0.5 bg-rose-100 text-rose-800 font-bold rounded text-[10px]">
                {pendingHomeworks.length} Tertunda
              </span>
            </div>

            <div className="space-y-2">
              {pendingHomeworks.length === 0 ? (
                <div className="text-xs text-slate-400 py-3 text-center">
                  Tidak ada PR yang tertunda! Semuanya beres.
                </div>
              ) : (
                pendingHomeworks.map((hw) => (
                  <div key={hw.id} className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-indigo-700">{hw.subject}</span>
                      <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded">
                        Deadline: {hw.dueDate}
                      </span>
                    </div>
                    <p className="text-slate-700 font-semibold truncate mt-0.5">
                      {hw.title}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigate('pr')}
            className="mt-4 w-full py-2 px-3 bg-slate-100 hover:bg-slate-200/80 text-slate-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
          >
            <span>Semua Catatan PR &amp; Tugas</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>

      {/* Today's Subjects Timetable Timeline */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-50 text-blue-700 rounded-lg">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Jadwal Belajar Hari {todayDayName}
              </h3>
              <span className="text-xs text-slate-500">Mata pelajaran yang aktif hari ini</span>
            </div>
          </div>

          <button
            onClick={() => onNavigate('jadwal')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Lihat Jadwal Seluruh Hari</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {todaySubjects.map((sub, idx) => (
            <div
              key={sub.id}
              className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 hover:border-indigo-300 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-bold mb-1.5">
                  <span className="bg-white px-2 py-0.5 rounded border border-slate-200 text-indigo-700 font-mono">
                    {sub.startTime} - {sub.endTime}
                  </span>
                  <span className="text-slate-400">Sesi #{idx + 1}</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 truncate">
                  {sub.name}
                </h4>
                <div className="mt-1 flex items-center gap-1 text-xs text-slate-500">
                  <MapPin className="w-3 h-3" />
                  <span>{sub.room}</span>
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-200/60 text-[11px] text-slate-600 truncate">
                Guru: {sub.teacher.split(',')[0]}
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
