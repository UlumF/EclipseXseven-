import React, { useState, useMemo } from 'react';
import { 
  Student, 
  AttendanceStatus, 
  AttendanceSummary 
} from '../../types';
import { 
  Search, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  XCircle, 
  UserCheck, 
  FileSpreadsheet, 
  Printer, 
  Edit3, 
  RotateCcw,
  Sparkles,
  CalendarDays,
  Users,
  UserCog,
  UserPlus,
  Lock,
  Trash2,
  AlertTriangle,
  Plus
} from 'lucide-react';

interface AttendanceViewProps {
  students: Student[];
  isAdmin: boolean;
  onUpdateStatus: (studentId: string, status: AttendanceStatus, notes?: string) => void;
  onMarkAllPresent: () => void;
  onResetAttendance: () => void;
  onDeleteStudent?: (id: string) => void;
  onResetStudentsToZero?: () => void;
  onOpenStudentManage?: () => void;
  onOpenLoginModal?: () => void;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  students,
  isAdmin,
  onUpdateStatus,
  onMarkAllPresent,
  onResetAttendance,
  onDeleteStudent,
  onResetStudentsToZero,
  onOpenStudentManage,
  onOpenLoginModal
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [editingNoteStudentId, setEditingNoteStudentId] = useState<string | null>(null);
  const [tempNote, setTempNote] = useState('');
  const [readOnlyNotice, setReadOnlyNotice] = useState<string | null>(null);
  const [confirmResetZeroOpen, setConfirmResetZeroOpen] = useState(false);

  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);
  const [confirmResetAttendanceOpen, setConfirmResetAttendanceOpen] = useState(false);

  // Calculate summary metrics
  const summary: AttendanceSummary = useMemo(() => {
    let hadir = 0;
    let sakit = 0;
    let izin = 0;
    let alpa = 0;

    students.forEach((s) => {
      if (s.attendanceStatus === 'hadir') hadir++;
      else if (s.attendanceStatus === 'sakit') sakit++;
      else if (s.attendanceStatus === 'izin') izin++;
      else if (s.attendanceStatus === 'alpa') alpa++;
    });

    const total = students.length;
    const percentage = total > 0 ? Math.round((hadir / total) * 100) : 0;

    return { hadir, sakit, izin, alpa, total, percentage };
  }, [students]);

  // Filtered student list (purely by search query, filter menu removed)
  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;
      return (
        student.name.toLowerCase().includes(q) ||
        student.nisn.includes(q) ||
        (student.notes && student.notes.toLowerCase().includes(q))
      );
    });
  }, [students, searchQuery]);

  const handleOpenNoteModal = (student: Student) => {
    if (!isAdmin) {
      setReadOnlyNotice('Hanya Admin/Pengurus yang dapat menambah catatan atau keterangan izin.');
      setTimeout(() => setReadOnlyNotice(null), 3000);
      return;
    }
    setEditingNoteStudentId(student.id);
    setTempNote(student.notes || '');
  };

  const handleSaveNote = () => {
    if (editingNoteStudentId) {
      const student = students.find((s) => s.id === editingNoteStudentId);
      if (student) {
        onUpdateStatus(student.id, student.attendanceStatus, tempNote);
      }
      setEditingNoteStudentId(null);
      setTempNote('');
    }
  };

  const handleStatusClick = (studentId: string, status: AttendanceStatus) => {
    if (!isAdmin) {
      setReadOnlyNotice('Mode Siswa (Hanya Lihat). Masuk sebagai Admin untuk mengubah kehadiran siswa.');
      setTimeout(() => setReadOnlyNotice(null), 3500);
      return;
    }
    onUpdateStatus(studentId, status);
  };

  const handleDeleteStudentClick = (student: Student) => {
    if (!isAdmin) return;
    setStudentToDelete(student);
  };

  const handleConfirmDeleteStudent = () => {
    if (studentToDelete && onDeleteStudent) {
      onDeleteStudent(studentToDelete.id);
      setStudentToDelete(null);
    }
  };

  const handleConfirmResetAttendance = () => {
    if (onResetAttendance) {
      onResetAttendance();
    }
    setConfirmResetAttendanceOpen(false);
  };

  const handleExecuteResetToZero = () => {
    if (onResetStudentsToZero) {
      onResetStudentsToZero();
    }
    setConfirmResetZeroOpen(false);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const headers = 'No,NISN,Nama Siswa,L/P,Status Kehadiran,Keterangan\n';
    const rows = students.map((s, idx) => {
      const statusLabel = 
        s.attendanceStatus === 'hadir' ? 'HADIR' :
        s.attendanceStatus === 'sakit' ? 'SAKIT' :
        s.attendanceStatus === 'izin' ? 'IZIN' : 'ALPA';
      const cleanNote = (s.notes || '-').replace(/,/g, ';');
      return `${idx + 1},"${s.nisn}","${s.name}","${s.gender}","${statusLabel}","${cleanNote}"`;
    }).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Absensi_Kelas_X-7.26_${selectedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Read only notification toast */}
      {readOnlyNotice && (
        <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between text-xs text-amber-900 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-semibold">{readOnlyNotice}</span>
          </div>
          {onOpenLoginModal && (
            <button
              onClick={onOpenLoginModal}
              className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg transition"
            >
              Login Admin
            </button>
          )}
        </div>
      )}

      {/* Top Header Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
              <UserCheck className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                  Absensi Anggota Kelas X-7.26
                </h2>
                <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md uppercase ${
                  isAdmin 
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                    : 'bg-slate-100 text-slate-600 border border-slate-200'
                }`}>
                  {isAdmin ? 'Mode Edit Admin' : 'Mode Baca Siswa'}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Pencatatan kehadiran harian seluruh {students.length} siswa terdaftar
              </p>
            </div>
          </div>
        </div>

        {/* Date and Actions */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100/90 rounded-lg text-xs font-semibold text-slate-700 border border-slate-200">
            <CalendarDays className="w-3.5 h-3.5 text-slate-500" />
            <input 
              type="date" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent border-none text-xs font-semibold text-slate-800 focus:outline-none cursor-pointer"
            />
          </div>

          {isAdmin && (
            <>
              <button
                id="btn-mark-all-present"
                onClick={onMarkAllPresent}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Set Semua Hadir</span>
              </button>

              {onOpenStudentManage && (
                <button
                  id="btn-open-student-manage-from-attendance"
                  onClick={onOpenStudentManage}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition"
                >
                  <UserPlus className="w-3.5 h-3.5 text-indigo-600" />
                  <span>+ Tambah / Kelola Siswa</span>
                </button>
              )}

              <button
                id="btn-reset-students-zero"
                onClick={() => setConfirmResetZeroOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition"
                title="Reset jumlah siswa menjadi 0"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                <span>Reset Siswa Jadi 0</span>
              </button>
            </>
          )}

          <button
            id="btn-export-attendance"
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden sm:inline">Ekspor CSV</span>
          </button>

          <button
            id="btn-print-attendance"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition"
            title="Cetak Lembar Absensi"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
          </button>
        </div>
      </div>

      {/* Summary Metric Counters (Clean display, no filter logic) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
        <div className="p-4 rounded-xl border bg-slate-900 text-white border-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider opacity-80">Total Siswa</span>
            <Users className="w-4 h-4 opacity-70" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold">{summary.total}</span>
            <span className="text-xs opacity-75">Siswa</span>
          </div>
          <div className="mt-1 text-[11px] opacity-75">Tingkat kehadiran {summary.percentage}%</div>
        </div>

        <div className="p-4 rounded-xl border bg-white text-slate-800 border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700">Hadir</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600">{summary.hadir}</span>
            <span className="text-xs text-slate-500 font-medium">Orang</span>
          </div>
          <div className="mt-1 text-[11px] text-emerald-600 font-medium">
            {summary.total > 0 ? Math.round((summary.hadir / summary.total) * 100) : 0}% dari kelas
          </div>
        </div>

        <div className="p-4 rounded-xl border bg-white text-slate-800 border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-700">Sakit</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-600">{summary.sakit}</span>
            <span className="text-xs text-slate-500 font-medium">Orang</span>
          </div>
          <div className="mt-1 text-[11px] text-amber-600 font-medium">Dengan surat dokter/wali</div>
        </div>

        <div className="p-4 rounded-xl border bg-white text-slate-800 border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-700">Izin</span>
            <AlertCircle className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-blue-600">{summary.izin}</span>
            <span className="text-xs text-slate-500 font-medium">Orang</span>
          </div>
          <div className="mt-1 text-[11px] text-blue-600 font-medium">Lomba / Keperluan Resmi</div>
        </div>

        <div className="p-4 rounded-xl border bg-white text-slate-800 border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-700">Alpa</span>
            <XCircle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-rose-600">{summary.alpa}</span>
            <span className="text-xs text-slate-500 font-medium">Orang</span>
          </div>
          <div className="mt-1 text-[11px] text-rose-600 font-medium">Tanpa keterangan</div>
        </div>
      </div>

      {/* Search Bar (Filter menu completely removed) */}
      <div className="flex items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
        <div className="relative w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            id="input-search-student"
            placeholder="Cari nama siswa, NISN, atau keterangan catatan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition"
          />
        </div>
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="text-xs font-semibold text-slate-500 hover:text-slate-700 px-2 py-1 bg-slate-100 rounded-lg shrink-0"
          >
            Reset Cari
          </button>
        )}
      </div>

      {/* Students Attendance Table / Card List */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                <th className="py-3.5 px-4 w-12 text-center">No</th>
                <th className="py-3.5 px-4">Nama Siswa</th>
                <th className="py-3.5 px-4 w-28">NISN</th>
                <th className="py-3.5 px-4 w-16 text-center">L/P</th>
                <th className="py-3.5 px-4 text-center">Status Kehadiran</th>
                <th className="py-3.5 px-4">Keterangan / Surat</th>
                <th className="py-3.5 px-4 w-28 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
              {students.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    <div className="max-w-xs mx-auto space-y-3">
                      <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 flex items-center justify-center text-xl">
                        👥
                      </div>
                      <div>
                        <p className="font-bold text-slate-700 text-sm">Jumlah Siswa: 0 Orang</p>
                        <p className="text-xs text-slate-400 mt-0.5">Daftar siswa saat ini kosong.</p>
                      </div>
                      {isAdmin && onOpenStudentManage && (
                        <button
                          onClick={onOpenStudentManage}
                          className="inline-flex items-center gap-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>+ Tambah Siswa Baru</span>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400">
                    Tidak ada data siswa yang cocok dengan pencarian &quot;{searchQuery}&quot;.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student, index) => {
                  const isHadir = student.attendanceStatus === 'hadir';
                  const isSakit = student.attendanceStatus === 'sakit';
                  const isIzin = student.attendanceStatus === 'izin';
                  const isAlpa = student.attendanceStatus === 'alpa';

                  return (
                    <tr 
                      key={student.id} 
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isAlpa ? 'bg-rose-50/30' : isSakit ? 'bg-amber-50/30' : isIzin ? 'bg-blue-50/30' : ''
                      }`}
                    >
                      <td className="py-3 px-4 text-center font-semibold text-slate-500">
                        {index + 1}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-7 h-7 rounded-full text-white text-[11px] font-bold flex items-center justify-center shrink-0 ${student.avatarBg || 'bg-indigo-600'}`}>
                            {student.name.charAt(0)}
                          </div>
                          <div>
                            <span className="font-semibold text-slate-900">{student.name}</span>
                            {student.notes && (
                              <span className="block text-[11px] text-slate-500 font-normal truncate max-w-xs">
                                {student.notes}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-500 font-mono text-xs">
                        {student.nisn}
                      </td>
                      <td className="py-3 px-4 text-center font-bold">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${student.gender === 'L' ? 'bg-blue-50 text-blue-700' : 'bg-pink-50 text-pink-700'}`}>
                          {student.gender}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {/* 4-State Quick Switcher Buttons */}
                        <div className="flex items-center justify-center gap-1">
                          <button
                            id={`btn-status-${student.id}-hadir`}
                            onClick={() => handleStatusClick(student.id, 'hadir')}
                            className={`px-2 py-1 text-[11px] font-bold rounded transition ${
                              isHadir
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700'
                            }`}
                            title={!isAdmin ? 'Hanya Admin yang dapat mengubah' : 'Set Hadir'}
                          >
                            Hadir
                          </button>
                          <button
                            id={`btn-status-${student.id}-sakit`}
                            onClick={() => handleStatusClick(student.id, 'sakit')}
                            className={`px-2 py-1 text-[11px] font-bold rounded transition ${
                              isSakit
                                ? 'bg-amber-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-amber-50 hover:text-amber-700'
                            }`}
                            title={!isAdmin ? 'Hanya Admin yang dapat mengubah' : 'Set Sakit'}
                          >
                            Sakit
                          </button>
                          <button
                            id={`btn-status-${student.id}-izin`}
                            onClick={() => handleStatusClick(student.id, 'izin')}
                            className={`px-2 py-1 text-[11px] font-bold rounded transition ${
                              isIzin
                                ? 'bg-blue-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-blue-50 hover:text-blue-700'
                            }`}
                            title={!isAdmin ? 'Hanya Admin yang dapat mengubah' : 'Set Izin'}
                          >
                            Izin
                          </button>
                          <button
                            id={`btn-status-${student.id}-alpa`}
                            onClick={() => handleStatusClick(student.id, 'alpa')}
                            className={`px-2 py-1 text-[11px] font-bold rounded transition ${
                              isAlpa
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-rose-50 hover:text-rose-700'
                            }`}
                            title={!isAdmin ? 'Hanya Admin yang dapat mengubah' : 'Set Alpa'}
                          >
                            Alpa
                          </button>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-600">
                        {student.notes ? (
                          <span className="inline-block bg-slate-100 px-2 py-1 rounded text-slate-700 font-medium">
                            {student.notes}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">-</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            id={`btn-edit-note-${student.id}`}
                            onClick={() => handleOpenNoteModal(student)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition"
                            title={isAdmin ? "Tambah / Ubah Catatan Siswa" : "Hanya Admin yang dapat mengedit"}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          {isAdmin && (
                            <button
                              id={`btn-delete-student-${student.id}`}
                              onClick={() => handleDeleteStudentClick(student)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                              title="Hapus / Kurangi Siswa"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        
        {/* Footer info */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <span>Menampilkan {filteredStudents.length} dari total {students.length} siswa X-7.26</span>
          <div className="flex items-center gap-3">
            {isAdmin && (
              <>
                <button
                  id="btn-reset-attendance-footer"
                  onClick={() => setConfirmResetAttendanceOpen(true)}
                  className="text-slate-500 hover:text-indigo-600 flex items-center gap-1 transition text-xs font-semibold"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Data Absen Awal</span>
                </button>
                <button
                  id="btn-reset-zero-footer"
                  onClick={() => setConfirmResetZeroOpen(true)}
                  className="text-slate-500 hover:text-rose-600 flex items-center gap-1 transition text-xs font-semibold"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Kosongkan Jumlah Siswa (0)</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Single Student Delete Confirmation Dialog */}
      {studentToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-600 mb-3">
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-100">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Hapus Data Siswa?
                </h3>
                <span className="text-xs text-slate-500">Konfirmasi Penghapusan</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5">
              Apakah Anda yakin ingin menghapus siswa <strong>&quot;{studentToDelete.name}&quot;</strong> (NISN: <span className="font-mono">{studentToDelete.nisn}</span>) dari daftar absensi kelas?
            </p>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setStudentToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmDeleteStudent}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-xs"
              >
                Ya, Hapus Siswa
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Attendance Status Confirmation Dialog */}
      {confirmResetAttendanceOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-indigo-600 mb-3">
              <div className="p-3 bg-indigo-50 rounded-xl border border-indigo-100">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Reset Status Absensi ke Hadir?
                </h3>
                <span className="text-xs text-slate-500">Kembalikan Status Awal</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5">
              Tindakan ini akan mengembalikan status absensi seluruh <strong>{students.length} siswa</strong> menjadi &quot;Hadir&quot; dan menghapus catatan keterangan sementara.
            </p>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setConfirmResetAttendanceOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmResetAttendance}
                className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-xs"
              >
                Ya, Reset Status Hadir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Note Editing Modal */}
      {editingNoteStudentId && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Catatan &amp; Keterangan Siswa
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Tambahkan surat izin dokter, tugas lomba, atau alasan izin lainnya.
            </p>

            <textarea
              rows={3}
              value={tempNote}
              onChange={(e) => setTempNote(e.target.value)}
              placeholder="Contoh: Izin mengikuti Olimpiade Sains / Sakit flu (ada surat dokter)"
              className="w-full p-3 text-xs sm:text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />

            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setEditingNoteStudentId(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
              >
                Batal
              </button>
              <button
                onClick={handleSaveNote}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition shadow-xs"
              >
                Simpan Catatan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset to Zero Confirmation Dialog */}
      {confirmResetZeroOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-600 mb-3">
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-100">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Reset Jumlah Siswa Menjadi 0?
                </h3>
                <span className="text-xs text-slate-500">Tindakan Khusus Admin</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5">
              Apakah Anda yakin ingin mengosongkan seluruh daftar siswa menjadi <strong>0 Siswa</strong>? Semua data absensi dan nama siswa saat ini akan dihapus sehingga Anda dapat mengisi siswa baru dari awal.
            </p>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setConfirmResetZeroOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
              >
                Batal
              </button>
              <button
                onClick={handleExecuteResetToZero}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-xs"
              >
                Ya, Kosongkan Siswa (0)
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
