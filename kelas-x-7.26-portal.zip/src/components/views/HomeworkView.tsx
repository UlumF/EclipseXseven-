import React, { useState, useMemo } from 'react';
import { 
  HomeworkNote 
} from '../../types';
import { 
  CheckSquare, 
  Plus, 
  Calendar, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  BookOpen, 
  Filter, 
  Search, 
  Sparkles,
  Trash2
} from 'lucide-react';

interface HomeworkViewProps {
  homeworks: HomeworkNote[];
  isAdmin?: boolean;
  onAddHomework: (hw: Omit<HomeworkNote, 'id'>) => void;
  onUpdateHomeworkStatus: (id: string, status: HomeworkNote['status']) => void;
  onDeleteHomework: (id: string) => void;
  onOpenLoginModal?: () => void;
}

export const HomeworkView: React.FC<HomeworkViewProps> = ({
  homeworks,
  isAdmin = false,
  onAddHomework,
  onUpdateHomeworkStatus,
  onDeleteHomework,
  onOpenLoginModal
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPriority, setFilterPriority] = useState<string>('all');

  // Form State
  const [formSubject, setFormSubject] = useState('Matematika Wajib');
  const [formTitle, setFormTitle] = useState('');
  const [formDateGiven, setFormDateGiven] = useState(new Date().toISOString().split('T')[0]);
  const [formDueDate, setFormDueDate] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formPriority, setFormPriority] = useState<HomeworkNote['priority']>('Sedang');
  const [formSubmissionType, setFormSubmissionType] = useState<HomeworkNote['submissionType']>('Buku Tugas');
  const [formTags, setFormTags] = useState('');

  // Calculate days remaining helper
  const calculateDaysLeft = (dueDateStr: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dueDateStr);
    due.setHours(0, 0, 0, 0);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const filteredHomeworks = useMemo(() => {
    return homeworks.filter((hw) => {
      const matchSearch = 
        hw.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        hw.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        hw.description.toLowerCase().includes(searchQuery.toLowerCase());

      const matchStatus = 
        filterStatus === 'all' || hw.status === filterStatus;

      const matchPriority = 
        filterPriority === 'all' || hw.priority === filterPriority;

      return matchSearch && matchStatus && matchPriority;
    });
  }, [homeworks, searchQuery, filterStatus, filterPriority]);

  const handleSubmitNewHomework = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formDueDate) return;

    onAddHomework({
      subject: formSubject,
      title: formTitle.trim(),
      dateGiven: formDateGiven,
      dueDate: formDueDate,
      description: formDescription.trim() || 'Kerjakan dengan teliti sesuai instruksi guru.',
      priority: formPriority,
      status: 'Belum Selesai',
      submissionType: formSubmissionType,
      tags: formTags.split(',').map((t) => t.trim()).filter(Boolean)
    });

    // Reset
    setFormTitle('');
    setFormDescription('');
    setFormTags('');
    setShowAddModal(false);
  };

  const pendingCount = homeworks.filter((h) => h.status !== 'Selesai').length;
  const completedCount = homeworks.filter((h) => h.status === 'Selesai').length;

  return (
    <div className="space-y-6">
      {/* Top Banner Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-indigo-600 to-violet-700 text-white rounded-xl shadow-xs">
            <CheckSquare className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Catatan Tugas &amp; PR Kelas X-7.26
              </h2>
              <span className="px-2 py-0.5 text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-md">
                Deadline Terintegrasi
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Daftar pekerjaan rumah, tanggal penugasan, dan batas akhir pengumpulan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-add-homework-modal"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-bold text-white bg-[#1E1B4B] hover:bg-indigo-950 rounded-xl transition shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Catatan PR</span>
          </button>
        </div>
      </div>

      {/* Stats Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div 
          onClick={() => setFilterStatus('all')}
          className={`p-3.5 rounded-xl border transition cursor-pointer ${
            filterStatus === 'all' ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-800 border-slate-200'
          }`}
        >
          <span className="text-[11px] font-bold uppercase tracking-wider opacity-75">Total Tugas PR</span>
          <div className="text-2xl font-extrabold mt-1">{homeworks.length}</div>
        </div>

        <div 
          onClick={() => setFilterStatus('Belum Selesai')}
          className={`p-3.5 rounded-xl border transition cursor-pointer ${
            filterStatus === 'Belum Selesai' ? 'bg-rose-600 text-white border-rose-600' : 'bg-white text-slate-800 border-slate-200'
          }`}
        >
          <span className="text-[11px] font-bold uppercase tracking-wider text-rose-700">Belum Selesai</span>
          <div className="text-2xl font-extrabold mt-1 text-rose-600">
            {homeworks.filter((h) => h.status === 'Belum Selesai').length}
          </div>
        </div>

        <div 
          onClick={() => setFilterStatus('Sedang Dikerjakan')}
          className={`p-3.5 rounded-xl border transition cursor-pointer ${
            filterStatus === 'Sedang Dikerjakan' ? 'bg-amber-600 text-white border-amber-600' : 'bg-white text-slate-800 border-slate-200'
          }`}
        >
          <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700">Dalam Proses</span>
          <div className="text-2xl font-extrabold mt-1 text-amber-600">
            {homeworks.filter((h) => h.status === 'Sedang Dikerjakan').length}
          </div>
        </div>

        <div 
          onClick={() => setFilterStatus('Selesai')}
          className={`p-3.5 rounded-xl border transition cursor-pointer ${
            filterStatus === 'Selesai' ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-slate-800 border-slate-200'
          }`}
        >
          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">Sudah Tuntas</span>
          <div className="text-2xl font-extrabold mt-1 text-emerald-600">{completedCount}</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari judul PR, mata pelajaran..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0 text-xs">
          <span className="text-slate-400 font-semibold hidden sm:inline">Prioritas:</span>
          {['all', 'Tinggi', 'Sedang', 'Rendah'].map((pri) => (
            <button
              key={pri}
              onClick={() => setFilterPriority(pri)}
              className={`px-2.5 py-1 rounded-md font-semibold capitalize transition ${
                filterPriority === pri
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {pri === 'all' ? 'Semua' : pri}
            </button>
          ))}
        </div>
      </div>

      {/* Homework Cards List */}
      <div className="space-y-4">
        {filteredHomeworks.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-sm">
            <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-400 mb-2" />
            <p className="font-semibold text-slate-700">Tidak ada catatan PR yang cocok!</p>
            <p className="text-xs text-slate-500 mt-1">Semua tugas beres atau tidak ada PR pada filter ini.</p>
          </div>
        ) : (
          filteredHomeworks.map((hw) => {
            const daysLeft = calculateDaysLeft(hw.dueDate);
            const isCompleted = hw.status === 'Selesai';
            const isOverdue = daysLeft < 0 && !isCompleted;
            const isDueSoon = daysLeft <= 2 && daysLeft >= 0 && !isCompleted;

            return (
              <div
                key={hw.id}
                id={`homework-item-${hw.id}`}
                className={`p-5 rounded-2xl border transition-all shadow-xs ${
                  isCompleted
                    ? 'bg-slate-50/70 border-slate-200 opacity-80'
                    : isDueSoon
                    ? 'bg-white border-rose-300 ring-1 ring-rose-200'
                    : 'bg-white border-slate-200 hover:border-indigo-300'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  
                  {/* Left content */}
                  <div className="flex-1 space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded text-xs font-extrabold bg-indigo-50 text-indigo-700 border border-indigo-200">
                        {hw.subject}
                      </span>

                      {/* Priority Tag */}
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        hw.priority === 'Tinggi' ? 'bg-rose-100 text-rose-800' :
                        hw.priority === 'Sedang' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        Prioritas: {hw.priority}
                      </span>

                      {/* Submission Type */}
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600">
                        📁 {hw.submissionType}
                      </span>
                    </div>

                    <h3 className={`text-base sm:text-lg font-bold ${isCompleted ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                      {hw.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {hw.description}
                    </p>

                    {/* Date Details Bar */}
                    <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-slate-500 border-t border-slate-100 mt-2">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>Diberikan: <strong className="text-slate-700">{hw.dateGiven}</strong></span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>Deadline: <strong className="text-slate-900">{hw.dueDate}</strong></span>
                      </div>

                      {/* Countdown badge */}
                      {!isCompleted && (
                        <div className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                          isOverdue ? 'bg-red-100 text-red-800' :
                          isDueSoon ? 'bg-amber-100 text-amber-800 animate-pulse' : 'bg-blue-50 text-blue-700'
                        }`}>
                          {isOverdue ? '⚠️ Melewati Batas!' :
                           daysLeft === 0 ? '🚨 Terakhir Hari Ini!' :
                           daysLeft === 1 ? '⏰ Besok Pengumpulan!' :
                           `${daysLeft} Hari Lagi`}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right Actions: Status Selector & Delete */}
                  <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    <select
                      value={hw.status}
                      onChange={(e) => onUpdateHomeworkStatus(hw.id, e.target.value as HomeworkNote['status'])}
                      className={`text-xs font-bold px-3 py-1.5 rounded-lg border focus:outline-none cursor-pointer ${
                        hw.status === 'Selesai' ? 'bg-emerald-50 text-emerald-700 border-emerald-300' :
                        hw.status === 'Sedang Dikerjakan' ? 'bg-amber-50 text-amber-700 border-amber-300' :
                        'bg-rose-50 text-rose-700 border-rose-300'
                      }`}
                    >
                      <option value="Belum Selesai">Belum Selesai</option>
                      <option value="Sedang Dikerjakan">Sedang Dikerjakan</option>
                      <option value="Selesai">Selesai (Tuntas)</option>
                    </select>

                    <button
                      onClick={() => onDeleteHomework(hw.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                      title="Hapus Catatan PR"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add Homework Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Tambah Catatan PR / Tugas Baru
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Catat tugas dari guru mapel agar seluruh teman kelas dapat memantau batas pengumpulan.
            </p>

            <form onSubmit={handleSubmitNewHomework} className="space-y-3.5 text-xs sm:text-sm">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Mata Pelajaran:
                </label>
                <select
                  value={formSubject}
                  onChange={(e) => setFormSubject(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-semibold"
                >
                  <option value="Matematika Wajib">Matematika Wajib</option>
                  <option value="Fisika">Fisika</option>
                  <option value="Kimia">Kimia</option>
                  <option value="Biologi">Biologi</option>
                  <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                  <option value="Bahasa Inggris">Bahasa Inggris</option>
                  <option value="Informatika">Informatika</option>
                  <option value="Sejarah Indonesia">Sejarah Indonesia</option>
                  <option value="Ekonomi Dasar">Ekonomi Dasar</option>
                  <option value="PPKN">PPKN</option>
                  <option value="PJOK">PJOK</option>
                  <option value="Seni Budaya">Seni Budaya</option>
                  <option value="Bahasa Daerah">Bahasa Daerah</option>
                  <option value="Pendidikan Agama">Pendidikan Agama</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Judul Tugas / Pekerjaan Rumah:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Latihan Soal Bab 3 Halaman 45 No. 1-10"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tanggal Diberikan:
                  </label>
                  <input
                    type="date"
                    required
                    value={formDateGiven}
                    onChange={(e) => setFormDateGiven(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tanggal Deadline (Batas Akhir):
                  </label>
                  <input
                    type="date"
                    required
                    value={formDueDate}
                    onChange={(e) => setFormDueDate(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-indigo-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tingkat Prioritas:
                  </label>
                  <select
                    value={formPriority}
                    onChange={(e) => setFormPriority(e.target.value as HomeworkNote['priority'])}
                    className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Tinggi">Tinggi (Mendesak)</option>
                    <option value="Sedang">Sedang</option>
                    <option value="Rendah">Rendah</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Metode Pengumpulan:
                  </label>
                  <select
                    value={formSubmissionType}
                    onChange={(e) => setFormSubmissionType(e.target.value as HomeworkNote['submissionType'])}
                    className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Buku Tugas">Buku Tugas</option>
                    <option value="Google Classroom">Google Classroom</option>
                    <option value="Presentasi">Presentasi</option>
                    <option value="Proyek Fisik">Proyek Fisik</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Instruksi / Catatan Tambahan:
                </label>
                <textarea
                  rows={3}
                  placeholder="Rincian ketentuan pengerjaan, bab, format file, dll."
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Tag Kata Kunci (pisahkan dengan koma):
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Bab 4, Kelompok, Buku Tulis"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs"
                >
                  Simpan Catatan PR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
