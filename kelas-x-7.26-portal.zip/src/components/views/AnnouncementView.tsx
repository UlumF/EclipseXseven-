import React, { useState } from 'react';
import { 
  Announcement, 
  ClassImportantNote, 
  AnnouncementSender 
} from '../../types';
import { 
  Bell, 
  AlertTriangle, 
  Pin, 
  Plus, 
  Calendar, 
  User, 
  Megaphone, 
  FileText, 
  ShieldAlert, 
  Sparkles,
  Trash2,
  Share2
} from 'lucide-react';

interface AnnouncementViewProps {
  announcements: Announcement[];
  classNotes: ClassImportantNote[];
  isAdmin?: boolean;
  onAddAnnouncement: (ann: Omit<Announcement, 'id'>) => void;
  onDeleteAnnouncement: (id: string) => void;
  onAddClassNote: (note: Omit<ClassImportantNote, 'id'>) => void;
  onDeleteClassNote: (id: string) => void;
  onOpenLoginModal?: () => void;
}

export const AnnouncementView: React.FC<AnnouncementViewProps> = ({
  announcements,
  classNotes,
  isAdmin = false,
  onAddAnnouncement,
  onDeleteAnnouncement,
  onAddClassNote,
  onDeleteClassNote,
  onOpenLoginModal
}) => {
  const [showAnnModal, setShowAnnModal] = useState(false);
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');

  // Announcement Form
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annSender, setAnnSender] = useState<AnnouncementSender>('Ketua Kelas');
  const [annSenderName, setAnnSenderName] = useState('Muhammad Rayhan Al-Fatih');
  const [annIsUrgent, setAnnIsUrgent] = useState(true);
  const [annCategory, setAnnCategory] = useState<Announcement['category']>('Mendesak');

  // Note Form
  const [noteTitle, setNoteTitle] = useState('');
  const [noteCategory, setNoteCategory] = useState('Akademik');
  const [noteContent, setNoteContent] = useState('');
  const [notePinned, setNotePinned] = useState(true);
  const [noteAuthor, setNoteAuthor] = useState('Pengurus Kelas');

  const handleSenderChange = (sender: AnnouncementSender) => {
    setAnnSender(sender);
    if (sender === 'Wali Kelas') {
      setAnnSenderName('Dra. Hj. Siti Nurhaliza, M.Pd');
    } else if (sender === 'Ketua Kelas') {
      setAnnSenderName('Muhammad Rayhan Al-Fatih');
    } else if (sender === 'Sekretaris') {
      setAnnSenderName('Dini Fitriyani / Marsha Nabila');
    } else if (sender === 'Bendahara') {
      setAnnSenderName('Jessica Amanda Siregar');
    } else {
      setAnnSenderName('Pengurus Inti X-7.26');
    }
  };

  const handleCreateAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annContent.trim()) return;

    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    onAddAnnouncement({
      title: annTitle.trim(),
      content: annContent.trim(),
      sender: annSender,
      senderName: annSenderName,
      date: formattedDate,
      isUrgent: annIsUrgent,
      category: annCategory
    });

    setAnnTitle('');
    setAnnContent('');
    setShowAnnModal(false);
  };

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() || !noteContent.trim()) return;

    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

    onAddClassNote({
      title: noteTitle.trim(),
      category: noteCategory,
      content: noteContent.trim(),
      dateUpdated: formattedDate,
      pinned: notePinned,
      author: noteAuthor,
      color: 'border-indigo-500 bg-indigo-50/70'
    });

    setNoteTitle('');
    setNoteContent('');
    setShowNoteModal(false);
  };

  const urgentList = announcements.filter((a) => a.isUrgent);
  const regularList = announcements.filter((a) => !a.isUrgent);

  return (
    <div className="space-y-8">
      
      {/* Top Banner Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-rose-600 to-amber-600 text-white rounded-xl shadow-xs">
            <Megaphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Pengumuman Mendesak &amp; Catatan Penting
              </h2>
              <span className="px-2 py-0.5 text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200 rounded-md">
                Wali Kelas &amp; Ketua Kelas
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Informasi resmi, instruksi darurat, tata tertib, dan arsip penting kelas X-7.26
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-open-ann-modal"
            onClick={() => setShowAnnModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-xs"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Kirim Pengumuman</span>
          </button>

          <button
            id="btn-open-note-modal"
            onClick={() => setShowNoteModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition border border-slate-200"
          >
            <Pin className="w-3.5 h-3.5 text-indigo-600" />
            <span>Tambah Catatan</span>
          </button>
        </div>
      </div>

      {/* SECTION 1: PENGUMUMAN MENDESAK (Urgent Broadcasts) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <div className="flex items-center gap-2">
            <span className="p-1 bg-rose-100 text-rose-700 rounded">
              <ShieldAlert className="w-4 h-4" />
            </span>
            <h3 className="text-base font-extrabold text-slate-900 tracking-tight">
              Kolom Pengumuman Mendesak (Urgent Broadcast)
            </h3>
          </div>
          <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
            {urgentList.length} Aktif
          </span>
        </div>

        {urgentList.length === 0 ? (
          <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 text-center text-slate-500 text-xs">
            Tidak ada pengumuman mendesak saat ini. Semua kondisi kelas normal &amp; terkendali.
          </div>
        ) : (
          <div className="space-y-3">
            {urgentList.map((ann) => (
              <div
                key={ann.id}
                id={`announcement-urgent-${ann.id}`}
                className="p-5 bg-gradient-to-r from-rose-50/90 via-amber-50/40 to-white rounded-2xl border-2 border-rose-300 shadow-sm relative overflow-hidden group"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-rose-600 text-white uppercase tracking-wider animate-pulse flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        MENDESAK
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-slate-800 border border-slate-200">
                        {ann.category}
                      </span>
                      <span className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        Oleh: <strong className="text-slate-900">{ann.sender} ({ann.senderName})</strong>
                      </span>
                    </div>

                    <h4 className="text-base sm:text-lg font-bold text-slate-900">
                      {ann.title}
                    </h4>

                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
                      {ann.content}
                    </p>

                    <div className="pt-2 flex items-center gap-2 text-[11px] text-slate-500">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>Diposting pada: {ann.date} WIB</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onDeleteAnnouncement(ann.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                      title="Hapus Pengumuman"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECTION 2: PENGUMUMAN REGULER KELAS */}
      {regularList.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Informasi &amp; Pengumuman Umum Kelas
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {regularList.map((ann) => (
              <div
                key={ann.id}
                className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-slate-300 shadow-xs flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700">
                      {ann.category}
                    </span>
                    <span className="text-[11px] text-slate-400">{ann.date}</span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900">
                    {ann.title}
                  </h4>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {ann.content}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span>Dari: <strong>{ann.sender} ({ann.senderName})</strong></span>
                  <button
                    onClick={() => onDeleteAnnouncement(ann.id)}
                    className="text-slate-400 hover:text-rose-600 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 3: CATATAN PENTING KELAS (Pinned Notes) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <div className="flex items-center gap-2">
            <span className="p-1 bg-indigo-100 text-indigo-700 rounded">
              <Pin className="w-4 h-4" />
            </span>
            <h3 className="text-base font-extrabold text-slate-900 tracking-tight">
              Catatan Penting, Tata Tertib &amp; Arsip Kelas
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-medium">
            {classNotes.length} Catatan Tersimpan
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {classNotes.map((note) => (
            <div
              key={note.id}
              id={`class-note-${note.id}`}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-indigo-50 text-indigo-700">
                    {note.category}
                  </span>
                  {note.pinned && (
                    <span className="flex items-center gap-1 text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">
                      <Pin className="w-3 h-3" /> Disematkan
                    </span>
                  )}
                </div>

                <h4 className="text-sm sm:text-base font-bold text-slate-900">
                  {note.title}
                </h4>

                <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                  {note.content}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>Penulis: <strong className="text-slate-600">{note.author}</strong></span>
                <div className="flex items-center gap-2">
                  <span>{note.dateUpdated}</span>
                  <button
                    onClick={() => onDeleteClassNote(note.id)}
                    className="text-slate-400 hover:text-rose-600 p-1 rounded"
                    title="Hapus Catatan"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CREATE ANNOUNCEMENT MODAL */}
      {showAnnModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Kirim Pengumuman Baru
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Siarkan pemberitahuan dari Wali Kelas atau Ketua Kelas ke seluruh siswa.
            </p>

            <form onSubmit={handleCreateAnnouncement} className="space-y-3.5 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jabatan Pengirim:
                  </label>
                  <select
                    value={annSender}
                    onChange={(e) => handleSenderChange(e.target.value as AnnouncementSender)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500 font-semibold"
                  >
                    <option value="Wali Kelas">Wali Kelas</option>
                    <option value="Ketua Kelas">Ketua Kelas</option>
                    <option value="Sekretaris">Sekretaris</option>
                    <option value="Bendahara">Bendahara</option>
                    <option value="Pengurus Kelas">Pengurus Kelas</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Pengirim:
                  </label>
                  <input
                    type="text"
                    required
                    value={annSenderName}
                    onChange={(e) => setAnnSenderName(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kategori Pengumuman:
                </label>
                <select
                  value={annCategory}
                  onChange={(e) => setAnnCategory(e.target.value as Announcement['category'])}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500"
                >
                  <option value="Mendesak">Mendesak / Darurat</option>
                  <option value="Akademik">Akademik &amp; Ulangan</option>
                  <option value="Kegiatan">Kegiatan Sekolah</option>
                  <option value="Keuangan">Kas &amp; Keuangan</option>
                  <option value="Tata Tertib">Tata Tertib &amp; Seragam</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Judul Pengumuman:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Jadwal Upacara Bendera & Kerapian Seragam"
                  value={annTitle}
                  onChange={(e) => setAnnTitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500 font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Isi Pesan Pengumuman:
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Tuliskan detail informasi atau instruksi yang harus dipatuhi..."
                  value={annContent}
                  onChange={(e) => setAnnContent(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              {/* Checkbox Urgent */}
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 flex items-center gap-2.5">
                <input
                  type="checkbox"
                  id="checkbox-urgent"
                  checked={annIsUrgent}
                  onChange={(e) => setAnnIsUrgent(e.target.checked)}
                  className="w-4 h-4 text-rose-600 rounded focus:ring-rose-500"
                />
                <label htmlFor="checkbox-urgent" className="text-xs font-bold text-rose-900 cursor-pointer">
                  Tandai sebagai Pengumuman Mendesak (Urgent Banner di atas)
                </label>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAnnModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs"
                >
                  Siarkan Sekarang
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE NOTE MODAL */}
      {showNoteModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Tambah Catatan Penting Kelas
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Simpan tata tertib, link drive belajar, atau arsip penting kelas X-7.26.
            </p>

            <form onSubmit={handleCreateNote} className="space-y-3.5 text-xs sm:text-sm">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kategori Catatan:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Tata Tertib / Akademik / Kas / Kegiatan"
                  value={noteCategory}
                  onChange={(e) => setNoteCategory(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Judul Catatan:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Link Google Drive Bank Soal Kelas"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Isi Catatan:
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Tuliskan catatan poin demi poin..."
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Pencatat / Penanggung Jawab:
                </label>
                <input
                  type="text"
                  value={noteAuthor}
                  onChange={(e) => setNoteAuthor(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowNoteModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
