import React, { useState } from 'react';
import { 
  SubjectItem, 
  DayOfWeek 
} from '../../types';
import { 
  Calendar, 
  Clock, 
  User, 
  MapPin, 
  BookOpen, 
  ExternalLink, 
  Info, 
  CheckCircle2, 
  Search,
  Plus,
  Edit,
  Trash2,
  X,
  Save,
  BookMarked
} from 'lucide-react';

interface ScheduleViewProps {
  schedule: SubjectItem[];
  isAdmin?: boolean;
  onAddSubject?: (subject: Omit<SubjectItem, 'id'>) => void;
  onUpdateSubject?: (id: string, updated: Partial<SubjectItem>) => void;
  onDeleteSubject?: (id: string) => void;
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({ 
  schedule,
  isAdmin = false,
  onAddSubject,
  onUpdateSubject,
  onDeleteSubject
}) => {
  const currentDayIndex = new Date().getDay();
  const dayNamesMap: Record<number, DayOfWeek> = {
    1: 'Senin',
    2: 'Selasa',
    3: 'Rabu',
    4: 'Kamis',
    5: 'Jumat'
  };
  const todayDayName: DayOfWeek = dayNamesMap[currentDayIndex] || 'Senin';

  const [activeDay, setActiveDay] = useState<DayOfWeek>(todayDayName);
  const [selectedSubject, setSelectedSubject] = useState<SubjectItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  // Modal edit/add state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSubjectId, setEditingSubjectId] = useState<string | null>(null);
  const [subjectToDelete, setSubjectToDelete] = useState<SubjectItem | null>(null);

  // Form fields
  const [formData, setFormData] = useState<{
    name: string;
    code: string;
    day: DayOfWeek;
    startTime: string;
    endTime: string;
    teacher: string;
    teacherNip: string;
    room: string;
    category: 'Wajib' | 'Peminatan' | 'Muatan Lokal' | 'Pengembangan Diri';
    description: string;
    currentTopic: string;
    syllabusRaw: string;
    referenceBooksRaw: string;
    classroomLink: string;
  }>({
    name: '',
    code: '',
    day: activeDay,
    startTime: '07.00',
    endTime: '08.30',
    teacher: '',
    teacherNip: '',
    room: 'Ruang X-7',
    category: 'Wajib',
    description: '',
    currentTopic: '',
    syllabusRaw: '',
    referenceBooksRaw: '',
    classroomLink: ''
  });

  const daysList: DayOfWeek[] = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat'];

  const filteredDaySubjects = schedule.filter((s) => {
    const isDay = s.day === activeDay;
    const matchQuery = 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.teacher.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.currentTopic.toLowerCase().includes(searchQuery.toLowerCase());
    const matchCategory = filterCategory === 'all' || s.category === filterCategory;

    return isDay && matchQuery && matchCategory;
  });

  const handleOpenAddModal = () => {
    setEditingSubjectId(null);
    setFormData({
      name: '',
      code: '',
      day: activeDay,
      startTime: '07.00',
      endTime: '08.30',
      teacher: '',
      teacherNip: '',
      room: 'Ruang Kelas X-7',
      category: 'Wajib',
      description: '',
      currentTopic: '',
      syllabusRaw: '',
      referenceBooksRaw: '',
      classroomLink: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (subject: SubjectItem) => {
    setEditingSubjectId(subject.id);
    setFormData({
      name: subject.name,
      code: subject.code,
      day: subject.day,
      startTime: subject.startTime,
      endTime: subject.endTime,
      teacher: subject.teacher,
      teacherNip: subject.teacherNip || '',
      room: subject.room,
      category: subject.category,
      description: subject.description,
      currentTopic: subject.currentTopic,
      syllabusRaw: subject.syllabusTopics.join('\n'),
      referenceBooksRaw: subject.referenceBooks.join('\n'),
      classroomLink: subject.classroomLink || ''
    });
    setIsModalOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    const syllabusTopics = formData.syllabusRaw
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const referenceBooks = formData.referenceBooksRaw
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const payload = {
      name: formData.name.trim(),
      code: formData.code.trim() || formData.name.substring(0, 4).toUpperCase(),
      day: formData.day,
      startTime: formData.startTime.trim(),
      endTime: formData.endTime.trim(),
      teacher: formData.teacher.trim(),
      teacherNip: formData.teacherNip.trim() || undefined,
      room: formData.room.trim(),
      category: formData.category,
      description: formData.description.trim() || `Mata pelajaran ${formData.name}`,
      currentTopic: formData.currentTopic.trim() || 'Pembahasan Materi Baru',
      syllabusTopics: syllabusTopics.length > 0 ? syllabusTopics : ['Materi Pokok 1', 'Materi Pokok 2'],
      referenceBooks: referenceBooks.length > 0 ? referenceBooks : ['Buku Paket Kemendikbud'],
      classroomLink: formData.classroomLink.trim() || undefined
    };

    if (editingSubjectId) {
      if (onUpdateSubject) {
        onUpdateSubject(editingSubjectId, payload);
      }
    } else {
      if (onAddSubject) {
        onAddSubject(payload);
      }
    }

    setIsModalOpen(false);
  };

  const handleDeleteSubjectClick = (subject: SubjectItem) => {
    if (!isAdmin) return;
    setSubjectToDelete(subject);
  };

  const handleConfirmDeleteSubject = () => {
    if (subjectToDelete && onDeleteSubject) {
      onDeleteSubject(subjectToDelete.id);
      setSubjectToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-xl shadow-xs">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Jadwal Mata Pelajaran &amp; Info Silabus
              </h2>
              <span className="px-2 py-0.5 text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200 rounded-md">
                Kurikulum Merdeka
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Alokasi waktu, nama guru pengampu, ruang kelas, dan materi silabus
            </p>
          </div>
        </div>

        {/* Search and Admin Add Button */}
        <div className="flex flex-wrap items-center gap-2">
          {isAdmin && (
            <button
              id="btn-add-subject"
              onClick={handleOpenAddModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Tambah Jadwal Mapel</span>
            </button>
          )}

          <div className="relative w-full sm:w-56">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari mapel / guru..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Day Selector Buttons */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {daysList.map((day) => {
          const isToday = day === todayDayName;
          const isSelected = day === activeDay;
          const count = schedule.filter((s) => s.day === day).length;

          return (
            <button
              key={day}
              id={`btn-schedule-day-${day}`}
              onClick={() => setActiveDay(day)}
              className={`flex-1 min-w-[120px] p-3 rounded-xl border text-center transition select-none ${
                isSelected
                  ? 'bg-[#1E1B4B] text-white border-[#1E1B4B] shadow-sm'
                  : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-center gap-1.5">
                <span className="font-bold text-sm">{day}</span>
                {isToday && (
                  <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-amber-400' : 'bg-indigo-600'}`} />
                )}
              </div>
              <span className="text-[11px] opacity-75 block mt-0.5">
                {count} Sesi Pelajaran
              </span>
            </button>
          );
        })}
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 text-xs overflow-x-auto pb-1">
        <span className="text-slate-400 font-semibold shrink-0">Kategori:</span>
        {['all', 'Wajib', 'Peminatan', 'Muatan Lokal', 'Pengembangan Diri'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition shrink-0 ${
              filterCategory === cat
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {cat === 'all' ? 'Semua' : cat}
          </button>
        ))}
      </div>

      {/* Subject Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDaySubjects.length === 0 ? (
          <div className="col-span-full py-12 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-sm">
            <p className="font-bold text-slate-600">Tidak ada jadwal mata pelajaran untuk hari {activeDay}.</p>
            {isAdmin && (
              <button
                onClick={handleOpenAddModal}
                className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah Jadwal Mapel Hari {activeDay}</span>
              </button>
            )}
          </div>
        ) : (
          filteredDaySubjects.map((subject, index) => {
            return (
              <div
                key={subject.id}
                id={`subject-card-${subject.id}`}
                className="bg-white rounded-2xl border border-slate-200/90 hover:border-indigo-300 shadow-xs hover:shadow-md transition-all p-5 flex flex-col justify-between group"
              >
                <div>
                  {/* Top info badge & Admin actions */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-slate-100 text-slate-700 tracking-wider">
                        SESI #{index + 1}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        subject.category === 'Wajib' ? 'bg-blue-50 text-blue-700' :
                        subject.category === 'Peminatan' ? 'bg-purple-50 text-purple-700' :
                        subject.category === 'Muatan Lokal' ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'
                      }`}>
                        {subject.category}
                      </span>
                    </div>

                    {isAdmin && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleOpenEditModal(subject)}
                          className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition"
                          title="Edit Jadwal Mapel"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteSubjectClick(subject)}
                          className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition"
                          title="Hapus Jadwal Mapel"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Subject Name & Code */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[11px] font-mono font-bold text-indigo-600 tracking-wider">
                        {subject.code}
                      </span>
                      <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                        {subject.name}
                      </h3>
                    </div>
                  </div>

                  {/* Time and Room */}
                  <div className="mt-3 space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-semibold text-slate-900">
                        {subject.startTime} - {subject.endTime} WIB
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{subject.room}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-medium text-slate-800 truncate">{subject.teacher}</span>
                    </div>
                  </div>

                  {/* Current Topic Highlight */}
                  <div className="mt-3.5 p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-[11px]">
                    <span className="font-bold text-slate-700 block mb-0.5">Topik Saat Ini:</span>
                    <p className="text-slate-600 line-clamp-2 leading-relaxed">
                      {subject.currentTopic}
                    </p>
                  </div>
                </div>

                {/* Bottom Action: Detail Info modal button */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => setSelectedSubject(subject)}
                    className="w-full flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold text-indigo-700 hover:text-white bg-indigo-50 hover:bg-indigo-600 rounded-xl transition"
                  >
                    <Info className="w-3.5 h-3.5" />
                    <span>Lihat Info &amp; Silabus Lengkap</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Subject Detail Modal (Student & Admin Read Mode) */}
      {selectedSubject && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-xl w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-indigo-100 text-indigo-800">
                    {selectedSubject.code}
                  </span>
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-slate-100 text-slate-700">
                    {selectedSubject.category}
                  </span>
                </div>
                <h3 className="text-xl font-extrabold text-slate-900 mt-1">
                  {selectedSubject.name}
                </h3>
                <span className="text-xs text-slate-500 font-medium">
                  {selectedSubject.day}, {selectedSubject.startTime} - {selectedSubject.endTime} WIB di {selectedSubject.room}
                </span>
              </div>

              <button
                onClick={() => setSelectedSubject(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="mt-4 space-y-4 text-xs sm:text-sm">
              
              {/* Teacher Info */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Guru Pengajar
                </span>
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-indigo-600" />
                  <div>
                    <span className="font-bold text-slate-900 text-sm block">
                      {selectedSubject.teacher}
                    </span>
                    {selectedSubject.teacherNip && (
                      <span className="text-[11px] text-slate-500 font-mono">
                        NIP: {selectedSubject.teacherNip}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <h4 className="font-bold text-slate-900 mb-1 text-xs uppercase tracking-wider text-slate-400">
                  Deskripsi Mata Pelajaran
                </h4>
                <p className="text-slate-600 leading-relaxed text-xs">
                  {selectedSubject.description}
                </p>
              </div>

              {/* Current Topic */}
              <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl">
                <span className="text-[10px] font-bold uppercase text-indigo-800 tracking-wider block mb-1">
                  🎯 Topik / Bab Yang Sedang Dipelajari
                </span>
                <p className="text-xs font-semibold text-indigo-950">
                  {selectedSubject.currentTopic}
                </p>
              </div>

              {/* Syllabus / Materi Semester */}
              <div>
                <h4 className="font-bold text-slate-900 mb-2 text-xs uppercase tracking-wider text-slate-400">
                  Silabus Pokok Bahasan Semester
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedSubject.syllabusTopics.map((topic, tIdx) => (
                    <div key={tIdx} className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg text-xs font-medium text-slate-700">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{topic}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reference Books */}
              <div>
                <h4 className="font-bold text-slate-900 mb-1 text-xs uppercase tracking-wider text-slate-400">
                  Buku Referensi &amp; Modul Pegangan
                </h4>
                <ul className="text-xs text-slate-600 space-y-1">
                  {selectedSubject.referenceBooks.map((book, bIdx) => (
                    <li key={bIdx} className="flex items-start gap-1.5">
                      <BookOpen className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <span>{book}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Classroom Link if any */}
              {selectedSubject.classroomLink && (
                <div className="pt-2">
                  <a
                    href={selectedSubject.classroomLink}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Buka Google Classroom / Bahan Ajar</span>
                  </a>
                </div>
              )}

            </div>

            <div className="mt-6 flex items-center justify-between pt-3 border-t border-slate-100">
              {isAdmin && (
                <button
                  onClick={() => {
                    const subj = selectedSubject;
                    setSelectedSubject(null);
                    handleOpenEditModal(subj);
                  }}
                  className="px-3 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition"
                >
                  Edit Data Mapel Ini
                </button>
              )}
              <button
                onClick={() => setSelectedSubject(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition ml-auto"
              >
                Tutup
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Admin: Add / Edit Subject Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                  <BookMarked className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {editingSubjectId ? 'Edit Jadwal Mata Pelajaran' : 'Tambah Jadwal Mata Pelajaran Baru'}
                  </h3>
                  <span className="text-xs text-slate-500">Pengaturan jadwal, guru, ruang, dan silabus</span>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Mata Pelajaran *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Matematika Wajib / Biologi"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Kode Mapel
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: MTK-W / BIO"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Hari
                  </label>
                  <select
                    value={formData.day}
                    onChange={(e) => setFormData({ ...formData, day: e.target.value as DayOfWeek })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {daysList.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jam Mulai
                  </label>
                  <input
                    type="text"
                    placeholder="07.00"
                    value={formData.startTime}
                    onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jam Selesai
                  </label>
                  <input
                    type="text"
                    placeholder="08.30"
                    value={formData.endTime}
                    onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Guru Pengampu
                  </label>
                  <input
                    type="text"
                    placeholder="Nama Guru &amp; Gelar"
                    value={formData.teacher}
                    onChange={(e) => setFormData({ ...formData, teacher: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    NIP Guru (Opsional)
                  </label>
                  <input
                    type="text"
                    placeholder="198203..."
                    value={formData.teacherNip}
                    onChange={(e) => setFormData({ ...formData, teacherNip: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Ruangan / Lab
                  </label>
                  <input
                    type="text"
                    placeholder="Ruang X-7 / Lab Fisika"
                    value={formData.room}
                    onChange={(e) => setFormData({ ...formData, room: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Kategori Mapel
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Wajib">Wajib</option>
                    <option value="Peminatan">Peminatan</option>
                    <option value="Muatan Lokal">Muatan Lokal</option>
                    <option value="Pengembangan Diri">Pengembangan Diri</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Link Google Classroom / Modul (Opsional)
                  </label>
                  <input
                    type="url"
                    placeholder="https://classroom.google.com/..."
                    value={formData.classroomLink}
                    onChange={(e) => setFormData({ ...formData, classroomLink: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Topik / Bab Yang Sedang Dipelajari Saat Ini
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Bab 3: Matriks dan Sistem Persamaan Linear Tiga Variabel"
                  value={formData.currentTopic}
                  onChange={(e) => setFormData({ ...formData, currentTopic: e.target.value })}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Deskripsi / Ringkasan Mata Pelajaran
                </label>
                <textarea
                  rows={2}
                  placeholder="Deskripsi singkat mengenai mata pelajaran ini..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Silabus Pokok Bahasan (1 topik per baris)
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Persamaan Linear&#10;Trigonometri Dasar&#10;Vektor &amp; Matriks"
                    value={formData.syllabusRaw}
                    onChange={(e) => setFormData({ ...formData, syllabusRaw: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Buku Referensi &amp; Pegangan (1 per baris)
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Buku Matematika Kelas X Kemdikbudristek (2024)&#10;Modul Pengayaan Erlangga"
                    value={formData.referenceBooksRaw}
                    onChange={(e) => setFormData({ ...formData, referenceBooksRaw: e.target.value })}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-xs flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan Jadwal Mapel</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Delete Subject Confirmation Modal */}
      {subjectToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-600 mb-3">
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-100">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Hapus Jadwal Mata Pelajaran?
                </h3>
                <span className="text-xs text-slate-500">Konfirmasi Penghapusan</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5">
              Apakah Anda yakin ingin menghapus jadwal <strong>&quot;{subjectToDelete.name}&quot;</strong> (Hari {subjectToDelete.day}, pukul {subjectToDelete.startTime} - {subjectToDelete.endTime} WIB)?
            </p>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSubjectToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteSubject}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-xs"
              >
                Ya, Hapus Jadwal
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
