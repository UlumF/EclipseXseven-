import React, { useState } from 'react';
import { 
  PiketDaySchedule, 
  DayOfWeek,
  Student
} from '../../types';
import { 
  Sparkles, 
  CheckCircle, 
  Circle, 
  Calendar, 
  Star, 
  ArrowLeftRight, 
  Plus, 
  CheckCheck,
  Award,
  Edit,
  Trash2,
  X,
  Save,
  Users,
  UserPlus
} from 'lucide-react';

interface PiketViewProps {
  piketSchedule: PiketDaySchedule[];
  students?: Student[];
  isAdmin?: boolean;
  onToggleTask: (day: DayOfWeek, taskId: string) => void;
  onAddTask: (day: DayOfWeek, taskLabel: string) => void;
  onDeleteTask?: (day: DayOfWeek, taskId: string) => void;
  onUpdatePiketDaySchedule?: (day: DayOfWeek, updated: Partial<PiketDaySchedule>) => void;
  onSwapMembers: (dayA: DayOfWeek, memberA: string, dayB: DayOfWeek, memberB: string) => void;
  onOpenLoginModal?: () => void;
}

export const PiketView: React.FC<PiketViewProps> = ({
  piketSchedule,
  students = [],
  isAdmin = false,
  onToggleTask,
  onAddTask,
  onDeleteTask,
  onUpdatePiketDaySchedule,
  onSwapMembers,
  onOpenLoginModal
}) => {
  // Determine current day of week in Indonesian
  const currentDayIndex = new Date().getDay(); // 0 is Sun, 1 is Mon...
  const dayNamesMap: Record<number, DayOfWeek> = {
    1: 'Senin',
    2: 'Selasa',
    3: 'Rabu',
    4: 'Kamis',
    5: 'Jumat'
  };
  const todayDayName: DayOfWeek = dayNamesMap[currentDayIndex] || 'Senin';

  const [activeDay, setActiveDay] = useState<DayOfWeek>(todayDayName);
  const [showSwapModal, setShowSwapModal] = useState(false);
  const [showEditScheduleModal, setShowEditScheduleModal] = useState(false);
  const [newTaskInput, setNewTaskInput] = useState('');
  const [showAddTaskInput, setShowAddTaskInput] = useState(false);

  // Edit schedule modal state for active day
  const [editCoordinator, setEditCoordinator] = useState('');
  const [editMembers, setEditMembers] = useState<string[]>([]);
  const [editScore, setEditScore] = useState<number>(95);
  const [newMemberInput, setNewMemberInput] = useState('');

  // Swap modal state
  const [swapDayA, setSwapDayA] = useState<DayOfWeek>('Senin');
  const [swapMemberA, setSwapMemberA] = useState<string>('');
  const [swapDayB, setSwapDayB] = useState<DayOfWeek>('Selasa');
  const [swapMemberB, setSwapMemberB] = useState<string>('');

  const currentSchedule = piketSchedule.find((p) => p.day === activeDay) || piketSchedule[0];

  const handleAddNewTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskInput.trim()) {
      onAddTask(activeDay, newTaskInput.trim());
      setNewTaskInput('');
      setShowAddTaskInput(false);
    }
  };

  const handleExecuteSwap = () => {
    if (swapMemberA && swapMemberB && swapDayA !== swapDayB) {
      onSwapMembers(swapDayA, swapMemberA, swapDayB, swapMemberB);
      setShowSwapModal(false);
    }
  };

  const handleOpenEditModal = () => {
    setEditCoordinator(currentSchedule.coordinator);
    setEditMembers([...currentSchedule.members]);
    setEditScore(currentSchedule.cleanlinessScore || 95);
    setShowEditScheduleModal(true);
  };

  const handleSaveScheduleEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onUpdatePiketDaySchedule) {
      onUpdatePiketDaySchedule(activeDay, {
        coordinator: editCoordinator.trim() || (editMembers[0] || 'Koordinator Piket'),
        members: editMembers,
        cleanlinessScore: Number(editScore) || 90
      });
    }
    setShowEditScheduleModal(false);
  };

  const handleAddMemberToEdit = () => {
    if (newMemberInput.trim() && !editMembers.includes(newMemberInput.trim())) {
      const updated = [...editMembers, newMemberInput.trim()];
      setEditMembers(updated);
      if (!editCoordinator) {
        setEditCoordinator(newMemberInput.trim());
      }
      setNewMemberInput('');
    }
  };

  const handleRemoveMemberFromEdit = (memberToRemove: string) => {
    const updated = editMembers.filter((m) => m !== memberToRemove);
    setEditMembers(updated);
    if (editCoordinator === memberToRemove) {
      setEditCoordinator(updated[0] || '');
    }
  };

  const daysList: DayOfWeek[] = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat'];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-xl shadow-xs">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Jadwal Piket Kebersihan X-7.26
              </h2>
              <span className="px-2 py-0.5 text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-md">
                Senin - Jum&apos;at
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Pengaturan jadwal petugas kebersihan harian &amp; checklist tugas piket
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {isAdmin && (
            <button
              id="btn-edit-piket-schedule"
              onClick={handleOpenEditModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-xs"
            >
              <Edit className="w-3.5 h-3.5" />
              <span>Ubah Petugas Piket Hari {activeDay}</span>
            </button>
          )}

          <button
            id="btn-open-swap-modal"
            onClick={() => {
              const dayA = piketSchedule[0]?.day || 'Senin';
              const dayB = piketSchedule[1]?.day || 'Selasa';
              setSwapDayA(dayA);
              setSwapMemberA(piketSchedule[0]?.members[0] || '');
              setSwapDayB(dayB);
              setSwapMemberB(piketSchedule[1]?.members[0] || '');
              setShowSwapModal(true);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 rounded-xl transition"
          >
            <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-600" />
            <span>Tukar Jadwal Piket</span>
          </button>
        </div>
      </div>

      {/* Day Tabs Switcher */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 sm:gap-3">
        {daysList.map((day) => {
          const schedule = piketSchedule.find((p) => p.day === day);
          const isToday = day === todayDayName;
          const isSelected = day === activeDay;
          const completedCount = schedule?.tasks.filter((t) => t.completed).length || 0;
          const totalCount = schedule?.tasks.length || 0;
          const isAllDone = completedCount === totalCount && totalCount > 0;

          return (
            <button
              key={day}
              id={`piket-tab-${day}`}
              onClick={() => setActiveDay(day)}
              className={`p-3.5 sm:p-4 rounded-xl border text-left transition relative select-none ${
                isSelected
                  ? 'bg-[#1E1B4B] text-white border-[#1E1B4B] shadow-md scale-[1.02]'
                  : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm sm:text-base">{day}</span>
                {isToday && (
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    isSelected ? 'bg-amber-400 text-slate-950' : 'bg-amber-100 text-amber-800'
                  }`}>
                    Hari Ini
                  </span>
                )}
              </div>

              <div className="mt-2 text-[11px] opacity-80 flex items-center justify-between">
                <span>{schedule?.members.length || 0} Petugas</span>
                {isAllDone && (
                  <span className="flex items-center gap-0.5 text-emerald-400 font-bold">
                    <CheckCheck className="w-3 h-3" /> Selesai
                  </span>
                )}
              </div>

              {/* Progress bar inside card */}
              <div className="mt-2 w-full bg-slate-200/50 rounded-full h-1.5 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-300 ${
                    isSelected ? 'bg-emerald-400' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${totalCount > 0 ? (completedCount / totalCount) * 100 : 0}%` }}
                />
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Day Detail Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Petugas Piket Cards */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Daftar Petugas
                </span>
                <h3 className="text-lg font-extrabold text-slate-900">
                  Piket Hari {currentSchedule.day}
                </h3>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700">
                  {currentSchedule.members.length} Siswa
                </span>
                {isAdmin && (
                  <button
                    onClick={handleOpenEditModal}
                    className="p-1 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 transition"
                    title="Ubah Petugas Piket"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Coordinator highlight */}
            <div className="mb-4 p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl flex items-center gap-3">
              <div className="p-2 bg-amber-500 text-white rounded-lg">
                <Award className="w-4 h-4" />
              </div>
              <div className="min-w-0 flex-1">
                <span className="text-[10px] font-bold uppercase text-amber-700 tracking-wider">
                  Koordinator Piket
                </span>
                <div className="text-xs font-bold text-slate-900 truncate">
                  {currentSchedule.coordinator || '(Belum Ditentukan)'}
                </div>
              </div>
            </div>

            {/* Member List */}
            <div className="space-y-2">
              {currentSchedule.members.length === 0 ? (
                <div className="p-4 bg-slate-50 rounded-xl text-center text-xs text-slate-400">
                  Belum ada petugas piket untuk hari ini.
                  {isAdmin && (
                    <button
                      onClick={handleOpenEditModal}
                      className="block mx-auto mt-2 text-indigo-600 font-bold hover:underline"
                    >
                      + Tambah Petugas Piket
                    </button>
                  )}
                </div>
              ) : (
                currentSchedule.members.map((member, idx) => {
                  const isCoordinator = member === currentSchedule.coordinator;
                  return (
                    <div
                      key={idx}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-xs font-semibold transition ${
                        isCoordinator 
                          ? 'bg-indigo-50/60 border-indigo-200 text-indigo-950' 
                          : 'bg-slate-50 border-slate-100 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className="truncate">{member}</span>
                      </div>
                      {isCoordinator && (
                        <span className="text-[10px] px-1.5 py-0.5 bg-indigo-600 text-white font-bold rounded shrink-0">
                          Ketua
                        </span>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>Petugas piket wajib hadir sebelum pukul 06.40 WIB.</span>
            </div>
          </div>

          {/* Cleanliness rating card */}
          <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white p-5 rounded-2xl shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-indigo-200">Indeks Kebersihan Kelas</span>
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-black">{currentSchedule.cleanlinessScore || 95}/100</span>
              <span className="text-xs text-emerald-400 font-bold">Kategori Sangat Bersih</span>
            </div>
            <p className="mt-2 text-xs text-indigo-200/80 leading-relaxed">
              Penilaian dilakukan oleh Seksi Kebersihan &amp; Wali Kelas setiap pagi dan saat jam pulang.
            </p>
          </div>
        </div>

        {/* Right Column: Duty Checklist */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-5">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Daftar Tugas &amp; Checklist
                </span>
                <h3 className="text-lg font-bold text-slate-900">
                  Checklist Pekerjaan Piket {currentSchedule.day}
                </h3>
              </div>
              
              <button
                onClick={() => setShowAddTaskInput(!showAddTaskInput)}
                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah Tugas</span>
              </button>
            </div>

            {/* Add task input inline */}
            {showAddTaskInput && (
              <form onSubmit={handleAddNewTask} className="mb-4 flex items-center gap-2 p-2 bg-slate-50 rounded-xl border border-indigo-200">
                <input
                  type="text"
                  placeholder="Contoh: Mengisi air dispenser galon / Merapikan loker belakang"
                  value={newTaskInput}
                  onChange={(e) => setNewTaskInput(e.target.value)}
                  className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  autoFocus
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
                >
                  Simpan
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddTaskInput(false)}
                  className="px-2 py-1.5 text-xs text-slate-500 hover:text-slate-700"
                >
                  Batal
                </button>
              </form>
            )}

            {/* Task list items */}
            <div className="space-y-3">
              {currentSchedule.tasks.map((task) => (
                <div
                  key={task.id}
                  id={`task-${task.id}`}
                  className={`flex items-start gap-3.5 p-3.5 rounded-xl border transition select-none ${
                    task.completed
                      ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
                      : 'bg-slate-50/80 border-slate-200 text-slate-800 hover:bg-slate-100/70'
                  }`}
                >
                  <button 
                    onClick={() => onToggleTask(currentSchedule.day, task.id)}
                    className="mt-0.5 shrink-0"
                  >
                    {task.completed ? (
                      <CheckCircle className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-400 hover:text-slate-600" />
                    )}
                  </button>
                  
                  <div 
                    onClick={() => onToggleTask(currentSchedule.day, task.id)}
                    className="flex-1 cursor-pointer"
                  >
                    <span className={`text-xs sm:text-sm font-semibold ${task.completed ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                      {task.label}
                    </span>
                  </div>

                  {task.completed && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-200/70 text-emerald-800 rounded">
                      Selesai
                    </span>
                  )}

                  {isAdmin && onDeleteTask && (
                    <button
                      onClick={() => onDeleteTask(currentSchedule.day, task.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                      title="Hapus Tugas Ini"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* SOP Ketertiban Piket */}
            <div className="mt-6 p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1.5">
              <div className="font-bold text-slate-800 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>SOP Kebersihan Kelas X-7.26:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-600">
                <li>Piket pagi dimulai pukul 06.30 - 06.50 WIB (sebelum guru masuk).</li>
                <li>Piket pulang dilakukan setelah doa penutup sampai kelas terkunci aman.</li>
                <li>Jika berhalangan, wajib lapor koordinator &amp; menukar jadwal dengan teman lain.</li>
              </ul>
            </div>

          </div>
        </div>

      </div>

      {/* Admin: Edit Piket Day Schedule Modal */}
      {showEditScheduleModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                  <Edit className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Ubah Jadwal Piket Hari {activeDay}
                  </h3>
                  <span className="text-xs text-slate-500">Kelola koordinator, petugas, dan nilai kebersihan</span>
                </div>
              </div>
              <button
                onClick={() => setShowEditScheduleModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveScheduleEdit} className="space-y-4 text-xs sm:text-sm">
              
              {/* Koordinator */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Koordinator / Ketua Piket Hari {activeDay}:
                </label>
                <input
                  type="text"
                  placeholder="Nama Koordinator Piket"
                  value={editCoordinator}
                  onChange={(e) => setEditCoordinator(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Nilai Kebersihan */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nilai Kebersihan (0 - 100):
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={editScore}
                  onChange={(e) => setEditScore(Number(e.target.value))}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Anggota Petugas */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Daftar Petugas Piket ({editMembers.length} Orang):
                </label>

                {/* Add member input */}
                <div className="flex items-center gap-2 mb-3">
                  <input
                    type="text"
                    placeholder="Ketik nama siswa..."
                    value={newMemberInput}
                    onChange={(e) => setNewMemberInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddMemberToEdit();
                      }
                    }}
                    className="flex-1 p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={handleAddMemberToEdit}
                    className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambah</span>
                  </button>
                </div>

                {/* Quick Select from Registered Students */}
                {students.length > 0 && (
                  <div className="mb-3">
                    <span className="text-[11px] text-slate-400 block mb-1">
                      Atau pilih cepat dari siswa terdaftar:
                    </span>
                    <select
                      onChange={(e) => {
                        if (e.target.value && !editMembers.includes(e.target.value)) {
                          setEditMembers([...editMembers, e.target.value]);
                          if (!editCoordinator) setEditCoordinator(e.target.value);
                        }
                      }}
                      defaultValue=""
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                    >
                      <option value="" disabled>-- Pilih Siswa Kelas X-7.26 --</option>
                      {students.map((s) => (
                        <option key={s.id} value={s.name}>{s.name} ({s.gender})</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* List of current members */}
                <div className="space-y-1.5 max-h-48 overflow-y-auto p-2 bg-slate-50 rounded-xl border border-slate-200">
                  {editMembers.length === 0 ? (
                    <div className="text-center py-4 text-xs text-slate-400">
                      Belum ada petugas ditambahkan.
                    </div>
                  ) : (
                    editMembers.map((member, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-2 bg-white rounded-lg border border-slate-200 text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-400 text-[10px] w-4">{idx + 1}.</span>
                          <span className="font-semibold text-slate-800">{member}</span>
                          {member === editCoordinator && (
                            <span className="text-[10px] px-1.5 bg-amber-100 text-amber-800 rounded font-bold">Koordinator</span>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          {member !== editCoordinator && (
                            <button
                              type="button"
                              onClick={() => setEditCoordinator(member)}
                              className="text-[10px] px-1.5 py-0.5 bg-slate-100 hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 rounded transition font-medium"
                              title="Jadikan Koordinator"
                            >
                              Set Koordinator
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleRemoveMemberFromEdit(member)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEditScheduleModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-xs flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan Perubahan Jadwal</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Swap Modal */}
      {showSwapModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Tukar Jadwal Piket Siswa
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Pilih hari dan nama siswa yang akan saling bertukar jadwal piket.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Petugas A */}
              <div className="space-y-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-slate-700">Siswa Pertama:</span>
                <div>
                  <label className="text-[11px] text-slate-500">Pilih Hari Asal:</label>
                  <select
                    value={swapDayA}
                    onChange={(e) => {
                      const day = e.target.value as DayOfWeek;
                      setSwapDayA(day);
                      const sched = piketSchedule.find((p) => p.day === day);
                      setSwapMemberA(sched?.members[0] || '');
                    }}
                    className="w-full mt-1 p-2 text-xs bg-white border border-slate-200 rounded-lg"
                  >
                    {daysList.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] text-slate-500">Pilih Nama Siswa:</label>
                  <select
                    value={swapMemberA}
                    onChange={(e) => setSwapMemberA(e.target.value)}
                    className="w-full mt-1 p-2 text-xs bg-white border border-slate-200 rounded-lg"
                  >
                    {piketSchedule.find((p) => p.day === swapDayA)?.members.map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Petugas B */}
              <div className="space-y-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-slate-700">Siswa Pengganti:</span>
                <div>
                  <label className="text-[11px] text-slate-500">Pilih Hari Tujuan:</label>
                  <select
                    value={swapDayB}
                    onChange={(e) => {
                      const day = e.target.value as DayOfWeek;
                      setSwapDayB(day);
                      const sched = piketSchedule.find((p) => p.day === day);
                      setSwapMemberB(sched?.members[0] || '');
                    }}
                    className="w-full mt-1 p-2 text-xs bg-white border border-slate-200 rounded-lg"
                  >
                    {daysList.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] text-slate-500">Pilih Nama Siswa:</label>
                  <select
                    value={swapMemberB}
                    onChange={(e) => setSwapMemberB(e.target.value)}
                    className="w-full mt-1 p-2 text-xs bg-white border border-slate-200 rounded-lg"
                  >
                    {piketSchedule.find((p) => p.day === swapDayB)?.members.map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setShowSwapModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Batal
              </button>
              <button
                onClick={handleExecuteSwap}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg"
              >
                Tukar Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
