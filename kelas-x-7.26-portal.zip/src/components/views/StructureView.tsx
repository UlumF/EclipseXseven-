import React, { useState } from 'react';
import { 
  ClassStructure, 
  Officer 
} from '../../types';
import { 
  BookOpen, 
  Phone, 
  Quote, 
  ShieldCheck, 
  Award, 
  CheckCircle, 
  X, 
  Target,
  Palette,
  Edit,
  Plus,
  Layers,
  Sparkles,
  UserCheck
} from 'lucide-react';
import { StructureEditModal } from '../StructureEditModal';

interface StructureViewProps {
  structure: ClassStructure;
  isAdmin?: boolean;
  onOpenCustomizer?: () => void;
  onSaveStructure?: (newStructure: ClassStructure) => void;
  onClearStructure?: () => void;
}

export const StructureView: React.FC<StructureViewProps> = ({ 
  structure,
  isAdmin = false,
  onOpenCustomizer,
  onSaveStructure,
  onClearStructure
}) => {
  const [selectedOfficer, setSelectedOfficer] = useState<Officer | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);

  const {
    waliKelas,
    ketuaKelas,
    wakilKetua,
    sekretaris1,
    sekretaris2,
    bendahara1,
    bendahara2,
    departments = [],
    motto,
    visi
  } = structure;

  const isStructureEmpty = 
    !waliKelas?.name && 
    !ketuaKelas?.name && 
    !wakilKetua?.name && 
    !sekretaris1?.name && 
    !bendahara1?.name && 
    departments.length === 0;

  return (
    <div className="space-y-6">
      {/* Top Banner with Class Motto */}
      <div className="p-6 bg-gradient-to-r from-[#1E1B4B] via-indigo-900 to-slate-900 text-white rounded-2xl shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-indigo-200 text-xs font-semibold backdrop-blur-xs mb-3">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>Struktur Organisasi Kelas X-7.26</span>
          </div>
          
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            {motto ? `“${motto}”` : 'Kelas X-7.26'}
          </h2>
          
          <p className="mt-2 text-xs sm:text-sm text-indigo-200/90 leading-relaxed">
            <span className="font-bold text-white">Visi Kelas: </span>
            {visi || 'Mewujudkan kelas yang solid, berprestasi, dan berakhlak mulia.'}
          </p>

          {isAdmin && (
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <button
                onClick={() => setIsEditModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs transition shadow-sm"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Isi &amp; Edit Struktur Manual</span>
              </button>

              {onOpenCustomizer && (
                <button
                  onClick={onOpenCustomizer}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/20 hover:bg-white/30 text-white rounded-xl text-xs font-semibold transition border border-white/30"
                >
                  <Palette className="w-3.5 h-3.5 text-indigo-200" />
                  <span>Kustomisasi Tampilan Web</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* If completely empty */}
      {isStructureEmpty ? (
        <div className="p-8 sm:p-12 text-center bg-white rounded-2xl border-2 border-dashed border-slate-200 shadow-xs space-y-4">
          <div className="w-16 h-16 mx-auto rounded-full bg-indigo-50 border border-indigo-200 flex items-center justify-center text-3xl">
            📋
          </div>
          <div className="max-w-md mx-auto">
            <h3 className="text-lg font-bold text-slate-900">
              Data Struktur Organisasi Masih Kosong
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              {isAdmin
                ? 'Semua data struktur organisasi sebelumnya telah dibersihkan. Anda dapat mengisi nama Wali Kelas, Ketua, Sekretaris, Bendahara, serta Seksi Bidang secara manual sekarang.'
                : 'Data kepengurusan kelas X-7.26 sedang diperbarui oleh Pengurus Kelas & Wali Kelas.'}
            </p>
          </div>

          {isAdmin && (
            <button
              onClick={() => setIsEditModalOpen(true)}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Isi Data Struktur Organisasi Sekarang</span>
            </button>
          )}
        </div>
      ) : (
        /* Structure Flow Layout */
        <div className="space-y-8">
          
          {/* Tier 1: Wali Kelas */}
          <div className="flex flex-col items-center">
            <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400 mb-2">
              Pembimbing &amp; Wali Kelas
            </span>
            <div
              id="officer-wali-kelas"
              onClick={() => setSelectedOfficer(waliKelas)}
              className="w-full max-w-md p-5 bg-white rounded-2xl border-2 border-indigo-600 shadow-md hover:shadow-lg transition-all cursor-pointer group text-center hover:scale-[1.01]"
            >
              <div className="w-16 h-16 mx-auto rounded-full bg-indigo-50 border-2 border-indigo-200 flex items-center justify-center text-3xl shadow-xs group-hover:rotate-6 transition-transform">
                {waliKelas?.avatar || '👩‍🏫'}
              </div>
              <div className="mt-3">
                <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-100 text-indigo-800 uppercase tracking-wide">
                  {waliKelas?.role || 'Wali Kelas'}
                </span>
                <h3 className="text-base sm:text-lg font-extrabold text-slate-900 mt-1">
                  {waliKelas?.name || '(Nama Wali Kelas Belum Diisi)'}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2 mt-1">
                  {waliKelas?.description || 'Pembimbing resmi kelas X-7.26'}
                </p>
              </div>
              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-center gap-1 text-[11px] font-semibold text-indigo-600">
                <span>Klik untuk profil &amp; detail</span>
              </div>
            </div>

            {/* Connecting line */}
            <div className="w-0.5 h-8 bg-slate-300 my-1" />
          </div>

          {/* Tier 2: Ketua & Wakil Ketua */}
          <div className="space-y-2">
            <div className="text-center">
              <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
                Pimpinan Inti Kelas
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
              {/* Ketua */}
              <div
                id="officer-ketua"
                onClick={() => setSelectedOfficer(ketuaKelas)}
                className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-blue-500 shadow-xs hover:shadow-md transition-all cursor-pointer group hover:scale-[1.01]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                    {ketuaKelas?.avatar || '👨‍🎓'}
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">
                      {ketuaKelas?.role || 'Ketua Kelas'}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 mt-0.5 truncate">
                      {ketuaKelas?.name || '(Belum Diisi)'}
                    </h4>
                    {ketuaKelas?.nickname && (
                      <span className="text-[11px] text-slate-500 block">Panggilan: &quot;{ketuaKelas.nickname}&quot;</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Wakil Ketua */}
              <div
                id="officer-wakil"
                onClick={() => setSelectedOfficer(wakilKetua)}
                className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-blue-500 shadow-xs hover:shadow-md transition-all cursor-pointer group hover:scale-[1.01]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                    {wakilKetua?.avatar || '👩‍🎓'}
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">
                      {wakilKetua?.role || 'Wakil Ketua'}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 mt-0.5 truncate">
                      {wakilKetua?.name || '(Belum Diisi)'}
                    </h4>
                    {wakilKetua?.nickname && (
                      <span className="text-[11px] text-slate-500 block">Panggilan: &quot;{wakilKetua.nickname}&quot;</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Tier 3: Sekretaris & Bendahara */}
          <div className="space-y-2">
            <div className="text-center">
              <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
                Administrasi &amp; Keuangan
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 max-w-4xl mx-auto">
              {/* Sekretaris 1 */}
              <div
                onClick={() => setSelectedOfficer(sekretaris1)}
                className="p-4 bg-white rounded-xl border border-slate-200 hover:border-violet-400 shadow-xs hover:shadow transition cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">{sekretaris1?.avatar || '📝'}</span>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-violet-100 text-violet-800">
                      {sekretaris1?.role || 'Sekretaris 1'}
                    </span>
                    <h5 className="text-xs font-bold text-slate-900 mt-0.5 truncate">
                      {sekretaris1?.name || '(Belum Diisi)'}
                    </h5>
                  </div>
                </div>
              </div>

              {/* Sekretaris 2 */}
              <div
                onClick={() => setSelectedOfficer(sekretaris2)}
                className="p-4 bg-white rounded-xl border border-slate-200 hover:border-violet-400 shadow-xs hover:shadow transition cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">{sekretaris2?.avatar || '📋'}</span>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-violet-100 text-violet-800">
                      {sekretaris2?.role || 'Sekretaris 2'}
                    </span>
                    <h5 className="text-xs font-bold text-slate-900 mt-0.5 truncate">
                      {sekretaris2?.name || '(Belum Diisi)'}
                    </h5>
                  </div>
                </div>
              </div>

              {/* Bendahara 1 */}
              <div
                onClick={() => setSelectedOfficer(bendahara1)}
                className="p-4 bg-white rounded-xl border border-slate-200 hover:border-emerald-400 shadow-xs hover:shadow transition cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">{bendahara1?.avatar || '💰'}</span>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                      {bendahara1?.role || 'Bendahara 1'}
                    </span>
                    <h5 className="text-xs font-bold text-slate-900 mt-0.5 truncate">
                      {bendahara1?.name || '(Belum Diisi)'}
                    </h5>
                  </div>
                </div>
              </div>

              {/* Bendahara 2 */}
              <div
                onClick={() => setSelectedOfficer(bendahara2)}
                className="p-4 bg-white rounded-xl border border-slate-200 hover:border-emerald-400 shadow-xs hover:shadow transition cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">{bendahara2?.avatar || '💳'}</span>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                      {bendahara2?.role || 'Bendahara 2'}
                    </span>
                    <h5 className="text-xs font-bold text-slate-900 mt-0.5 truncate">
                      {bendahara2?.name || '(Belum Diisi)'}
                    </h5>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Tier 4: Seksi Bidang (Departments) */}
          <div className="space-y-4 pt-4 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base sm:text-lg font-extrabold text-slate-900">
                  Seksi Bidang &amp; Koordinator Divisi ({departments.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Divisi kerja khusus yang menunjang operasional dan prestasi kelas
                </p>
              </div>

              {isAdmin && (
                <button
                  onClick={() => setIsEditModalOpen(true)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition border border-indigo-200"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Kelola Divisi</span>
                </button>
              )}
            </div>

            {departments.length === 0 ? (
              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
                Belum ada seksi bidang yang didaftarkan.
                {isAdmin && ' Klik tombol "Isi & Edit Struktur Manual" untuk menambahkan seksi bidang baru.'}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {departments.map((dept, idx) => (
                  <div
                    key={idx}
                    className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-slate-300 transition"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-xl shrink-0">
                        {dept.icon || '✨'}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">
                          {dept.name || 'Seksi Tanpa Nama'}
                        </h4>
                        <span className="text-xs text-indigo-700 font-semibold block mt-0.5">
                          Koordinator: {dept.coordinator || '(Belum Ditentukan)'}
                        </span>
                      </div>
                    </div>

                    <div className="mt-3.5 pt-3 border-t border-slate-100 space-y-2">
                      <div>
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          Anggota Seksi:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {dept.members && dept.members.length > 0 ? (
                            dept.members.map((m, mIdx) => (
                              <span key={mIdx} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-medium">
                                {m}
                              </span>
                            ))
                          ) : (
                            <span className="text-xs text-slate-400 italic">Belum ada anggota</span>
                          )}
                        </div>
                      </div>

                      {dept.duties && dept.duties.length > 0 && (
                        <div>
                          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                            Tugas Utama:
                          </span>
                          <ul className="text-xs text-slate-600 space-y-1">
                            {dept.duties.map((duty, dIdx) => (
                              <li key={dIdx} className="flex items-start gap-1.5">
                                <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                                <span>{duty}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

      {/* Officer Detail Modal */}
      {selectedOfficer && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150">
            <button
              onClick={() => setSelectedOfficer(null)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-4 border-b border-slate-100 pb-4">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-3xl shrink-0">
                {selectedOfficer.avatar || '👤'}
              </div>
              <div>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800 uppercase tracking-wide">
                  {selectedOfficer.role}
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-1">
                  {selectedOfficer.name || '(Belum Diisi)'}
                </h3>
                {selectedOfficer.contact && (
                  <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                    <Phone className="w-3 h-3 text-slate-400" />
                    <span>{selectedOfficer.contact}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 space-y-4 text-xs sm:text-sm">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Deskripsi Peran
                </h4>
                <p className="text-slate-600 leading-relaxed">
                  {selectedOfficer.description || 'Pengurus aktif kelas X-7.26'}
                </p>
              </div>

              {selectedOfficer.tasks && selectedOfficer.tasks.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Tugas Pokok &amp; Fungsi (Tupoksi)
                  </h4>
                  <div className="space-y-1.5">
                    {selectedOfficer.tasks.map((task, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-slate-700 p-2 bg-slate-50 rounded-lg">
                        <Target className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                        <span>{task}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selectedOfficer.quote && (
                <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl text-amber-900 text-xs italic flex items-start gap-2">
                  <Quote className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>{selectedOfficer.quote}</span>
                </div>
              )}
            </div>

            <div className="mt-6 flex justify-end gap-2">
              {isAdmin && (
                <button
                  onClick={() => {
                    setSelectedOfficer(null);
                    setIsEditModalOpen(true);
                  }}
                  className="px-4 py-2 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition"
                >
                  Edit Data
                </button>
              )}
              <button
                onClick={() => setSelectedOfficer(null)}
                className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Structure Edit Modal */}
      <StructureEditModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        structure={structure}
        onSaveStructure={(newStruct) => {
          if (onSaveStructure) {
            onSaveStructure(newStruct);
          }
        }}
        onClearStructure={() => {
          if (onClearStructure) {
            onClearStructure();
          }
        }}
      />

    </div>
  );
};
