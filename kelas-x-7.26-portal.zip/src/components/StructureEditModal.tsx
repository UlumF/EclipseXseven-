import React, { useState } from 'react';
import { 
  ClassStructure, 
  Officer, 
  SectionDepartment 
} from '../types';
import { 
  X, 
  Save, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Award, 
  Users, 
  Check, 
  Edit3, 
  Briefcase, 
  Sparkles,
  Layers,
  ChevronRight
} from 'lucide-react';

interface StructureEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  structure: ClassStructure;
  onSaveStructure: (newStructure: ClassStructure) => void;
  onClearStructure: () => void;
}

export const StructureEditModal: React.FC<StructureEditModalProps> = ({
  isOpen,
  onClose,
  structure,
  onSaveStructure,
  onClearStructure
}) => {
  const [activeTab, setActiveTab] = useState<'inti' | 'sekben' | 'divisi' | 'visimotto'>('visimotto');

  // Form State initialized from props
  const [motto, setMotto] = useState(structure.motto || '');
  const [visi, setVisi] = useState(structure.visi || '');

  // Wali Kelas
  const [waliName, setWaliName] = useState(structure.waliKelas.name || '');
  const [waliNickname, setWaliNickname] = useState(structure.waliKelas.nickname || '');
  const [waliDesc, setWaliDesc] = useState(structure.waliKelas.description || '');
  const [waliContact, setWaliContact] = useState(structure.waliKelas.contact || '');
  const [waliAvatar, setWaliAvatar] = useState(structure.waliKelas.avatar || '👩‍🏫');
  const [waliTasks, setWaliTasks] = useState(structure.waliKelas.tasks?.join('\n') || '');
  const [waliQuote, setWaliQuote] = useState(structure.waliKelas.quote || '');

  // Ketua Kelas
  const [ketuaName, setKetuaName] = useState(structure.ketuaKelas.name || '');
  const [ketuaNickname, setKetuaNickname] = useState(structure.ketuaKelas.nickname || '');
  const [ketuaDesc, setKetuaDesc] = useState(structure.ketuaKelas.description || '');
  const [ketuaContact, setKetuaContact] = useState(structure.ketuaKelas.contact || '');
  const [ketuaAvatar, setKetuaAvatar] = useState(structure.ketuaKelas.avatar || '👨‍🎓');
  const [ketuaTasks, setKetuaTasks] = useState(structure.ketuaKelas.tasks?.join('\n') || '');
  const [ketuaQuote, setKetuaQuote] = useState(structure.ketuaKelas.quote || '');

  // Wakil Ketua
  const [wakilName, setWakilName] = useState(structure.wakilKetua.name || '');
  const [wakilNickname, setWakilNickname] = useState(structure.wakilKetua.nickname || '');
  const [wakilDesc, setWakilDesc] = useState(structure.wakilKetua.description || '');
  const [wakilContact, setWakilContact] = useState(structure.wakilKetua.contact || '');
  const [wakilAvatar, setWakilAvatar] = useState(structure.wakilKetua.avatar || '👩‍🎓');
  const [wakilTasks, setWakilTasks] = useState(structure.wakilKetua.tasks?.join('\n') || '');
  const [wakilQuote, setWakilQuote] = useState(structure.wakilKetua.quote || '');

  // Sekretaris 1 & 2
  const [sek1Name, setSek1Name] = useState(structure.sekretaris1.name || '');
  const [sek1Nickname, setSek1Nickname] = useState(structure.sekretaris1.nickname || '');
  const [sek1Avatar, setSek1Avatar] = useState(structure.sekretaris1.avatar || '📝');
  const [sek1Contact, setSek1Contact] = useState(structure.sekretaris1.contact || '');
  const [sek1Desc, setSek1Desc] = useState(structure.sekretaris1.description || '');

  const [sek2Name, setSek2Name] = useState(structure.sekretaris2.name || '');
  const [sek2Nickname, setSek2Nickname] = useState(structure.sekretaris2.nickname || '');
  const [sek2Avatar, setSek2Avatar] = useState(structure.sekretaris2.avatar || '📋');
  const [sek2Contact, setSek2Contact] = useState(structure.sekretaris2.contact || '');
  const [sek2Desc, setSek2Desc] = useState(structure.sekretaris2.description || '');

  // Bendahara 1 & 2
  const [ben1Name, setBen1Name] = useState(structure.bendahara1.name || '');
  const [ben1Nickname, setBen1Nickname] = useState(structure.bendahara1.nickname || '');
  const [ben1Avatar, setBen1Avatar] = useState(structure.bendahara1.avatar || '💰');
  const [ben1Contact, setBen1Contact] = useState(structure.bendahara1.contact || '');
  const [ben1Desc, setBen1Desc] = useState(structure.bendahara1.description || '');

  const [ben2Name, setBen2Name] = useState(structure.bendahara2.name || '');
  const [ben2Nickname, setBen2Nickname] = useState(structure.bendahara2.nickname || '');
  const [ben2Avatar, setBen2Avatar] = useState(structure.bendahara2.avatar || '💳');
  const [ben2Contact, setBen2Contact] = useState(structure.bendahara2.contact || '');
  const [ben2Desc, setBen2Desc] = useState(structure.bendahara2.description || '');

  // Dynamic Departments
  const [departments, setDepartments] = useState<SectionDepartment[]>(structure.departments || []);
  const [showConfirmClear, setShowConfirmClear] = useState(false);

  if (!isOpen) return null;

  const handleAddDepartment = () => {
    const newDept: SectionDepartment = {
      name: 'Seksi Bidang Baru',
      icon: '✨',
      coordinator: '',
      members: [],
      duties: ['Tugas pokok divisi']
    };
    setDepartments([...departments, newDept]);
  };

  const handleUpdateDepartment = (index: number, updated: Partial<SectionDepartment>) => {
    setDepartments((prev) =>
      prev.map((d, i) => (i === index ? { ...d, ...updated } : d))
    );
  };

  const handleDeleteDepartment = (index: number) => {
    setDepartments((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const parseTasks = (text: string) =>
      text
        .split('\n')
        .map((t) => t.trim())
        .filter(Boolean);

    const updatedStructure: ClassStructure = {
      motto: motto.trim(),
      visi: visi.trim(),
      waliKelas: {
        ...structure.waliKelas,
        role: 'Wali Kelas',
        name: waliName.trim(),
        nickname: waliNickname.trim(),
        description: waliDesc.trim(),
        contact: waliContact.trim(),
        avatar: waliAvatar.trim() || '👩‍🏫',
        tasks: parseTasks(waliTasks),
        quote: waliQuote.trim()
      },
      ketuaKelas: {
        ...structure.ketuaKelas,
        role: 'Ketua Kelas',
        name: ketuaName.trim(),
        nickname: ketuaNickname.trim(),
        description: ketuaDesc.trim(),
        contact: ketuaContact.trim(),
        avatar: ketuaAvatar.trim() || '👨‍🎓',
        tasks: parseTasks(ketuaTasks),
        quote: ketuaQuote.trim()
      },
      wakilKetua: {
        ...structure.wakilKetua,
        role: 'Wakil Ketua Kelas',
        name: wakilName.trim(),
        nickname: wakilNickname.trim(),
        description: wakilDesc.trim(),
        contact: wakilContact.trim(),
        avatar: wakilAvatar.trim() || '👩‍🎓',
        tasks: parseTasks(wakilTasks),
        quote: wakilQuote.trim()
      },
      sekretaris1: {
        ...structure.sekretaris1,
        role: 'Sekretaris 1',
        name: sek1Name.trim(),
        nickname: sek1Nickname.trim(),
        avatar: sek1Avatar.trim() || '📝',
        contact: sek1Contact.trim(),
        description: sek1Desc.trim(),
        tasks: structure.sekretaris1.tasks || []
      },
      sekretaris2: {
        ...structure.sekretaris2,
        role: 'Sekretaris 2',
        name: sek2Name.trim(),
        nickname: sek2Nickname.trim(),
        avatar: sek2Avatar.trim() || '📋',
        contact: sek2Contact.trim(),
        description: sek2Desc.trim(),
        tasks: structure.sekretaris2.tasks || []
      },
      bendahara1: {
        ...structure.bendahara1,
        role: 'Bendahara 1',
        name: ben1Name.trim(),
        nickname: ben1Nickname.trim(),
        avatar: ben1Avatar.trim() || '💰',
        contact: ben1Contact.trim(),
        description: ben1Desc.trim(),
        tasks: structure.bendahara1.tasks || []
      },
      bendahara2: {
        ...structure.bendahara2,
        role: 'Bendahara 2',
        name: ben2Name.trim(),
        nickname: ben2Nickname.trim(),
        avatar: ben2Avatar.trim() || '💳',
        contact: ben2Contact.trim(),
        description: ben2Desc.trim(),
        tasks: structure.bendahara2.tasks || []
      },
      departments: departments.map((d) => ({
        ...d,
        name: d.name.trim(),
        coordinator: d.coordinator.trim(),
        members: Array.isArray(d.members) ? d.members : [],
        duties: Array.isArray(d.duties) ? d.duties : []
      }))
    };

    onSaveStructure(updatedStructure);
    onClose();
  };

  const handleClearAll = () => {
    setShowConfirmClear(true);
  };

  const executeClearAll = () => {
    setMotto('');
    setVisi('');
    setWaliName('');
    setWaliNickname('');
    setWaliDesc('');
    setWaliContact('');
    setKetuaName('');
    setKetuaNickname('');
    setKetuaDesc('');
    setKetuaContact('');
    setWakilName('');
    setWakilNickname('');
    setWakilDesc('');
    setWakilContact('');
    setSek1Name('');
    setSek1Nickname('');
    setSek2Name('');
    setSek2Nickname('');
    setBen1Name('');
    setBen1Nickname('');
    setBen2Name('');
    setBen2Nickname('');
    setDepartments([]);
    onClearStructure();
    setShowConfirmClear(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full p-6 sm:p-7 border border-slate-200 relative max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-indigo-600 to-violet-700 text-white rounded-2xl shadow-xs">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-slate-900">
                  Input &amp; Edit Struktur Organisasi Manual
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-md">
                  Panel Admin
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Isi manual Wali Kelas, Ketua, Sekretaris, Bendahara, Seksi Bidang, Motto &amp; Visi Kelas
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="grid grid-cols-4 p-1 bg-slate-100 rounded-2xl my-3 text-center text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('visimotto')}
            className={`py-2 px-1 rounded-xl transition ${
              activeTab === 'visimotto' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Motto &amp; Visi
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('inti')}
            className={`py-2 px-1 rounded-xl transition ${
              activeTab === 'inti' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Wali &amp; Pimpinan
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('sekben')}
            className={`py-2 px-1 rounded-xl transition ${
              activeTab === 'sekben' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Sekretaris &amp; Bendahara
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('divisi')}
            className={`py-2 px-1 rounded-xl transition ${
              activeTab === 'divisi' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Seksi Bidang ({departments.length})
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto pr-1 py-1 space-y-4 text-xs sm:text-sm">
          
          {/* TAB 1: VISI & MOTTO */}
          {activeTab === 'visimotto' && (
            <div className="space-y-4">
              <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-2xl">
                <span className="font-bold text-indigo-950 block">Slogan &amp; Nilai Dasar Kelas X-7.26</span>
                <span className="text-xs text-indigo-700">Teks ini akan ditampilkan di banner atas menu Struktur Organisasi</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Motto Kelas:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Solidaritas Tanpa Batas, Berprestasi dengan Integritas"
                  value={motto}
                  onChange={(e) => setMotto(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Visi &amp; Misi Kelas:
                </label>
                <textarea
                  rows={3}
                  placeholder="Contoh: Mewujudkan kelas X-7.26 yang kompak, berprestasi dalam bidang akademik & non-akademik, serta berakhlak mulia."
                  value={visi}
                  onChange={(e) => setVisi(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          )}

          {/* TAB 2: WALI KELAS & PIMPINAN INTI */}
          {activeTab === 'inti' && (
            <div className="space-y-5">
              
              {/* 1. Wali Kelas */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span>👩‍🏫</span> Pembimbing &amp; Wali Kelas
                  </span>
                  <input
                    type="text"
                    placeholder="Avatar Emoji"
                    value={waliAvatar}
                    onChange={(e) => setWaliAvatar(e.target.value)}
                    className="w-12 p-1 text-center text-sm bg-white border border-slate-200 rounded-lg"
                    title="Emoji Avatar"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Nama Lengkap Wali Kelas &amp; Gelar:</label>
                    <input
                      type="text"
                      placeholder="Contoh: Dra. Hj. Siti Nurhaliza, M.Pd"
                      value={waliName}
                      onChange={(e) => setWaliName(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl font-semibold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Nama Panggilan / Sapaan:</label>
                    <input
                      type="text"
                      placeholder="Contoh: Bu Siti"
                      value={waliNickname}
                      onChange={(e) => setWaliNickname(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">No. Kontak / WhatsApp Wali Kelas:</label>
                    <input
                      type="text"
                      placeholder="Contoh: 0812-8921-7788"
                      value={waliContact}
                      onChange={(e) => setWaliContact(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Kutipan / Pesan Motivasi:</label>
                    <input
                      type="text"
                      placeholder="Contoh: Tekun dan berakhlak mulia"
                      value={waliQuote}
                      onChange={(e) => setWaliQuote(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Deskripsi / Mata Pelajaran:</label>
                  <textarea
                    rows={2}
                    placeholder="Contoh: Guru Matematika Wajib & Pembimbing Kelas X-7.26"
                    value={waliDesc}
                    onChange={(e) => setWaliDesc(e.target.value)}
                    className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-700"
                  />
                </div>
              </div>

              {/* 2. Ketua Kelas */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span>👨‍🎓</span> Ketua Kelas
                  </span>
                  <input
                    type="text"
                    value={ketuaAvatar}
                    onChange={(e) => setKetuaAvatar(e.target.value)}
                    className="w-12 p-1 text-center text-sm bg-white border border-slate-200 rounded-lg"
                    title="Emoji Avatar"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Nama Lengkap Ketua:</label>
                    <input
                      type="text"
                      placeholder="Contoh: Muhammad Rayhan Al-Fatih"
                      value={ketuaName}
                      onChange={(e) => setKetuaName(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl font-semibold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Nama Panggilan:</label>
                    <input
                      type="text"
                      placeholder="Contoh: Rayhan"
                      value={ketuaNickname}
                      onChange={(e) => setKetuaNickname(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Deskripsi Peran Ketua:</label>
                  <input
                    type="text"
                    placeholder="Contoh: Mengkoordinasikan kegiatan kelas dan menjadi wakil dalam forum sekolah"
                    value={ketuaDesc}
                    onChange={(e) => setKetuaDesc(e.target.value)}
                    className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>
              </div>

              {/* 3. Wakil Ketua */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span>👩‍🎓</span> Wakil Ketua Kelas
                  </span>
                  <input
                    type="text"
                    value={wakilAvatar}
                    onChange={(e) => setWakilAvatar(e.target.value)}
                    className="w-12 p-1 text-center text-sm bg-white border border-slate-200 rounded-lg"
                    title="Emoji Avatar"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Nama Lengkap Wakil Ketua:</label>
                    <input
                      type="text"
                      placeholder="Contoh: Aurelia Safira Putri"
                      value={wakilName}
                      onChange={(e) => setWakilName(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl font-semibold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Nama Panggilan:</label>
                    <input
                      type="text"
                      placeholder="Contoh: Aurel"
                      value={wakilNickname}
                      onChange={(e) => setWakilNickname(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Deskripsi Peran Wakil:</label>
                  <input
                    type="text"
                    placeholder="Contoh: Membantu ketua kelas dalam pengawasan program dan administrasi"
                    value={wakilDesc}
                    onChange={(e) => setWakilDesc(e.target.value)}
                    className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: SEKRETARIS & BENDAHARA */}
          {activeTab === 'sekben' && (
            <div className="space-y-4">
              
              {/* Sekretaris 1 & 2 */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <span className="font-bold text-slate-900 block border-b border-slate-200 pb-2">
                  📝 Tim Sekretaris Kelas
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-2">
                    <label className="block text-xs font-bold text-indigo-900">Sekretaris 1:</label>
                    <input
                      type="text"
                      placeholder="Nama Sekretaris 1"
                      value={sek1Name}
                      onChange={(e) => setSek1Name(e.target.value)}
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                    />
                    <input
                      type="text"
                      placeholder="Panggilan"
                      value={sek1Nickname}
                      onChange={(e) => setSek1Nickname(e.target.value)}
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-2">
                    <label className="block text-xs font-bold text-indigo-900">Sekretaris 2:</label>
                    <input
                      type="text"
                      placeholder="Nama Sekretaris 2"
                      value={sek2Name}
                      onChange={(e) => setSek2Name(e.target.value)}
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                    />
                    <input
                      type="text"
                      placeholder="Panggilan"
                      value={sek2Nickname}
                      onChange={(e) => setSek2Nickname(e.target.value)}
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Bendahara 1 & 2 */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <span className="font-bold text-slate-900 block border-b border-slate-200 pb-2">
                  💰 Tim Bendahara Kelas
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-2">
                    <label className="block text-xs font-bold text-emerald-900">Bendahara 1:</label>
                    <input
                      type="text"
                      placeholder="Nama Bendahara 1"
                      value={ben1Name}
                      onChange={(e) => setBen1Name(e.target.value)}
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                    />
                    <input
                      type="text"
                      placeholder="Panggilan"
                      value={ben1Nickname}
                      onChange={(e) => setBen1Nickname(e.target.value)}
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-2">
                    <label className="block text-xs font-bold text-emerald-900">Bendahara 2:</label>
                    <input
                      type="text"
                      placeholder="Nama Bendahara 2"
                      value={ben2Name}
                      onChange={(e) => setBen2Name(e.target.value)}
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                    />
                    <input
                      type="text"
                      placeholder="Panggilan"
                      value={ben2Nickname}
                      onChange={(e) => setBen2Nickname(e.target.value)}
                      className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 4: SEKSI BIDANG / DEPARTEMEN DINAMIS */}
          {activeTab === 'divisi' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-indigo-50/70 rounded-2xl border border-indigo-100">
                <div>
                  <span className="font-bold text-indigo-950 block">Daftar Seksi Bidang &amp; Divisi Kelas</span>
                  <span className="text-xs text-indigo-700">Tambahkan atau sesuaikan seksi kerja kelas X-7.26</span>
                </div>
                <button
                  type="button"
                  onClick={handleAddDepartment}
                  className="inline-flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Seksi</span>
                </button>
              </div>

              {departments.length === 0 ? (
                <div className="text-center py-8 bg-slate-50 rounded-2xl border border-slate-200 text-slate-400 text-xs">
                  Belum ada seksi bidang yang ditambahkan. Klik &quot;+ Tambah Seksi&quot; di atas untuk membuat divisi kerja baru.
                </div>
              ) : (
                departments.map((dept, idx) => (
                  <div key={idx} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center gap-2 flex-1 mr-2">
                        <input
                          type="text"
                          value={dept.icon}
                          onChange={(e) => handleUpdateDepartment(idx, { icon: e.target.value })}
                          className="w-10 p-1 text-center bg-white border border-slate-200 rounded-lg text-sm"
                          title="Icon Emoji"
                        />
                        <input
                          type="text"
                          placeholder="Nama Seksi Bidang"
                          value={dept.name}
                          onChange={(e) => handleUpdateDepartment(idx, { name: e.target.value })}
                          className="flex-1 p-2 text-xs bg-white border border-slate-200 rounded-xl font-bold text-slate-900"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteDepartment(idx)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                        title="Hapus Seksi Bidang"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">
                        Koordinator Seksi:
                      </label>
                      <input
                        type="text"
                        placeholder="Nama Koordinator Seksi"
                        value={dept.coordinator}
                        onChange={(e) => handleUpdateDepartment(idx, { coordinator: e.target.value })}
                        className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">
                        Anggota Seksi (Pisahkan dengan koma):
                      </label>
                      <input
                        type="text"
                        placeholder="Contoh: Raden Mas Bagus Satria, Tiara Anggun, Vito"
                        value={dept.members.join(', ')}
                        onChange={(e) => {
                          const members = e.target.value.split(',').map((m) => m.trim()).filter(Boolean);
                          handleUpdateDepartment(idx, { members });
                        }}
                        className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">
                        Tugas Utama (Pisahkan dengan koma atau baris baru):
                      </label>
                      <textarea
                        rows={2}
                        placeholder="Contoh: Mengawasi piket harian, Menyediakan alat kebersihan"
                        value={dept.duties.join(', ')}
                        onChange={(e) => {
                          const duties = e.target.value.split(',').map((d) => d.trim()).filter(Boolean);
                          handleUpdateDepartment(idx, { duties });
                        }}
                        className="w-full p-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-700"
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Footer Buttons */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              onClick={handleClearAll}
              className="text-xs text-rose-600 hover:text-rose-700 flex items-center gap-1 font-semibold hover:bg-rose-50 px-2.5 py-1.5 rounded-lg transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Kosongkan Semua Struktur</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Struktur Organisasi</span>
              </button>
            </div>
          </div>

        </form>

        {/* Clear Confirmation Modal */}
        {showConfirmClear && (
          <div className="fixed inset-0 z-60 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 animate-in fade-in zoom-in-95">
              <div className="flex items-center gap-2.5 text-rose-600 mb-2.5">
                <div className="p-2 bg-rose-50 rounded-xl">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Kosongkan Struktur?</h4>
                  <span className="text-[11px] text-slate-500">Reset Semua Jabatan</span>
                </div>
              </div>

              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                Apakah Anda yakin ingin mengosongkan semua data struktur kelas agar bisa diisi ulang dari awal?
              </p>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowConfirmClear(false)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={executeClearAll}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs"
                >
                  Ya, Kosongkan
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
