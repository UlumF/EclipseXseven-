import React from 'react';
import { 
  Bell, 
  Users, 
  Sparkles, 
  Calendar, 
  BookOpen, 
  CheckSquare, 
  AlertTriangle, 
  Layers, 
  ShieldCheck, 
  User, 
  Palette, 
  UserCog, 
  Lock, 
  LogOut,
  ChevronDown
} from 'lucide-react';
import { UserSession } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  urgentCount: number;
  session: UserSession;
  onOpenLogin: () => void;
  onOpenCustomizer?: () => void;
  onOpenStudentManage?: () => void;
  onOpenVisitorLogs?: () => void;
  openAddModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  urgentCount,
  session,
  onOpenLogin,
  onOpenCustomizer,
  onOpenStudentManage,
  onOpenVisitorLogs,
  openAddModal
}) => {
  const isAdmin = session.role === 'admin';

  const navItems = [
    { id: 'dashboard', label: 'Ringkasan', icon: Layers },
    { id: 'absensi', label: 'Absensi', icon: Users },
    { id: 'piket', label: 'Piket Mingguan', icon: Sparkles },
    { id: 'struktur', label: 'Struktur Kelas', icon: BookOpen },
    { id: 'jadwal', label: 'Jadwal Mapel', icon: Calendar },
    { id: 'pr', label: 'Catatan PR', icon: CheckSquare },
    { id: 'pengumuman', label: 'Pengumuman & Catatan', icon: Bell, badge: urgentCount > 0 ? urgentCount : undefined },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all shadow-xs">
      {/* Top Role Indicator Bar */}
      <div className={`px-4 py-1 text-xs transition-colors flex items-center justify-between border-b ${
        isAdmin 
          ? 'bg-indigo-900 text-indigo-100 border-indigo-950' 
          : 'bg-slate-100 text-slate-600 border-slate-200/80'
      }`}>
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-[11px]">
            {isAdmin ? (
              <>
                <span className="flex items-center gap-1 font-bold text-amber-300">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Akses Admin Aktif:</span>
                </span>
                <span className="font-semibold text-white truncate max-w-[200px] sm:max-w-xs">
                  {session.name} {session.officerRole ? `(${session.officerRole})` : ''}
                </span>
                <span className="hidden md:inline-block px-1.5 py-0.2 rounded bg-indigo-800 text-[10px] text-indigo-200 font-mono">
                  Full Edit Access
                </span>
              </>
            ) : (
              <>
                <span className="flex items-center gap-1 font-semibold text-slate-600">
                  <User className="w-3.5 h-3.5" />
                  <span>Mode Siswa:</span>
                </span>
                <span className="font-medium text-slate-800 truncate max-w-[180px]">
                  {session.name} (Hanya Lihat)
                </span>
                <span className="hidden sm:inline text-slate-400">
                  • Masuk sebagai Admin untuk mengedit data
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            {isAdmin && onOpenVisitorLogs && (
              <button
                id="btn-nav-visitor-logs"
                onClick={onOpenVisitorLogs}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-indigo-800/90 hover:bg-indigo-700 text-indigo-100 text-[11px] font-bold transition shadow-xs"
                title="Lihat Log Masuk 7 Hari & Rekap Bulanan"
              >
                <Layers className="w-3 h-3 text-emerald-400" />
                <span className="hidden sm:inline">📊 Log 7 Hari &amp; Rekap</span>
              </button>
            )}

            {isAdmin && onOpenCustomizer && (
              <button
                id="btn-nav-customizer"
                onClick={onOpenCustomizer}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-indigo-800/80 hover:bg-indigo-700 text-indigo-100 text-[11px] font-bold transition"
                title="Ubah Teks dan Tampilan Website"
              >
                <Palette className="w-3 h-3 text-amber-300" />
                <span className="hidden sm:inline">Ubah Teks &amp; Tampilan</span>
              </button>
            )}

            {isAdmin && onOpenStudentManage && (
              <button
                id="btn-nav-student-manage"
                onClick={onOpenStudentManage}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-indigo-800/80 hover:bg-indigo-700 text-indigo-100 text-[11px] font-bold transition"
                title="Kelola & Edit Data Siswa"
              >
                <UserCog className="w-3 h-3 text-sky-300" />
                <span className="hidden sm:inline">Edit Data Siswa</span>
              </button>
            )}

            <button
              id="btn-nav-switch-role"
              onClick={onOpenLogin}
              className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold transition cursor-pointer ${
                isAdmin
                  ? 'bg-rose-500/20 text-rose-200 hover:bg-rose-500/30 border border-rose-400/30'
                  : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-xs'
              }`}
            >
              {isAdmin ? (
                <>
                  <LogOut className="w-3 h-3" />
                  <span>Ganti / Keluar</span>
                </>
              ) : (
                <>
                  <Lock className="w-3 h-3" />
                  <span>Login Admin</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          
          {/* Logo brand */}
          <div 
            id="brand-logo-btn"
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="relative flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-400 p-[2px] shadow-sm group-hover:scale-105 transition-transform duration-200">
              <div className="w-full h-full bg-white rounded-full flex items-center justify-center overflow-hidden">
                <span className="font-extrabold text-xs tracking-tighter bg-gradient-to-r from-blue-700 to-indigo-600 bg-clip-text text-transparent">
                  X-7
                </span>
              </div>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-slate-900">
                  X-7<span className="text-indigo-600">.26</span>
                </span>
                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60">
                  Portal Resmi
                </span>
              </div>
              <span className="text-[11px] text-slate-500 hidden sm:inline-block font-medium">
                Solidaritas &amp; Prestasi
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-150 ${
                    isActive
                      ? 'text-indigo-600 bg-indigo-50/80 font-semibold'
                      : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100/70'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-bold leading-none text-white bg-rose-500 rounded-full animate-pulse">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2">
            {isAdmin && openAddModal && (
              <button
                id="header-btn-announcement"
                onClick={openAddModal}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition border border-slate-200"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                <span>Buat Info / PR</span>
              </button>
            )}

            <button
              id="header-btn-action"
              onClick={() => setActiveTab('absensi')}
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-medium text-white bg-[#1E1B4B] hover:bg-indigo-950 rounded-lg transition shadow-sm hover:shadow active:scale-[0.98]"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Presensi Siswa</span>
            </button>
          </div>

        </div>

        {/* Mobile Horizontal Navigation scroll */}
        <div className="lg:hidden flex items-center gap-1 overflow-x-auto pb-2.5 pt-1 scrollbar-none border-t border-slate-100">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-mob-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`whitespace-nowrap flex items-center gap-1.5 px-2.5 py-1.5 text-xs rounded-md transition-colors ${
                  isActive
                    ? 'text-indigo-600 bg-indigo-50 font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
                )}
              </button>
            );
          })}
        </div>

      </div>
    </header>
  );
};
