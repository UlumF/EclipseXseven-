import React, { useState } from 'react';
import { 
  UserRole, 
  UserSession, 
  Student,
  AdminRoleTitle 
} from '../types';
import { 
  ShieldCheck, 
  User, 
  KeyRound, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Lock, 
  Users, 
  Sparkles,
  ArrowRight,
  GraduationCap,
  BarChart3,
  Calendar
} from 'lucide-react';
import { AdminVisitorAnalyticsView } from './AdminVisitorAnalyticsView';
import { recordVisitorLog } from '../utils/visitorLogger';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSession: UserSession;
  students: Student[];
  onLogin: (session: UserSession) => void;
  onLogout: () => void;
  defaultTab?: 'auth' | 'analytics';
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  currentSession,
  students,
  onLogin,
  onLogout,
  defaultTab = 'auth'
}) => {
  const [modalMainTab, setModalMainTab] = useState<'auth' | 'analytics'>(defaultTab);
  const [selectedRole, setSelectedRole] = useState<UserRole>('admin');
  
  // Admin form state
  const [adminPassword, setAdminPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [adminRoleTitle, setAdminRoleTitle] = useState<AdminRoleTitle>('Wali Kelas');
  const [adminError, setAdminError] = useState('');
  const [loginSuccess, setLoginSuccess] = useState(false);

  // Student form state
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [studentCustomName, setStudentCustomName] = useState('');

  if (!isOpen) return null;

  const ADMIN_SECRET_PASSWORD = 'X720262027';

  const handleAdminRoleChange = (role: AdminRoleTitle) => {
    setAdminRoleTitle(role);
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');

    if (adminPassword.trim() !== ADMIN_SECRET_PASSWORD) {
      setAdminError('Password Admin salah! Silakan masukkan password resmi pengurus kelas.');
      return;
    }

    setLoginSuccess(true);
    setTimeout(() => {
      // Record visitor log
      recordVisitorLog({
        name: adminRoleTitle,
        role: 'admin',
        roleTitle: adminRoleTitle,
        action: 'Login Admin'
      });

      onLogin({
        role: 'admin',
        name: adminRoleTitle,
        officerRole: adminRoleTitle,
        lastLogin: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      });
      setLoginSuccess(false);
      setAdminPassword('');
      onClose();
    }, 400);
  };

  const handleStudentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    let name = 'Siswa X-7.26';
    let studentId = undefined;
    let nisn = undefined;

    if (selectedStudentId) {
      const found = students.find((s) => s.id === selectedStudentId);
      if (found) {
        name = found.name;
        studentId = found.id;
        nisn = found.nisn;
      }
    } else if (studentCustomName.trim()) {
      name = studentCustomName.trim();
    }

    // Record visitor log
    recordVisitorLog({
      name: name,
      role: 'student',
      roleTitle: 'Siswa',
      studentId: studentId,
      nisn: nisn,
      action: 'Login Siswa'
    });

    onLogin({
      role: 'student',
      name: name,
      studentId: studentId,
      lastLogin: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    });
    onClose();
  };

  const handleSwitchToStudent = () => {
    onLogout();
    onClose();
  };

  const isCurrentAdmin = currentSession.role === 'admin';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className={`bg-white rounded-3xl shadow-2xl w-full p-5 sm:p-7 border border-slate-200 relative overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-auto ${
        modalMainTab === 'analytics' ? 'max-w-5xl' : 'max-w-md'
      }`}>
        
        {/* Close Button */}
        <button
          id="btn-close-login-modal"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition z-10"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Current Session Banner & Main Navigation Switcher */}
        <div className="mb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-white ${
              isCurrentAdmin ? 'bg-indigo-600' : 'bg-slate-600'
            }`}>
              {isCurrentAdmin ? <ShieldCheck className="w-4 h-4" /> : <User className="w-4 h-4" />}
            </div>
            <div>
              <span className="text-[10px] font-semibold text-slate-400 block">Sesi Login Aktif:</span>
              <span className="text-xs font-bold text-slate-900 truncate max-w-[170px] block">
                {currentSession.name}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Tab selector for Admin */}
            {isCurrentAdmin ? (
              <div className="inline-flex p-1 bg-slate-200/70 rounded-xl">
                <button
                  type="button"
                  id="tab-btn-auth"
                  onClick={() => setModalMainTab('auth')}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                    modalMainTab === 'auth'
                      ? 'bg-white text-indigo-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Ganti Hak Akses
                </button>
                <button
                  type="button"
                  id="tab-btn-analytics"
                  onClick={() => setModalMainTab('analytics')}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition flex items-center gap-1 ${
                    modalMainTab === 'analytics'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <BarChart3 className="w-3.5 h-3.5" />
                  <span>Log Akses 7 Hari</span>
                </button>
              </div>
            ) : (
              <span className="px-2.5 py-1 rounded-md text-[10px] font-extrabold uppercase bg-slate-200 text-slate-700">
                Mode Siswa
              </span>
            )}
          </div>
        </div>

        {/* SECTION A: AUTH / LOGIN FORM */}
        {modalMainTab === 'auth' && (
          <div>
            {/* Header Title */}
            <div className="text-center mb-6">
              <div className="w-12 h-12 mx-auto mb-2.5 rounded-2xl bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-400 p-[2px] shadow-sm flex items-center justify-center">
                <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center">
                  <KeyRound className="w-5 h-5 text-indigo-600" />
                </div>
              </div>
              <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                Panel Hak Akses Kelas X-7.26
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Pilih hak akses untuk melihat data atau mengelola konten website
              </p>
            </div>

            {/* Role Selector Switch Tabs */}
            <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-2xl mb-5">
              <button
                type="button"
                id="tab-select-admin-login"
                onClick={() => {
                  setSelectedRole('admin');
                  setAdminError('');
                }}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  selectedRole === 'admin'
                    ? 'bg-white text-indigo-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <ShieldCheck className={`w-4 h-4 ${selectedRole === 'admin' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>Admin / Pengurus</span>
              </button>

              <button
                type="button"
                id="tab-select-student-login"
                onClick={() => {
                  setSelectedRole('student');
                  setAdminError('');
                }}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  selectedRole === 'student'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <GraduationCap className={`w-4 h-4 ${selectedRole === 'student' ? 'text-slate-800' : 'text-slate-400'}`} />
                <span>Siswa (Hanya Lihat)</span>
              </button>
            </div>

            {/* 1. ADMIN LOGIN FORM */}
            {selectedRole === 'admin' && (
              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div className="p-3.5 bg-indigo-50/70 border border-indigo-100 rounded-2xl text-xs text-indigo-950 flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block font-bold">Izin Pengurus &amp; Wali Kelas:</strong>
                    <span>Dapat mengubah teks/tampilan web, mengedit nama &amp; data siswa, presensi, jadwal, piket, PR, menyiarkan pengumuman, serta melihat log 7 hari &amp; rekap bulanan.</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Pilih Jabatan / Peran:
                  </label>
                  <select
                    id="select-admin-role"
                    value={adminRoleTitle}
                    onChange={(e) => handleAdminRoleChange(e.target.value as AdminRoleTitle)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                  >
                    <option value="Wali Kelas">Wali Kelas</option>
                    <option value="Perangkat Kelas">Perangkat Kelas</option>
                    <option value="Admin Website">Admin Website</option>
                  </select>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">
                      Password Admin:
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">X720262027</span>
                  </div>
                  
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      id="input-admin-password"
                      required
                      placeholder="Masukkan password admin..."
                      value={adminPassword}
                      onChange={(e) => {
                        setAdminPassword(e.target.value);
                        if (adminError) setAdminError('');
                      }}
                      className="w-full pl-3 pr-10 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono font-bold tracking-wider"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {adminError && (
                    <div className="mt-2 p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-1.5 font-medium">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{adminError}</span>
                    </div>
                  )}
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    id="btn-submit-admin-login"
                    className="w-full py-3 px-4 bg-[#1E1B4B] hover:bg-indigo-950 text-white rounded-xl text-xs sm:text-sm font-bold transition shadow-md hover:shadow-lg flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
                  >
                    {loginSuccess ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 animate-bounce" />
                        <span>Verifikasi Berhasil! Membuka Akses...</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4 text-indigo-300" />
                        <span>Masuk sebagai Admin (Akses Edit Penuh)</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* 2. STUDENT (READ ONLY) LOGIN FORM */}
            {selectedRole === 'student' && (
              <form onSubmit={handleStudentLogin} className="space-y-4">
                <div className="p-3.5 bg-slate-100 border border-slate-200 rounded-2xl text-xs text-slate-700 flex items-start gap-2.5">
                  <User className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block font-bold text-slate-900">Hak Akses Siswa / Tamu:</strong>
                    <span>Mode lihat (read-only) untuk memantau kehadiran, jadwal mapel, kelompok piket, catatan PR, dan pengumuman kelas.</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Pilih Nama Siswa (Opsional):
                  </label>
                  <select
                    id="select-student-name"
                    value={selectedStudentId}
                    onChange={(e) => {
                      setSelectedStudentId(e.target.value);
                      setStudentCustomName('');
                    }}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500"
                  >
                    <option value="">-- Masuk sebagai Siswa Umum X-7.26 --</option>
                    {students.map((s, idx) => (
                      <option key={s.id} value={s.id}>
                        {idx + 1}. {s.name} ({s.gender})
                      </option>
                    ))}
                  </select>
                </div>

                {!selectedStudentId && (
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Atau Masukkan Nama Panggilan Anda:
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: Budi Santoso"
                      value={studentCustomName}
                      onChange={(e) => setStudentCustomName(e.target.value)}
                      className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500"
                    />
                  </div>
                )}

                <div className="pt-2">
                  <button
                    type="submit"
                    id="btn-submit-student-login"
                    className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs sm:text-sm font-bold transition shadow-sm hover:shadow flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
                  >
                    <GraduationCap className="w-4 h-4 text-slate-300" />
                    <span>Masuk sebagai Siswa (Mode Lihat)</span>
                  </button>
                </div>

                {isCurrentAdmin && (
                  <div className="pt-1 text-center">
                    <button
                      type="button"
                      onClick={handleSwitchToStudent}
                      className="text-xs text-rose-600 hover:underline font-semibold"
                    >
                      Keluar dari Mode Admin &amp; Kembali ke Mode Siswa
                    </button>
                  </div>
                )}
              </form>
            )}
          </div>
        )}

        {/* SECTION B: VISITOR ANALYTICS 7 DAYS & RECAP */}
        {modalMainTab === 'analytics' && isCurrentAdmin && (
          <div className="animate-in fade-in duration-200">
            <AdminVisitorAnalyticsView students={students} onClose={onClose} />
          </div>
        )}

      </div>
    </div>
  );
};
