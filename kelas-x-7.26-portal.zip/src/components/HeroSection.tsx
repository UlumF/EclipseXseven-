import React from 'react';
import { Sparkles, Calendar, Users, AlertCircle, ArrowRight, Palette, Edit } from 'lucide-react';
import { WebsiteSettings } from '../types';

interface HeroSectionProps {
  onExplore: () => void;
  onViewSchedule: () => void;
  onViewAttendance: () => void;
  settings?: WebsiteSettings;
  studentCount?: number;
  isAdmin?: boolean;
  onOpenCustomizer?: () => void;
  urgentAnnouncement?: {
    title: string;
    sender: string;
  } | null;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExplore,
  onViewSchedule,
  onViewAttendance,
  settings,
  studentCount = 35,
  isAdmin = false,
  onOpenCustomizer,
  urgentAnnouncement
}) => {
  const title = settings?.heroTitle || 'Setiap prestasi hebat dimulai dari Kelas X-7.26.';
  const subtitle = settings?.heroSubtitle || 'Ruang portal terpadu untuk monitoring absensi 35 siswa, jadwal piket Senin s.d. Jum\'at, struktur kepengurusan, jadwal mata pelajaran & info silabus, catatan deadline PR, serta pengumuman penting wali kelas.';
  const tagline = settings?.classTagline || 'Solidaritas Tanpa Batas, Berprestasi dengan Integritas';
  const schoolYear = settings?.schoolYear || 'Tahun Ajaran 2026/2027';

  return (
    <section className="relative pt-8 pb-12 sm:pt-14 sm:pb-16 text-center max-w-4xl mx-auto px-4">
      
      {/* Top Urgent announcement pill if exists */}
      {urgentAnnouncement && (
        <div 
          onClick={onExplore}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold mb-6 hover:bg-rose-100/80 cursor-pointer transition shadow-xs group"
        >
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping inline-block" />
          <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
          <span className="font-bold">Mendesak ({urgentAnnouncement.sender}):</span>
          <span className="max-w-[260px] sm:max-w-md truncate font-normal text-slate-700">
            {urgentAnnouncement.title}
          </span>
          <ArrowRight className="w-3 h-3 text-rose-500 group-hover:translate-x-0.5 transition-transform" />
        </div>
      )}

      {/* Class tagline badge */}
      <div className="mb-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/80 text-indigo-800 text-xs font-bold">
        <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
        <span>{tagline}</span>
        <span className="text-indigo-400">•</span>
        <span className="font-mono text-indigo-600">{schoolYear}</span>
      </div>

      {/* Main Display Headline */}
      <div className="relative group">
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.15]">
          {title}
        </h1>
        {isAdmin && onOpenCustomizer && (
          <button
            onClick={onOpenCustomizer}
            className="mt-2 inline-flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-800 font-semibold bg-indigo-50/70 hover:bg-indigo-100 px-2.5 py-1 rounded-lg transition border border-indigo-200"
          >
            <Palette className="w-3 h-3" />
            <span>Ubah Teks &amp; Tampilan Website</span>
          </button>
        )}
      </div>

      {/* Clean subtitle */}
      <p className="mt-4 sm:mt-5 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto font-normal leading-relaxed">
        {subtitle}
      </p>

      {/* Action Buttons styled like the reference */}
      <div className="mt-8 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
        <button
          id="hero-btn-primary"
          onClick={onViewSchedule}
          className="px-6 py-3 text-sm sm:text-base font-semibold text-white bg-[#1E1B4B] hover:bg-indigo-950 rounded-xl transition duration-150 shadow-md hover:shadow-lg active:scale-95 flex items-center gap-2"
        >
          <Calendar className="w-4 h-4 text-indigo-300" />
          <span>Jadwal &amp; Info Hari Ini</span>
        </button>

        <button
          id="hero-btn-secondary"
          onClick={onViewAttendance}
          className="px-6 py-3 text-sm sm:text-base font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300/80 rounded-xl transition duration-150 shadow-xs hover:border-slate-400 active:scale-95 flex items-center gap-2"
        >
          <Users className="w-4 h-4 text-slate-500" />
          <span>Presensi &amp; Rekap Siswa</span>
        </button>
      </div>

      {/* Quick stats micro-bar */}
      <div className="mt-10 pt-6 border-t border-slate-200/70 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center max-w-2xl mx-auto">
        <div className="flex flex-col items-center">
          <span className="text-xl sm:text-2xl font-bold text-slate-900">{studentCount}</span>
          <span className="text-xs text-slate-500 font-medium">Siswa Terdaftar</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-xl sm:text-2xl font-bold text-indigo-600">5 Hari</span>
          <span className="text-xs text-slate-500 font-medium">Jadwal Piket Aktif</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-xl sm:text-2xl font-bold text-slate-900">14 Mapel</span>
          <span className="text-xs text-slate-500 font-medium">Kurikulum Merdeka</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-xl sm:text-2xl font-bold text-emerald-600">100%</span>
          <span className="text-xs text-slate-500 font-medium">Kekompakan Kelas</span>
        </div>
      </div>

    </section>
  );
};
