/**
 * Admin Visitor & Login Analytics View (7 Days Window + Monthly Recap)
 * Incorporates:
 * 1. 7-Day Rolling Log Retention
 * 2. Diagram Lingkaran (Pie Chart) with role distribution
 * 3. Diagram Alir (Flow/Area Trend Chart) for 7 days traffic
 * 4. Real-time working Refresh Button with animation and status feedback
 * 5. Granular manual deletion (per-row & full clear) and automatic cleanup on month turnover
 * 6. Accurate Monthly Recap generator and archive with verified status note
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  VisitorLog, 
  MonthlyRecap, 
  Student 
} from '../types';
import { 
  getStoredVisitorLogs, 
  deleteSingleLog, 
  clearAllVisitorLogs, 
  get7DaysFlowTrend, 
  getRolePieData, 
  getStoredMonthlyRecaps, 
  compileMonthlyRecap, 
  deleteMonthlyRecap,
  recordVisitorLog 
} from '../utils/visitorLogger';
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Tooltip, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Legend 
} from 'recharts';
import { 
  RefreshCw, 
  Trash2, 
  Calendar, 
  Clock, 
  Users, 
  ShieldCheck, 
  PieChart as PieIcon, 
  TrendingUp, 
  Filter, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Download, 
  Smartphone, 
  Monitor, 
  Sparkles, 
  Database,
  ArrowRight,
  Info,
  AlertTriangle
} from 'lucide-react';

interface AdminVisitorAnalyticsViewProps {
  students?: Student[];
  onClose?: () => void;
}

export const AdminVisitorAnalyticsView: React.FC<AdminVisitorAnalyticsViewProps> = ({
  students = []
}) => {
  const [logs, setLogs] = useState<VisitorLog[]>(() => getStoredVisitorLogs());
  const [recaps, setRecaps] = useState<MonthlyRecap[]>(() => getStoredMonthlyRecaps());
  const [activeSubTab, setActiveSubTab] = useState<'7days' | 'monthly_recap'>('7days');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  
  // Refresh animation & feedback state
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastRefreshedTime, setLastRefreshedTime] = useState<string>(() => 
    new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  );
  const [notificationMsg, setNotificationMsg] = useState<{ type: 'success' | 'info' | 'warn'; text: string } | null>(null);

  // In-app confirmation dialog states
  const [logToDelete, setLogToDelete] = useState<{ id: string; name: string } | null>(null);
  const [showClearAllLogsConfirm, setShowClearAllLogsConfirm] = useState(false);
  const [recapToDelete, setRecapToDelete] = useState<{ id: string; label: string } | null>(null);

  // Auto clear notification after 4 seconds
  useEffect(() => {
    if (notificationMsg) {
      const timer = setTimeout(() => {
        setNotificationMsg(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [notificationMsg]);

  // Load fresh data
  const refreshData = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      const freshLogs = getStoredVisitorLogs();
      const freshRecaps = getStoredMonthlyRecaps();
      setLogs(freshLogs);
      setRecaps(freshRecaps);
      const timeStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastRefreshedTime(timeStr);
      setIsRefreshing(false);
      setNotificationMsg({
        type: 'success',
        text: `Data log 7 hari berhasil diperbarui secara real-time pada pukul ${timeStr}.`
      });
    }, 450);
  };

  // Handle manual single delete
  const handleDeleteLog = (id: string, name: string) => {
    setLogToDelete({ id, name });
  };

  const handleConfirmDeleteLog = () => {
    if (logToDelete) {
      const updated = deleteSingleLog(logToDelete.id);
      setLogs(updated);
      setNotificationMsg({
        type: 'info',
        text: `Log akses untuk "${logToDelete.name}" telah dihapus secara manual.`
      });
      setLogToDelete(null);
    }
  };

  // Handle clear all 7-day raw logs
  const handleClearAll = () => {
    setShowClearAllLogsConfirm(true);
  };

  const handleConfirmClearAll = () => {
    clearAllVisitorLogs();
    setLogs([]);
    setNotificationMsg({
      type: 'warn',
      text: 'Seluruh riwayat log masuk 7 hari berhasil dibersihkan.'
    });
    setShowClearAllLogsConfirm(false);
  };

  // Handle Generate Monthly Recap (accurate compilation)
  const handleCreateMonthlyRecap = (autoPurge: boolean = false) => {
    const currentMonthKey = new Date().toISOString().substring(0, 7); // e.g. "2026-08"
    const newRecap = compileMonthlyRecap(currentMonthKey, logs, autoPurge);
    
    // Update recaps and logs state
    setRecaps(getStoredMonthlyRecaps());
    if (autoPurge) {
      setLogs(getStoredVisitorLogs());
    }

    setNotificationMsg({
      type: 'success',
      text: `${newRecap.statusNote}${autoPurge ? ' (Data mentah siswa telah dibersihkan otomatis).' : ''}`
    });
    setActiveSubTab('monthly_recap');
  };

  // Handle delete single monthly recap
  const handleDeleteRecap = (recapId: string, monthLabel: string) => {
    setRecapToDelete({ id: recapId, label: monthLabel });
  };

  const handleConfirmDeleteRecap = () => {
    if (recapToDelete) {
      const updated = deleteMonthlyRecap(recapToDelete.id);
      setRecaps(updated);
      setNotificationMsg({
        type: 'info',
        text: `Arsip rekap bulanan "${recapToDelete.label}" telah dihapus.`
      });
      setRecapToDelete(null);
    }
  };

  // Filtered logs calculation
  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const matchesSearch = 
        log.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (log.nisn && log.nisn.includes(searchQuery)) ||
        log.roleTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        log.timeStr.includes(searchQuery) ||
        log.dateStr.includes(searchQuery);

      const matchesRole = 
        roleFilter === 'all' || 
        (roleFilter === 'admin' && log.role === 'admin') ||
        (roleFilter === 'student' && log.role === 'student') ||
        log.roleTitle === roleFilter;

      return matchesSearch && matchesRole;
    });
  }, [logs, searchQuery, roleFilter]);

  // Chart datasets
  const pieData = useMemo(() => getRolePieData(logs), [logs]);
  const flowTrendData = useMemo(() => get7DaysFlowTrend(logs), [logs]);

  // Stat summary calculations
  const total7DaysVisits = logs.length;
  const studentVisitsCount = logs.filter((l) => l.role === 'student').length;
  const adminVisitsCount = logs.filter((l) => l.role === 'admin').length;
  const uniqueUsersCount = new Set(logs.map((l) => l.name)).size;

  const latestRecap = recaps[0];

  return (
    <div className="space-y-6">
      {/* Top Banner & Control Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-2xl border border-indigo-900/50 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px] font-bold uppercase tracking-wider border border-indigo-500/30 flex items-center gap-1">
                <Database className="w-3 h-3" />
                Retensi 7 Hari Aktif
              </span>
              <span className="text-[11px] text-slate-400">
                Update Terakhir: <strong className="text-white font-mono">{lastRefreshedTime} WIB</strong>
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-black tracking-tight text-white mt-1">
              Monitoring Aktivitas &amp; Log Masuk Website
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Pantau siapa saja yang membuka portal selama 7 hari terakhir dengan visualisasi diagram alir &amp; lingkaran.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Realtime Refresh Button */}
            <button
              type="button"
              id="btn-refresh-logs"
              onClick={refreshData}
              disabled={isRefreshing}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-sm ${
                isRefreshing 
                  ? 'bg-indigo-700 text-white cursor-wait' 
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white cursor-pointer active:scale-95'
              }`}
              title="Klik untuk menyinkronkan data log secara akurat"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? 'Memperbarui...' : 'Refresh Data'}</span>
            </button>

            {/* Sub-tab switcher */}
            <div className="inline-flex p-1 bg-slate-800/80 rounded-xl border border-slate-700">
              <button
                type="button"
                onClick={() => setActiveSubTab('7days')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                  activeSubTab === '7days'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Log 7 Hari
              </button>
              <button
                type="button"
                onClick={() => setActiveSubTab('monthly_recap')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition flex items-center gap-1 ${
                  activeSubTab === 'monthly_recap'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <FileText className="w-3 h-3" />
                <span>Rekap Bulanan</span>
                {recaps.length > 0 && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Live Notification Feedback */}
        {notificationMsg && (
          <div className={`mt-3 p-2.5 rounded-xl text-xs flex items-center gap-2 animate-in fade-in slide-in-from-top-1 duration-200 ${
            notificationMsg.type === 'success' ? 'bg-emerald-950/80 text-emerald-200 border border-emerald-800' :
            notificationMsg.type === 'warn' ? 'bg-rose-950/80 text-rose-200 border border-rose-800' :
            'bg-sky-950/80 text-sky-200 border border-sky-800'
          }`}>
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span className="font-medium">{notificationMsg.text}</span>
          </div>
        )}
      </div>

      {/* SUB-TAB 1: 7-DAY LOGS & CHARTS */}
      {activeSubTab === '7days' && (
        <div className="space-y-6">
          
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-500 block">Total Kunjungan 7 Hari</span>
              <div className="flex items-baseline gap-1.5 mt-1">
                <span className="text-2xl font-black text-slate-900">{total7DaysVisits}</span>
                <span className="text-[10px] text-indigo-600 font-bold">sesi masuk</span>
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">Rolling 168 jam</span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-500 block">Siswa Aktif</span>
              <div className="flex items-baseline gap-1.5 mt-1">
                <span className="text-2xl font-black text-emerald-600">{studentVisitsCount}</span>
                <span className="text-[10px] text-slate-400 font-semibold">kali masuk</span>
              </div>
              <span className="text-[10px] text-emerald-700 font-semibold mt-1 block">Mode Presensi &amp; Lihat</span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-500 block">Admin &amp; Wali Kelas</span>
              <div className="flex items-baseline gap-1.5 mt-1">
                <span className="text-2xl font-black text-indigo-600">{adminVisitsCount}</span>
                <span className="text-[10px] text-slate-400 font-semibold">kali login</span>
              </div>
              <span className="text-[10px] text-indigo-700 font-semibold mt-1 block">Kelola Data &amp; Info</span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-500 block">Pengguna Unik</span>
              <div className="flex items-baseline gap-1.5 mt-1">
                <span className="text-2xl font-black text-amber-600">{uniqueUsersCount}</span>
                <span className="text-[10px] text-slate-400 font-semibold">orang</span>
              </div>
              <span className="text-[10px] text-amber-700 font-semibold mt-1 block">Identitas Terdata</span>
            </div>
          </div>

          {/* DIAGRAMS SECTION (Diagram Lingkaran & Diagram Alir) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* 1. Diagram Alir / Flow Trend (7 Days) - 7 Cols */}
            <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-extrabold text-slate-900">
                      Diagram Alir Kunjungan 7 Hari Terakhir
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Grafik tren volume aktivitas masuk per hari
                    </p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-[10px] font-bold text-slate-600 font-mono">
                  7 Hari
                </span>
              </div>

              {/* Area Flow Chart */}
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={flowTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#4F46E5" stopOpacity={0.0}/>
                      </linearGradient>
                      <linearGradient id="colorSiswa" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0.0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                    <XAxis 
                      dataKey="dayLabel" 
                      tick={{ fontSize: 10, fill: '#64748B' }} 
                      axisLine={{ stroke: '#E2E8F0' }} 
                    />
                    <YAxis 
                      allowDecimals={false} 
                      tick={{ fontSize: 10, fill: '#64748B' }} 
                      axisLine={{ stroke: '#E2E8F0' }} 
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1E1B4B', borderColor: '#312E81', borderRadius: '12px', color: '#FFF', fontSize: '11px' }}
                      itemStyle={{ color: '#E0E7FF' }}
                    />
                    <Legend 
                      wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} 
                    />
                    <Area 
                      type="monotone" 
                      dataKey="siswa" 
                      name="Siswa" 
                      stroke="#10B981" 
                      strokeWidth={2}
                      fillOpacity={1} 
                      fill="url(#colorSiswa)" 
                    />
                    <Area 
                      type="monotone" 
                      dataKey="total" 
                      name="Total Akses" 
                      stroke="#4F46E5" 
                      strokeWidth={2.5}
                      fillOpacity={1} 
                      fill="url(#colorTotal)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* 2. Diagram Lingkaran (Pie Chart) - 5 Cols */}
            <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
                      <PieIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-extrabold text-slate-900">
                        Diagram Lingkaran Hak Akses
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Distribusi persentase peran yang masuk
                      </p>
                    </div>
                  </div>
                </div>

                {/* Pie Chart */}
                <div className="h-44 w-full relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={70}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value: any) => [`${value} kali`, 'Frekuensi']}
                        contentStyle={{ backgroundColor: '#1E1B4B', borderColor: '#312E81', borderRadius: '12px', color: '#FFF', fontSize: '11px' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className="text-xs text-slate-400 font-semibold">Total</span>
                    <span className="text-sm font-black text-slate-800">{total7DaysVisits}</span>
                  </div>
                </div>
              </div>

              {/* Legend List */}
              <div className="grid grid-cols-2 gap-2 mt-2 pt-3 border-t border-slate-100">
                {pieData.map((item) => (
                  <div key={item.name} className="flex items-center justify-between p-2 rounded-xl bg-slate-50 text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="font-semibold text-slate-700 text-[11px] truncate max-w-[80px]">
                        {item.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-slate-900">{item.value}</span>
                      <span className="text-[10px] text-slate-400 font-mono">({item.percent}%)</span>
                    </div>
                  </div>
                ))}
              </div>

            </div>

          </div>

          {/* INFORMASI RINCI TABEL LOG */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            {/* Header & Filter Controls */}
            <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-indigo-600" />
                  <span>Informasi Rinci Log Masuk (7 Hari Terakhir)</span>
                  <span className="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-bold text-[10px]">
                    {filteredLogs.length} Entri
                  </span>
                </h4>
                <p className="text-[11px] text-slate-400">
                  Data otomatis terhapus setelah melewati rentang 7 hari
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Search Box */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Cari nama / NISN / jam..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 w-44 sm:w-56"
                  />
                </div>

                {/* Role Filter Dropdown */}
                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="p-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                >
                  <option value="all">Semua Peran</option>
                  <option value="Wali Kelas">Wali Kelas</option>
                  <option value="Perangkat Kelas">Perangkat Kelas</option>
                  <option value="Admin Website">Admin Website</option>
                  <option value="Siswa">Siswa</option>
                </select>

                {/* Delete all logs button */}
                <button
                  type="button"
                  onClick={handleClearAll}
                  className="p-1.5 px-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                  title="Hapus manual seluruh log 7 hari"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Hapus Semua Log</span>
                </button>
              </div>
            </div>

            {/* Table Container */}
            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="sticky top-0 bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Waktu &amp; Tanggal</th>
                    <th className="py-3 px-4">Nama Pengguna</th>
                    <th className="py-3 px-4">Peran / Jabatan</th>
                    <th className="py-3 px-4">NISN / Identitas</th>
                    <th className="py-3 px-4">Perangkat</th>
                    <th className="py-3 px-4">Aksi</th>
                    <th className="py-3 px-4 text-center">Kelola</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredLogs.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        <Info className="w-6 h-6 mx-auto mb-1 text-slate-300" />
                        <span>Tidak ada data log yang cocok dengan filter pencarian.</span>
                      </td>
                    </tr>
                  ) : (
                    filteredLogs.map((log) => {
                      const isRoleAdmin = log.role === 'admin';
                      return (
                        <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-2.5 px-4 whitespace-nowrap">
                            <div className="font-mono font-bold text-slate-800 text-[11px]">{log.timeStr} WIB</div>
                            <div className="text-[10px] text-slate-400">{log.dateStr}</div>
                          </td>
                          <td className="py-2.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                            {log.name}
                          </td>
                          <td className="py-2.5 px-4 whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                              log.roleTitle === 'Wali Kelas' ? 'bg-indigo-100 text-indigo-800 border border-indigo-200' :
                              log.roleTitle === 'Perangkat Kelas' ? 'bg-sky-100 text-sky-800 border border-sky-200' :
                              log.roleTitle === 'Admin Website' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                              'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            }`}>
                              {log.roleTitle}
                            </span>
                          </td>
                          <td className="py-2.5 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                            {log.nisn || '-'}
                          </td>
                          <td className="py-2.5 px-4 text-[11px] text-slate-600 whitespace-nowrap">
                            <span className="inline-flex items-center gap-1">
                              {log.device === 'Desktop' ? <Monitor className="w-3 h-3 text-slate-400" /> : <Smartphone className="w-3 h-3 text-slate-400" />}
                              <span>{log.device}</span>
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-[11px] text-slate-600 whitespace-nowrap">
                            <span className="font-medium">{log.action}</span>
                          </td>
                          <td className="py-2.5 px-4 text-center whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => handleDeleteLog(log.id, log.name)}
                              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                              title="Hapus baris log ini"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Bottom Note & Quick Trigger */}
            <div className="p-3.5 bg-slate-50 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                <Info className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>
                  Siklus retensi otomatis membatasi data mentah hanya dalam rentang <strong>7 hari terakhir</strong>.
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleCreateMonthlyRecap(false)}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-xs"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Buat Rekap 1 Bulan Sekarang</span>
              </button>
            </div>
          </div>

        </div>
      )}

      {/* SUB-TAB 2: MONTHLY RECAP ARCHIVE (REKAP 1 BULAN AKURAT) */}
      {activeSubTab === 'monthly_recap' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Action Header Card */}
          <div className="p-5 rounded-2xl bg-indigo-50/70 border border-indigo-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-indigo-600 text-white text-[10px] font-extrabold uppercase tracking-wide">
                  Rekap Bulanan Terpadu
                </span>
                <span className="text-xs font-bold text-indigo-950">
                  Arsip Laporan Akses 1 Bulan Penuh
                </span>
              </div>
              <p className="text-xs text-indigo-900 mt-1">
                Kompilasi akurat aktivitas siswa dan pengurus kelas setiap pergantian bulan dengan ringkasan statistik dan verifikasi status.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                id="btn-recap-now"
                onClick={() => handleCreateMonthlyRecap(false)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>Kompilasi Rekap Bulan Ini</span>
              </button>

              <button
                type="button"
                id="btn-recap-and-purge"
                onClick={() => {
                  if (window.confirm('Buat Rekap Bulanan sekaligus bersihkan log mentah bulan lalu secara otomatis?')) {
                    handleCreateMonthlyRecap(true);
                  }
                }}
                className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                title="Buat rekap dan bersihkan riwayat mentah siswa otomatis"
              >
                <Database className="w-3.5 h-3.5 text-indigo-600" />
                <span>Rekap &amp; Bersihkan Log Mentah</span>
              </button>
            </div>
          </div>

          {/* List of Archived Monthly Recaps */}
          <div className="space-y-4">
            {recaps.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-400">
                <FileText className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                <p className="text-xs font-semibold">Belum ada arsip rekap bulanan yang dibuat.</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Klik tombol &ldquo;Kompilasi Rekap Bulan Ini&rdquo; untuk membuat arsip 1 bulan akurat.</p>
              </div>
            ) : (
              recaps.map((recap) => (
                <div key={recap.id} className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-4">
                  {/* Recap Top Row */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-black text-slate-900">
                          Rekap Aktivitas: {recap.monthLabel}
                        </h4>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Hasil Akurat</span>
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">
                        Dibuat pada: {new Date(recap.generatedAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })} WIB
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleDeleteRecap(recap.id, recap.monthLabel)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition text-xs font-semibold flex items-center gap-1"
                        title="Hapus arsip rekap ini"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span className="text-[11px]">Hapus Arsip</span>
                      </button>
                    </div>
                  </div>

                  {/* Status Verification Box (Keterangan status 1 bulan) */}
                  <div className="p-3 rounded-xl bg-emerald-50/80 border border-emerald-200 text-emerald-950 text-xs flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block font-bold">{recap.statusNote}</strong>
                      <span className="text-[11px] text-emerald-800">
                        Data kunjungan, presensi, dan interaksi siswa selama periode 1 bulan telah tervalidasi secara komprehensif.
                      </span>
                    </div>
                  </div>

                  {/* Summary Metric Stats */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 font-semibold block">Total Kunjungan 1 Bulan</span>
                      <span className="text-lg font-black text-slate-900">{recap.totalVisits}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 font-semibold block">Siswa Aktif Masuk</span>
                      <span className="text-lg font-black text-emerald-600">{recap.studentVisits}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 font-semibold block">Login Wali &amp; Admin</span>
                      <span className="text-lg font-black text-indigo-600">{recap.adminVisits}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 font-semibold block">Hari Paling Ramai</span>
                      <span className="text-xs font-bold text-slate-800 truncate block mt-1">{recap.peakDay}</span>
                    </div>
                  </div>

                  {/* Top Active Users list for that month */}
                  {recap.topUsers && recap.topUsers.length > 0 && (
                    <div className="pt-2">
                      <span className="text-[11px] font-bold text-slate-700 block mb-2">
                        5 Pengguna Paling Sering Mengakses Portal ({recap.monthLabel}):
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                        {recap.topUsers.map((user, idx) => (
                          <div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2 truncate">
                              <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold text-[10px] shrink-0">
                                {idx + 1}
                              </span>
                              <div className="truncate">
                                <span className="font-bold text-slate-900 block truncate">{user.name}</span>
                                <span className="text-[10px] text-slate-400">{user.role}</span>
                              </div>
                            </div>
                            <span className="font-extrabold text-indigo-600 shrink-0 text-[11px]">
                              {user.count}x
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              ))
            )}
          </div>

        </div>
      )}

      {/* Single Log Delete Confirmation Modal */}
      {logToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-2.5 text-rose-600 mb-2.5">
              <div className="p-2 bg-rose-50 rounded-xl">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">Hapus Log Kunjungan?</h4>
                <span className="text-[11px] text-slate-500">Penghapusan Manual</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              Yakin ingin menghapus riwayat masuk untuk <strong>&quot;{logToDelete.name}&quot;</strong>?
            </p>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setLogToDelete(null)}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteLog}
                className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs"
              >
                Ya, Hapus Log
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All 7-Days Logs Confirmation Modal */}
      {showClearAllLogsConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-2.5 text-rose-600 mb-2.5">
              <div className="p-2 bg-rose-50 rounded-xl">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">Bersihkan Riwayat 7 Hari?</h4>
                <span className="text-[11px] text-slate-500">Hapus Seluruh Data Mentah</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              Seluruh riwayat masuk 7 hari terakhir akan dihapus. Rekap bulanan yang telah diarsip tetap tersimpan aman.
            </p>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowClearAllLogsConfirm(false)}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmClearAll}
                className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs"
              >
                Ya, Bersihkan Semua
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Monthly Recap Confirmation Modal */}
      {recapToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-2.5 text-rose-600 mb-2.5">
              <div className="p-2 bg-rose-50 rounded-xl">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">Hapus Arsip Rekap?</h4>
                <span className="text-[11px] text-slate-500">Arsip Bulanan</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              Yakin ingin menghapus arsip laporan bulanan untuk periode <strong>&quot;{recapToDelete.label}&quot;</strong>?
            </p>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setRecapToDelete(null)}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteRecap}
                className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs"
              >
                Ya, Hapus Rekap
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
